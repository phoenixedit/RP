$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

function Lips_Teeth_DominantTeeth() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('layerSection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(sTID('layerSectionStart'), 796);
    desc1.putInteger(sTID('layerSectionEnd'), 797);
    desc1.putString(cTID('Nm  '), 'Group 1');
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Without Yellow');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('AdjL'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    desc3.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindDefault'));
    desc3.putBoolean(cTID('Clrz'), false);
    desc2.putObject(cTID('Type'), cTID('HStr'), desc3);
    desc1.putObject(cTID('Usng'), cTID('AdjL'), desc2);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('AdjL'), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindCustom'));
    var list1 = new ActionList();
    var desc3 = new ActionDescriptor();
    desc3.putInteger(cTID('LclR'), 1);
    desc3.putInteger(cTID('BgnR'), 315);
    desc3.putInteger(cTID('BgnS'), 345);
    desc3.putInteger(cTID('EndS'), 15);
    desc3.putInteger(cTID('EndR'), 45);
    desc3.putInteger(cTID('H   '), 0);
    desc3.putInteger(cTID('Strt'), -21);
    desc3.putInteger(cTID('Lght'), 0);
    list1.putObject(cTID('Hst2'), desc3);
    var desc4 = new ActionDescriptor();
    desc4.putInteger(cTID('LclR'), 2);
    desc4.putInteger(cTID('BgnR'), 15);
    desc4.putInteger(cTID('BgnS'), 45);
    desc4.putInteger(cTID('EndS'), 75);
    desc4.putInteger(cTID('EndR'), 105);
    desc4.putInteger(cTID('H   '), 0);
    desc4.putInteger(cTID('Strt'), -54);
    desc4.putInteger(cTID('Lght'), 0);
    list1.putObject(cTID('Hst2'), desc4);
    desc2.putList(cTID('Adjs'), list1);
    desc1.putObject(cTID('T   '), cTID('HStr'), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Hue/Saturation ');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('AdjL'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    desc3.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindDefault'));
    desc2.putObject(cTID('Type'), cTID('SlcC'), desc3);
    desc1.putObject(cTID('Usng'), cTID('AdjL'), desc2);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step8(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('AdjL'), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindCustom'));
    var list1 = new ActionList();
    var desc3 = new ActionDescriptor();
    desc3.putEnumerated(cTID('Clrs'), cTID('Clrs'), cTID('Ylws'));
    desc3.putUnitDouble(cTID('Ylw '), cTID('#Prc'), -16);
    list1.putObject(cTID('ClrC'), desc3);
    desc2.putList(cTID('ClrC'), list1);
    desc1.putObject(cTID('T   '), cTID('SlcC'), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step9(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step10(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Selective Color ');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step11(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('AdjL'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(0);
    desc3.putList(cTID('ShdL'), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(0);
    desc3.putList(cTID('MdtL'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(0);
    desc3.putList(cTID('HghL'), list3);
    desc3.putBoolean(cTID('PrsL'), true);
    desc2.putObject(cTID('Type'), cTID('ClrB'), desc3);
    desc1.putObject(cTID('Usng'), cTID('AdjL'), desc2);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step12(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('AdjL'), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var list1 = new ActionList();
    list1.putInteger(-7);
    list1.putInteger(0);
    list1.putInteger(6);
    desc2.putList(cTID('HghL'), list1);
    desc1.putObject(cTID('T   '), cTID('ClrB'), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step13(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step14(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Color Balance ');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step15(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('AdjL'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    desc3.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindDefault'));
    desc2.putObject(cTID('Type'), cTID('Crvs'), desc3);
    desc1.putObject(cTID('Usng'), cTID('AdjL'), desc2);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step16(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('AdjL'), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(sTID('presetKind'), sTID('presetKindType'), sTID('presetKindCustom'));
    var list1 = new ActionList();
    var desc3 = new ActionDescriptor();
    var ref2 = new ActionReference();
    ref2.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Bl  '));
    desc3.putReference(cTID('Chnl'), ref2);
    var list2 = new ActionList();
    var desc4 = new ActionDescriptor();
    desc4.putDouble(cTID('Hrzn'), 0);
    desc4.putDouble(cTID('Vrtc'), 0);
    list2.putObject(cTID('Pnt '), desc4);
    var desc5 = new ActionDescriptor();
    desc5.putDouble(cTID('Hrzn'), 120);
    desc5.putDouble(cTID('Vrtc'), 134);
    list2.putObject(cTID('Pnt '), desc5);
    var desc6 = new ActionDescriptor();
    desc6.putDouble(cTID('Hrzn'), 255);
    desc6.putDouble(cTID('Vrtc'), 255);
    list2.putObject(cTID('Pnt '), desc6);
    desc3.putList(cTID('Crv '), list2);
    list1.putObject(cTID('CrvA'), desc3);
    desc2.putList(cTID('Adjs'), list1);
    desc1.putObject(cTID('T   '), cTID('Crvs'), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step17(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 73);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step18(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step19(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Curves ');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step20(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(801);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Crea
  function step21(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Inverti
  function step22(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('invert'), undefined, dialogMode);
  }

  // Selezione
  function step23(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(33);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step24(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('AdjL'), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var list1 = new ActionList();
    var desc3 = new ActionDescriptor();
    var ref2 = new ActionReference();
    ref2.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Cmps'));
    desc3.putReference(cTID('Chnl'), ref2);
    var list2 = new ActionList();
    var desc4 = new ActionDescriptor();
    desc4.putDouble(cTID('Hrzn'), 0);
    desc4.putDouble(cTID('Vrtc'), 0);
    list2.putObject(cTID('Pnt '), desc4);
    var desc5 = new ActionDescriptor();
    desc5.putDouble(cTID('Hrzn'), 117);
    desc5.putDouble(cTID('Vrtc'), 137);
    list2.putObject(cTID('Pnt '), desc5);
    var desc6 = new ActionDescriptor();
    desc6.putDouble(cTID('Hrzn'), 255);
    desc6.putDouble(cTID('Vrtc'), 255);
    list2.putObject(cTID('Pnt '), desc6);
    desc3.putList(cTID('Crv '), list2);
    list1.putObject(cTID('CrvA'), desc3);
    desc2.putList(cTID('Adjs'), list1);
    desc1.putObject(cTID('T   '), cTID('Crvs'), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step25(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(28);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step26(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 50);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step27(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 77);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step28(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 80);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step29(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(421);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step30(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step31(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Glow');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step32(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(420);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step33(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step34(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Add Cold Color');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step35(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(419);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step36(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step37(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Desaturate');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step38(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(418);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step39(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step40(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Desaturate Warm Color');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step41(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(419);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step42(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(420);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step43(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(421);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step44(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(416);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step45(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('PbTl'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step46(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Bckw'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(378);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step47(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 60);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step48(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Frwr'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(80);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Imposta
    step3(); // Crea
    step4(); // Imposta
    step5(); // Selezione
    step6(); // Imposta
    step7(); // Crea
    step8(); // Imposta
    step9(); // Selezione
    step10(); // Imposta
    step11(); // Crea
    step12(); // Imposta
    step13(); // Selezione
    step14(); // Imposta
    step15(); // Crea
    step16(); // Imposta
    step17(); // Imposta
    step18(); // Selezione
    step19(); // Imposta
    step20(); // Selezione
    step21(); // Crea
    step22(); // Inverti
    step23(); // Selezione
    step24(); // Imposta
    step25(); // Selezione
    step26(); // Imposta
    step27(); // Imposta
    step28(); // Imposta
    step29(); // Selezione
    step30(); // Selezione
    step31(); // Imposta
    step32(); // Selezione
    step33(); // Selezione
    step34(); // Imposta
    step35(); // Selezione
    step36(); // Selezione
    step37(); // Imposta
    step38(); // Selezione
    step39(); // Selezione
    step40(); // Imposta
    step41(); // Selezione
    step42(); // Selezione
    step43(); // Selezione
    step44(); // Selezione
    step45(); // Selezione
    step46(); // Selezione
    step47(); // Imposta
    step48(); // Selezione
    return true;
  } catch (error) {
    return false;
  }
}

Lips_Teeth_DominantTeeth();
