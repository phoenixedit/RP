$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Eyes - Reflections ==============
//
function Eyes_Reflections() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('layerSection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(sTID('layerSectionStart'), 378);
    desc1.putInteger(sTID('layerSectionEnd'), 379);
    desc1.putString(cTID('Nm  '), 'Gruppo 1');
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Reflections');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Ylw '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('contentLayer'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    var desc4 = new ActionDescriptor();
    desc4.putDouble(cTID('Rd  '), 255);
    desc4.putDouble(cTID('Grn '), 255);
    desc4.putDouble(cTID('Bl  '), 255);
    desc3.putObject(cTID('Clr '), sTID('RGBColor'), desc4);
    desc2.putObject(cTID('Type'), sTID('solidColorLayer'), desc3);
    var desc5 = new ActionDescriptor();
    var desc6 = new ActionDescriptor();
    desc6.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 296.544);
    desc6.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 207.491220285261);
    desc5.putObject(cTID('Cntr'), cTID('Pnt '), desc6);
    var desc7 = new ActionDescriptor();
    desc7.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 58.2680824088748);
    desc7.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 58.2680824088748);
    desc5.putObject(sTID('corner'), cTID('Ofst'), desc7);
    desc5.putInteger(sTID('sides'), 6);
    desc2.putObject(cTID('Shp '), cTID('Plgn'), desc5);
    var desc8 = new ActionDescriptor();
    desc8.putInteger(sTID('strokeStyleVersion'), 2);
    desc8.putBoolean(sTID('strokeEnabled'), false);
    desc8.putBoolean(sTID('fillEnabled'), true);
    desc8.putUnitDouble(sTID('strokeStyleLineWidth'), cTID('#Pxl'), 37.43);
    desc8.putUnitDouble(sTID('strokeStyleLineDashOffset'), cTID('#Pnt'), 0);
    desc8.putDouble(sTID('strokeStyleMiterLimit'), 100);
    desc8.putEnumerated(
      sTID('strokeStyleLineCapType'),
      sTID('strokeStyleLineCapType'),
      sTID('strokeStyleButtCap')
    );
    desc8.putEnumerated(
      sTID('strokeStyleLineJoinType'),
      sTID('strokeStyleLineJoinType'),
      sTID('strokeStyleMiterJoin')
    );
    desc8.putEnumerated(
      sTID('strokeStyleLineAlignment'),
      sTID('strokeStyleLineAlignment'),
      sTID('strokeStyleAlignInside')
    );
    desc8.putBoolean(sTID('strokeStyleScaleLock'), false);
    desc8.putBoolean(sTID('strokeStyleStrokeAdjust'), false);
    var list1 = new ActionList();
    desc8.putList(sTID('strokeStyleLineDashSet'), list1);
    desc8.putEnumerated(sTID('strokeStyleBlendMode'), cTID('BlnM'), cTID('Nrml'));
    desc8.putUnitDouble(sTID('strokeStyleOpacity'), cTID('#Prc'), 100);
    var desc9 = new ActionDescriptor();
    var desc10 = new ActionDescriptor();
    desc10.putDouble(cTID('Rd  '), 1.58946195384488);
    desc10.putDouble(cTID('Grn '), 1.5894620725885);
    desc10.putDouble(cTID('Bl  '), 1.5894620725885);
    desc9.putObject(cTID('Clr '), sTID('RGBColor'), desc10);
    desc8.putObject(sTID('strokeStyleContent'), sTID('solidColorLayer'), desc9);
    desc8.putDouble(sTID('strokeStyleResolution'), 300);
    desc2.putObject(sTID('strokeStyle'), sTID('strokeStyle'), desc8);
    desc1.putObject(cTID('Usng'), sTID('contentLayer'), desc2);
    desc1.putInteger(cTID('LyrI'), 380);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Converti
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Imposta
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Ovrl'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step8(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putProperty(cTID('Chnl'), sTID('selection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('T   '), cTID('Ordn'), cTID('Al  '));
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Allinea
  function step9(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('ADSt'), sTID('ADSCentersH'));
    desc1.putBoolean(sTID('alignToCanvas'), true);
    executeAction(sTID('align'), desc1, dialogMode);
  }

  // Allinea
  function step10(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('ADSt'), sTID('ADSCentersV'));
    desc1.putBoolean(sTID('alignToCanvas'), true);
    executeAction(sTID('align'), desc1, dialogMode);
  }

  // Imposta
  function step11(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putProperty(cTID('Chnl'), sTID('selection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('T   '), cTID('Ordn'), cTID('None'));
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Nascondi
  function step12(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Imposta
  function step13(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Hexagon');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step14(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 381);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Crea
  function step15(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('contentLayer'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    var desc3 = new ActionDescriptor();
    var desc4 = new ActionDescriptor();
    desc4.putDouble(cTID('Rd  '), 255);
    desc4.putDouble(cTID('Grn '), 255);
    desc4.putDouble(cTID('Bl  '), 255);
    desc3.putObject(cTID('Clr '), sTID('RGBColor'), desc4);
    desc2.putObject(cTID('Type'), sTID('solidColorLayer'), desc3);
    var desc5 = new ActionDescriptor();
    desc5.putInteger(sTID('unitValueQuadVersion'), 1);
    desc5.putUnitDouble(cTID('Top '), cTID('#Pxl'), 841);
    desc5.putUnitDouble(cTID('Left'), cTID('#Pxl'), 1090);
    desc5.putUnitDouble(cTID('Btom'), cTID('#Pxl'), 1498);
    desc5.putUnitDouble(cTID('Rght'), cTID('#Pxl'), 1747);
    desc2.putObject(cTID('Shp '), cTID('Elps'), desc5);
    var desc6 = new ActionDescriptor();
    desc6.putInteger(sTID('strokeStyleVersion'), 2);
    desc6.putBoolean(sTID('strokeEnabled'), false);
    desc6.putBoolean(sTID('fillEnabled'), true);
    desc6.putUnitDouble(sTID('strokeStyleLineWidth'), cTID('#Pxl'), 37.43);
    desc6.putUnitDouble(sTID('strokeStyleLineDashOffset'), cTID('#Pnt'), 0);
    desc6.putDouble(sTID('strokeStyleMiterLimit'), 100);
    desc6.putEnumerated(
      sTID('strokeStyleLineCapType'),
      sTID('strokeStyleLineCapType'),
      sTID('strokeStyleButtCap')
    );
    desc6.putEnumerated(
      sTID('strokeStyleLineJoinType'),
      sTID('strokeStyleLineJoinType'),
      sTID('strokeStyleMiterJoin')
    );
    desc6.putEnumerated(
      sTID('strokeStyleLineAlignment'),
      sTID('strokeStyleLineAlignment'),
      sTID('strokeStyleAlignInside')
    );
    desc6.putBoolean(sTID('strokeStyleScaleLock'), false);
    desc6.putBoolean(sTID('strokeStyleStrokeAdjust'), false);
    var list1 = new ActionList();
    desc6.putList(sTID('strokeStyleLineDashSet'), list1);
    desc6.putEnumerated(sTID('strokeStyleBlendMode'), cTID('BlnM'), cTID('Nrml'));
    desc6.putUnitDouble(sTID('strokeStyleOpacity'), cTID('#Prc'), 100);
    var desc7 = new ActionDescriptor();
    var desc8 = new ActionDescriptor();
    desc8.putDouble(cTID('Rd  '), 1.58946195384488);
    desc8.putDouble(cTID('Grn '), 1.5894620725885);
    desc8.putDouble(cTID('Bl  '), 1.5894620725885);
    desc7.putObject(cTID('Clr '), sTID('RGBColor'), desc8);
    desc6.putObject(sTID('strokeStyleContent'), sTID('solidColorLayer'), desc7);
    desc6.putDouble(sTID('strokeStyleResolution'), 300);
    desc2.putObject(sTID('strokeStyle'), sTID('strokeStyle'), desc6);
    desc1.putObject(cTID('Usng'), sTID('contentLayer'), desc2);
    desc1.putInteger(cTID('LyrI'), 382);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step16(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Ovrl'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step17(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Circle');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Converti
  function step18(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Imposta
  function step19(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putProperty(cTID('Chnl'), sTID('selection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('T   '), cTID('Ordn'), cTID('Al  '));
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Allinea
  function step20(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('ADSt'), sTID('ADSCentersH'));
    desc1.putBoolean(sTID('alignToCanvas'), true);
    executeAction(sTID('align'), desc1, dialogMode);
  }

  // Allinea
  function step21(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('ADSt'), sTID('ADSCentersV'));
    desc1.putBoolean(sTID('alignToCanvas'), true);
    executeAction(sTID('align'), desc1, dialogMode);
  }

  // Imposta
  function step22(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putProperty(cTID('Chnl'), sTID('selection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(cTID('T   '), cTID('Ordn'), cTID('None'));
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Nascondi
  function step23(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Selezione
  function step24(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), 'Reflections');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(378);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Imposta
    step3(); // Crea
    step4(); // Imposta
    step5(); // Crea
    step6(); // Converti
    step7(); // Imposta
    step8(); // Imposta
    step9(); // Allinea
    step10(); // Allinea
    step11(); // Imposta
    step12(); // Nascondi
    step13(); // Imposta
    step14(); // Crea
    step15(); // Crea
    step16(); // Imposta
    step17(); // Imposta
    step18(); // Converti
    step19(); // Imposta
    step20(); // Allinea
    step21(); // Allinea
    step22(); // Imposta
    step23(); // Nascondi
    step24(); // Selezione
    return true;
  } catch (error) {
    return false;
  }
}

Eyes_Reflections();
