$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

function Eyes_Image_Reflection() {
  // Inserisci
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 35);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/4.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 36);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/5.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 37);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/8.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 38);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/9.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 39);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/10.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 40);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/23.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 41);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/26.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step8(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 42);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/28.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Img '));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 5.45696821063757e-14);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step9(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 43);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/29.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), -1.09139364212751e-13);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step10(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 44);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/31.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 5.45696821063757e-14);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step11(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 45);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/32.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 0);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Inserisci
  function step12(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(cTID('Idnt'), 46);
    var panel = new File($.fileName).parent;
    var image = new File(panel + '/assets/34.jpg');
    desc1.putPath(cTID('null'), new File(image));
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('CMod'), 'JPEG');
    desc2.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Defa'));
    desc2.putString(cTID('CrVe'), '14.3');
    desc2.putInteger(cTID('PrVN'), 5);
    desc2.putInteger(cTID('PrVe'), 184549376);
    desc2.putString(cTID('Look'), '');
    desc2.putString(cTID('CamP'), 'Embedded');
    desc2.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc2.putBoolean(cTID('CtoG'), false);
    desc2.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc2.putInteger(cTID('Temp'), 0);
    desc2.putInteger(cTID('Tint'), 0);
    desc2.putDouble(cTID('Ex12'), 0);
    desc2.putInteger(cTID('Cr12'), 0);
    desc2.putInteger(cTID('Hi12'), 0);
    desc2.putInteger(cTID('Sh12'), 0);
    desc2.putInteger(cTID('Wh12'), 0);
    desc2.putInteger(cTID('Bk12'), 0);
    desc2.putInteger(cTID('CrTx'), 0);
    desc2.putInteger(cTID('Cl12'), 0);
    desc2.putInteger(cTID('Dhze'), 0);
    desc2.putInteger(cTID('Vibr'), 0);
    desc2.putInteger(cTID('Strt'), 0);
    desc2.putInteger(cTID('PC_S'), 0);
    desc2.putInteger(cTID('PC_D'), 0);
    desc2.putInteger(cTID('PC_L'), 0);
    desc2.putInteger(cTID('PC_H'), 0);
    desc2.putInteger(cTID('PC_1'), 25);
    desc2.putInteger(cTID('PC_2'), 50);
    desc2.putInteger(cTID('PC_3'), 75);
    desc2.putInteger(cTID('Shrp'), 0);
    desc2.putInteger(cTID('LNR '), 0);
    desc2.putInteger(cTID('CNR '), 0);
    desc2.putInteger(cTID('HA_R'), 0);
    desc2.putInteger(cTID('HA_O'), 0);
    desc2.putInteger(cTID('HA_Y'), 0);
    desc2.putInteger(cTID('HA_G'), 0);
    desc2.putInteger(cTID('HA_A'), 0);
    desc2.putInteger(cTID('HA_B'), 0);
    desc2.putInteger(cTID('HA_P'), 0);
    desc2.putInteger(cTID('HA_M'), 0);
    desc2.putInteger(cTID('SA_R'), 0);
    desc2.putInteger(cTID('SA_O'), 0);
    desc2.putInteger(cTID('SA_Y'), 0);
    desc2.putInteger(cTID('SA_G'), 0);
    desc2.putInteger(cTID('SA_A'), 0);
    desc2.putInteger(cTID('SA_B'), 0);
    desc2.putInteger(cTID('SA_P'), 0);
    desc2.putInteger(cTID('SA_M'), 0);
    desc2.putInteger(cTID('LA_R'), 0);
    desc2.putInteger(cTID('LA_O'), 0);
    desc2.putInteger(cTID('LA_Y'), 0);
    desc2.putInteger(cTID('LA_G'), 0);
    desc2.putInteger(cTID('LA_A'), 0);
    desc2.putInteger(cTID('LA_B'), 0);
    desc2.putInteger(cTID('LA_P'), 0);
    desc2.putInteger(cTID('LA_M'), 0);
    desc2.putInteger(cTID('STSH'), 0);
    desc2.putInteger(cTID('STSS'), 0);
    desc2.putInteger(cTID('STHH'), 0);
    desc2.putInteger(cTID('STHS'), 0);
    desc2.putInteger(cTID('STB '), 0);
    desc2.putInteger(cTID('CgMH'), 0);
    desc2.putInteger(cTID('CgMS'), 0);
    desc2.putInteger(cTID('CgSL'), 0);
    desc2.putInteger(cTID('CgML'), 0);
    desc2.putInteger(cTID('CgHL'), 0);
    desc2.putInteger(cTID('CgBl'), 50);
    desc2.putInteger(cTID('CgGH'), 0);
    desc2.putInteger(cTID('CgGS'), 0);
    desc2.putInteger(cTID('CgGL'), 0);
    desc2.putInteger(cTID('AuCA'), 0);
    desc2.putInteger(cTID('LPEn'), 0);
    desc2.putInteger(cTID('MDis'), 0);
    desc2.putInteger(cTID('VigA'), 0);
    desc2.putInteger(cTID('DfPA'), 0);
    desc2.putInteger(cTID('DPHL'), 30);
    desc2.putInteger(cTID('DPHH'), 70);
    desc2.putInteger(cTID('DfGA'), 0);
    desc2.putInteger(cTID('DPGL'), 40);
    desc2.putInteger(cTID('DPGH'), 60);
    desc2.putInteger(cTID('PerU'), 0);
    desc2.putInteger(cTID('PerV'), 0);
    desc2.putInteger(cTID('PerH'), 0);
    desc2.putDouble(cTID('PerR'), 0);
    desc2.putInteger(cTID('PerA'), 0);
    desc2.putInteger(cTID('PerS'), 100);
    desc2.putDouble(cTID('PerX'), 0);
    desc2.putDouble(cTID('PerY'), 0);
    desc2.putInteger(cTID('GRNA'), 0);
    desc2.putInteger(cTID('PCVA'), 0);
    desc2.putInteger(cTID('BlkB'), 0);
    desc2.putInteger(cTID('RHue'), 0);
    desc2.putInteger(cTID('RSat'), 0);
    desc2.putInteger(cTID('GHue'), 0);
    desc2.putInteger(cTID('GSat'), 0);
    desc2.putInteger(cTID('BHue'), 0);
    desc2.putInteger(cTID('BSat'), 0);
    desc2.putInteger(cTID('TMMs'), 0);
    desc2.putInteger(cTID('PGTM'), 0);
    desc2.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc2.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc2.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc2.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc2.putList(cTID('CrvB'), list4);
    desc2.putString(cTID('Rtch'), '');
    desc2.putString(cTID('REye'), '');
    desc2.putString(cTID('LCs '), '');
    desc2.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc2.putString(cTID('Pset'), '');
    desc2.putDouble(cTID('CrpT'), 0);
    desc2.putDouble(cTID('CrpL'), 0);
    desc2.putDouble(cTID('CrpB'), 1);
    desc2.putDouble(cTID('CrpR'), 1);
    desc2.putDouble(cTID('CrpA'), 0);
    desc2.putBoolean(cTID('CCrp'), false);
    desc2.putEnumerated(cTID('ClrS'), cTID('ClrS'), cTID('SMPT'));
    desc2.putEnumerated(cTID('BtDp'), cTID('BtDp'), cTID('BD8 '));
    desc2.putEnumerated(cTID('RStF'), cTID('RStF'), cTID('RFNo'));
    desc2.putDouble(cTID('Rslt'), 300);
    desc2.putEnumerated(cTID('ReUn'), cTID('ReUn'), cTID('PpIn'));
    desc2.putEnumerated(cTID('OSM '), cTID('OSM '), cTID('OSMN'));
    desc2.putInteger(cTID('Ornt'), 0);
    desc2.putString(cTID('Snap'), '');
    desc1.putObject(cTID('OpAs'), sTID('Adobe Camera Raw'), desc2);
    desc1.putEnumerated(cTID('FTcs'), cTID('QCSt'), sTID('QCSAverage'));
    var desc3 = new ActionDescriptor();
    desc3.putUnitDouble(cTID('Hrzn'), cTID('#Rlt'), 5.45696821063757e-14);
    desc3.putUnitDouble(cTID('Vrtc'), cTID('#Rlt'), 0);
    desc1.putObject(cTID('Ofst'), cTID('Ofst'), desc3);
    executeAction(sTID('placeEvent'), desc1, dialogMode);
  }

  // Selezione
  function step13(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    list1.putInteger(36);
    list1.putInteger(37);
    list1.putInteger(38);
    list1.putInteger(39);
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    list1.putInteger(45);
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Crea
  function step14(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('layerSection'));
    desc1.putReference(cTID('null'), ref1);
    var ref2 = new ActionReference();
    ref2.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('From'), ref2);
    desc1.putInteger(sTID('layerSectionStart'), 47);
    desc1.putInteger(sTID('layerSectionEnd'), 48);
    desc1.putString(cTID('Nm  '), 'Gruppo 1');
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step15(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Reflection');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step16(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Selezione
  function step17(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '31');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step18(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    list1.putInteger(36);
    list1.putInteger(37);
    list1.putInteger(38);
    list1.putInteger(39);
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    list1.putInteger(45);
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step19(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '10');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(39);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step20(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Converti
  function step21(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Selezione
  function step22(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '5');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(36);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Converti
  function step23(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Selezione
  function step24(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '8');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(37);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Converti
  function step25(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Selezione
  function step26(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '9');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(38);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step27(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '10');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(38);
    list1.putInteger(39);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Converti
  function step28(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Selezione
  function step29(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '23');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(40);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step30(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '31');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    list1.putInteger(45);
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Converti
  function step31(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('rasterizeLayer'), desc1, dialogMode);
  }

  // Selezione
  function step32(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '32');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(44);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step33(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '31');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step34(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    list1.putInteger(36);
    list1.putInteger(37);
    list1.putInteger(38);
    list1.putInteger(39);
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    list1.putInteger(45);
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Nascondi
  function step35(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step36(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '5');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step37(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '8');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step38(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '9');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step39(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '10');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step40(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '23');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step41(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '26');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step42(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '28');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step43(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '34');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step44(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '32');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step45(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '29');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Selezione
  function step46(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '31');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(46);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step47(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Scrn'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Nascondi
  function step48(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Mostra
  function step49(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '29');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Selezione
  function step50(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '29');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(45);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step51(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Scrn'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Nascondi
  function step52(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Selezione
  function step53(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '32');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(44);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step54(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    list1.putInteger(36);
    list1.putInteger(37);
    list1.putInteger(38);
    list1.putInteger(39);
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step55(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '23');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(40);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step56(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '32');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(44);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Mostra
  function step57(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step58(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step59(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '5');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step60(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '8');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step61(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '9');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step62(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '10');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step63(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '23');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step64(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '26');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step65(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '28');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Mostra
  function step66(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '34');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Selezione
  function step67(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putEnumerated(
      sTID('selectionModifier'),
      sTID('selectionModifierType'),
      sTID('addToSelectionContinuous')
    );
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    list1.putInteger(36);
    list1.putInteger(37);
    list1.putInteger(38);
    list1.putInteger(39);
    list1.putInteger(40);
    list1.putInteger(41);
    list1.putInteger(42);
    list1.putInteger(43);
    list1.putInteger(44);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Imposta
  function step68(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('CDdg'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step69(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Scrn'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Nascondi
  function step70(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '32');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step71(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '34');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step72(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '28');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step73(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '26');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step74(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '23');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step75(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '10');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step76(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '9');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step77(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '8');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step78(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '5');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Nascondi
  function step79(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Mostra
  function step80(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Selezione
  function step81(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), '4');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(35);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Nascondi
  function step82(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  try {
    step1(); // Inserisci
    step2(); // Inserisci
    step3(); // Inserisci
    step4(); // Inserisci
    step5(); // Inserisci
    step6(); // Inserisci
    step7(); // Inserisci
    step8(); // Inserisci
    step9(); // Inserisci
    step10(); // Inserisci
    step11(); // Inserisci
    step12(); // Inserisci
    step13(); // Selezione
    step14(); // Crea
    step15(); // Imposta
    step16(); // Crea
    step17(); // Selezione
    step18(); // Selezione
    step19(); // Selezione
    step20(); // Selezione
    step21(); // Converti
    step22(); // Selezione
    step23(); // Converti
    step24(); // Selezione
    step25(); // Converti
    step26(); // Selezione
    step27(); // Selezione
    step28(); // Converti
    step29(); // Selezione
    step30(); // Selezione
    step31(); // Converti
    step32(); // Selezione
    step33(); // Selezione
    step34(); // Selezione
    step35(); // Nascondi
    step36(); // Nascondi
    step37(); // Nascondi
    step38(); // Nascondi
    step39(); // Nascondi
    step40(); // Nascondi
    step41(); // Nascondi
    step42(); // Nascondi
    step43(); // Nascondi
    step44(); // Nascondi
    step45(); // Nascondi
    step46(); // Selezione
    step47(); // Imposta
    step48(); // Nascondi
    step49(); // Mostra
    step50(); // Selezione
    step51(); // Imposta
    step52(); // Nascondi
    step53(); // Selezione
    step54(); // Selezione
    step55(); // Selezione
    step56(); // Selezione
    step57(); // Mostra
    step58(); // Mostra
    step59(); // Mostra
    step60(); // Mostra
    step61(); // Mostra
    step62(); // Mostra
    step63(); // Mostra
    step64(); // Mostra
    step65(); // Mostra
    step66(); // Mostra
    step67(); // Selezione
    step68(); // Imposta
    step69(); // Imposta
    step70(); // Nascondi
    step71(); // Nascondi
    step72(); // Nascondi
    step73(); // Nascondi
    step74(); // Nascondi
    step75(); // Nascondi
    step76(); // Nascondi
    step77(); // Nascondi
    step78(); // Nascondi
    step79(); // Nascondi
    step80(); // Mostra
    step81(); // Selezione
    step82(); // Nascondi
    return true;
  } catch (error) {
    return false;
  }
}

Eyes_Image_Reflection();
