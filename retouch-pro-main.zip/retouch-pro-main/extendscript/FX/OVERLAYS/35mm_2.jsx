$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== 35mm Film II ==============
//
function Film35mm_2() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), 1);
    desc1.putDouble(cTID('Ex12'), -0.05);
    desc1.putInteger(cTID('Cr12'), 15);
    desc1.putInteger(cTID('Hi12'), -35);
    desc1.putInteger(cTID('Sh12'), 60);
    desc1.putInteger(cTID('Wh12'), -30);
    desc1.putInteger(cTID('Bk12'), 55);
    desc1.putInteger(cTID('Cl12'), 5);
    desc1.putInteger(cTID('Vibr'), 25);
    desc1.putInteger(cTID('Strt'), -20);
    desc1.putInteger(cTID('LNR '), 10);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), -5);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), 5);
    desc1.putInteger(cTID('HA_G'), -35);
    desc1.putInteger(cTID('HA_A'), 30);
    desc1.putInteger(cTID('HA_B'), -15);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), -15);
    desc1.putInteger(cTID('SA_R'), -10);
    desc1.putInteger(cTID('SA_O'), -30);
    desc1.putInteger(cTID('SA_Y'), 20);
    desc1.putInteger(cTID('SA_G'), -60);
    desc1.putInteger(cTID('SA_A'), 25);
    desc1.putInteger(cTID('SA_B'), 0);
    desc1.putInteger(cTID('SA_P'), -30);
    desc1.putInteger(cTID('SA_M'), -25);
    desc1.putInteger(cTID('LA_R'), -30);
    desc1.putInteger(cTID('LA_O'), -10);
    desc1.putInteger(cTID('LA_Y'), -20);
    desc1.putInteger(cTID('LA_G'), 35);
    desc1.putInteger(cTID('LA_A'), 60);
    desc1.putInteger(cTID('LA_B'), 30);
    desc1.putInteger(cTID('LA_P'), -25);
    desc1.putInteger(cTID('LA_M'), -25);
    desc1.putInteger(cTID('STSH'), 50);
    desc1.putInteger(cTID('STSS'), 15);
    desc1.putInteger(cTID('STHH'), 185);
    desc1.putInteger(cTID('STHS'), 5);
    desc1.putInteger(cTID('STB '), 10);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    desc1.putInteger(cTID('GRNA'), 45);
    desc1.putInteger(cTID('GRNS'), 35);
    desc1.putInteger(cTID('GRNF'), 45);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 45);
    desc1.putInteger(cTID('RSat'), -10);
    desc1.putInteger(cTID('GHue'), 70);
    desc1.putInteger(cTID('GSat'), -15);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), -10);
    desc1.putInteger(cTID('TMMs'), 0);
    desc1.putInteger(cTID('PGTM'), 0);
    desc1.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(39);
    list1.putInteger(57);
    list1.putInteger(73);
    list1.putInteger(125);
    list1.putInteger(127);
    list1.putInteger(189);
    list1.putInteger(187);
    list1.putInteger(255);
    list1.putInteger(249);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(39);
    list2.putInteger(9);
    list2.putInteger(89);
    list2.putInteger(60);
    list2.putInteger(127);
    list2.putInteger(120);
    list2.putInteger(197);
    list2.putInteger(206);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(39);
    list3.putInteger(11);
    list3.putInteger(91);
    list3.putInteger(63);
    list3.putInteger(130);
    list3.putInteger(121);
    list3.putInteger(198);
    list3.putInteger(205);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(40);
    list4.putInteger(13);
    list4.putInteger(88);
    list4.putInteger(63);
    list4.putInteger(128);
    list4.putInteger(120);
    list4.putInteger(197);
    list4.putInteger(206);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="35mm Film II"\n     crs:Amount="1"\n     crs:UUID="C7070D27C2E98F7EC60FE48DFA6045E3"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="+1"\n      crs:Exposure2012="-0.05"\n      crs:Contrast2012="+15"\n      crs:Highlights2012="-35"\n      crs:Shadows2012="+60"\n      crs:Whites2012="-30"\n      crs:Blacks2012="+55"\n      crs:Clarity2012="+5"\n      crs:Vibrance="+25"\n      crs:Saturation="-20"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="10"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="-5"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="+5"\n      crs:HueAdjustmentGreen="-35"\n      crs:HueAdjustmentAqua="+30"\n      crs:HueAdjustmentBlue="-15"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="-15"\n      crs:SaturationAdjustmentRed="-10"\n      crs:SaturationAdjustmentOrange="-30"\n      crs:SaturationAdjustmentYellow="+20"\n      crs:SaturationAdjustmentGreen="-60"\n      crs:SaturationAdjustmentAqua="+25"\n      crs:SaturationAdjustmentBlue="0"\n      crs:SaturationAdjustmentPurple="-30"\n      crs:SaturationAdjustmentMagenta="-25"\n      crs:LuminanceAdjustmentRed="-30"\n      crs:LuminanceAdjustmentOrange="-10"\n      crs:LuminanceAdjustmentYellow="-20"\n      crs:LuminanceAdjustmentGreen="+35"\n      crs:LuminanceAdjustmentAqua="+60"\n      crs:LuminanceAdjustmentBlue="+30"\n      crs:LuminanceAdjustmentPurple="-25"\n      crs:LuminanceAdjustmentMagenta="-25"\n      crs:SplitToningShadowHue="50"\n      crs:SplitToningShadowSaturation="15"\n      crs:SplitToningHighlightHue="185"\n      crs:SplitToningHighlightSaturation="5"\n      crs:SplitToningBalance="+10"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="45"\n      crs:GrainSize="35"\n      crs:GrainFrequency="45"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+45"\n      crs:RedSaturation="-10"\n      crs:GreenHue="+70"\n      crs:GreenSaturation="-15"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="-10"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 39</rdf:li>\n       <rdf:li>57, 73</rdf:li>\n       <rdf:li>125, 127</rdf:li>\n       <rdf:li>189, 187</rdf:li>\n       <rdf:li>255, 249</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 9</rdf:li>\n       <rdf:li>89, 60</rdf:li>\n       <rdf:li>127, 120</rdf:li>\n       <rdf:li>197, 206</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 11</rdf:li>\n       <rdf:li>91, 63</rdf:li>\n       <rdf:li>130, 121</rdf:li>\n       <rdf:li>198, 205</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>40, 13</rdf:li>\n       <rdf:li>88, 63</rdf:li>\n       <rdf:li>128, 120</rdf:li>\n       <rdf:li>197, 206</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), '35mm Film II');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

Film35mm_2();
