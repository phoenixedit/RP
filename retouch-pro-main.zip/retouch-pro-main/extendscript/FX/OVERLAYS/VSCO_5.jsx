$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== VSCO V ==============
//
function FilmVSCO_5() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), -30);
    desc1.putInteger(cTID('Sh12'), 55);
    desc1.putInteger(cTID('Bk12'), 90);
    desc1.putInteger(cTID('HA_R'), -40);
    desc1.putInteger(cTID('HA_O'), 0);
    desc1.putInteger(cTID('HA_Y'), -5);
    desc1.putInteger(cTID('HA_G'), -10);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), 0);
    desc1.putInteger(cTID('HA_P'), 20);
    desc1.putInteger(cTID('HA_M'), 0);
    desc1.putInteger(cTID('SA_R'), -40);
    desc1.putInteger(cTID('SA_O'), -25);
    desc1.putInteger(cTID('SA_Y'), -60);
    desc1.putInteger(cTID('SA_G'), -70);
    desc1.putInteger(cTID('SA_A'), -70);
    desc1.putInteger(cTID('SA_B'), -20);
    desc1.putInteger(cTID('SA_P'), -55);
    desc1.putInteger(cTID('SA_M'), -10);
    desc1.putInteger(cTID('LA_R'), -30);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), 0);
    desc1.putInteger(cTID('LA_G'), 0);
    desc1.putInteger(cTID('LA_A'), -15);
    desc1.putInteger(cTID('LA_B'), -20);
    desc1.putInteger(cTID('LA_P'), -10);
    desc1.putInteger(cTID('LA_M'), -20);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 55);
    desc1.putInteger(cTID('RSat'), 10);
    desc1.putInteger(cTID('GHue'), 100);
    desc1.putInteger(cTID('GSat'), -60);
    desc1.putInteger(cTID('BHue'), -10);
    desc1.putInteger(cTID('BSat'), -5);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(1);
    list1.putInteger(36);
    list1.putInteger(28);
    list1.putInteger(124);
    list1.putInteger(125);
    list1.putInteger(192);
    list1.putInteger(184);
    list1.putInteger(255);
    list1.putInteger(239);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(36);
    list2.putInteger(14);
    list2.putInteger(91);
    list2.putInteger(58);
    list2.putInteger(129);
    list2.putInteger(113);
    list2.putInteger(172);
    list2.putInteger(187);
    list2.putInteger(212);
    list2.putInteger(231);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(42);
    list3.putInteger(16);
    list3.putInteger(79);
    list3.putInteger(43);
    list3.putInteger(109);
    list3.putInteger(81);
    list3.putInteger(131);
    list3.putInteger(119);
    list3.putInteger(181);
    list3.putInteger(198);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(79);
    list4.putInteger(37);
    list4.putInteger(131);
    list4.putInteger(111);
    list4.putInteger(185);
    list4.putInteger(196);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="VSCO V"\n     crs:Amount="1"\n     crs:UUID="D8ED44BC61AF77DD159E56F235F3E2C0"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="-30"\n      crs:Highlights2012="0"\n      crs:Shadows2012="+55"\n      crs:Whites2012="0"\n      crs:Blacks2012="+90"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:HueAdjustmentRed="-40"\n      crs:HueAdjustmentOrange="0"\n      crs:HueAdjustmentYellow="-5"\n      crs:HueAdjustmentGreen="-10"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="0"\n      crs:HueAdjustmentPurple="+20"\n      crs:HueAdjustmentMagenta="0"\n      crs:SaturationAdjustmentRed="-40"\n      crs:SaturationAdjustmentOrange="-25"\n      crs:SaturationAdjustmentYellow="-60"\n      crs:SaturationAdjustmentGreen="-70"\n      crs:SaturationAdjustmentAqua="-70"\n      crs:SaturationAdjustmentBlue="-20"\n      crs:SaturationAdjustmentPurple="-55"\n      crs:SaturationAdjustmentMagenta="-10"\n      crs:LuminanceAdjustmentRed="-30"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="0"\n      crs:LuminanceAdjustmentGreen="0"\n      crs:LuminanceAdjustmentAqua="-15"\n      crs:LuminanceAdjustmentBlue="-20"\n      crs:LuminanceAdjustmentPurple="-10"\n      crs:LuminanceAdjustmentMagenta="-20"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="0"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+55"\n      crs:RedSaturation="+10"\n      crs:GreenHue="+100"\n      crs:GreenSaturation="-60"\n      crs:BlueHue="-10"\n      crs:BlueSaturation="-5"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 1</rdf:li>\n       <rdf:li>36, 28</rdf:li>\n       <rdf:li>124, 125</rdf:li>\n       <rdf:li>192, 184</rdf:li>\n       <rdf:li>255, 239</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>36, 14</rdf:li>\n       <rdf:li>91, 58</rdf:li>\n       <rdf:li>129, 113</rdf:li>\n       <rdf:li>172, 187</rdf:li>\n       <rdf:li>212, 231</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>42, 16</rdf:li>\n       <rdf:li>79, 43</rdf:li>\n       <rdf:li>109, 81</rdf:li>\n       <rdf:li>131, 119</rdf:li>\n       <rdf:li>181, 198</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>79, 37</rdf:li>\n       <rdf:li>131, 111</rdf:li>\n       <rdf:li>185, 196</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'VSCO V');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmVSCO_5();
