$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== 35mm Film I ==============
//
function Film35mm_1() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), 1);
    desc1.putDouble(cTID('Ex12'), -0.09);
    desc1.putInteger(cTID('Cr12'), -20);
    desc1.putInteger(cTID('Hi12'), -45);
    desc1.putInteger(cTID('Sh12'), 60);
    desc1.putInteger(cTID('Wh12'), -35);
    desc1.putInteger(cTID('Bk12'), 70);
    desc1.putInteger(cTID('Cl12'), 10);
    desc1.putInteger(cTID('Vibr'), 20);
    desc1.putInteger(cTID('Strt'), -15);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 30);
    desc1.putInteger(cTID('PC_2'), 48);
    desc1.putInteger(cTID('PC_3'), 89);
    desc1.putInteger(cTID('Shrp'), 15);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('LNR '), 5);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNR '), 10);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), 15);
    desc1.putInteger(cTID('HA_O'), 0);
    desc1.putInteger(cTID('HA_Y'), -5);
    desc1.putInteger(cTID('HA_G'), -25);
    desc1.putInteger(cTID('HA_A'), 40);
    desc1.putInteger(cTID('HA_B'), -10);
    desc1.putInteger(cTID('HA_P'), 15);
    desc1.putInteger(cTID('HA_M'), -5);
    desc1.putInteger(cTID('SA_R'), -25);
    desc1.putInteger(cTID('SA_O'), -15);
    desc1.putInteger(cTID('SA_Y'), -30);
    desc1.putInteger(cTID('SA_G'), -60);
    desc1.putInteger(cTID('SA_A'), -15);
    desc1.putInteger(cTID('SA_B'), -15);
    desc1.putInteger(cTID('SA_P'), -20);
    desc1.putInteger(cTID('SA_M'), -45);
    desc1.putInteger(cTID('LA_R'), -20);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), 0);
    desc1.putInteger(cTID('LA_G'), 40);
    desc1.putInteger(cTID('LA_A'), 30);
    desc1.putInteger(cTID('LA_B'), 15);
    desc1.putInteger(cTID('LA_P'), 20);
    desc1.putInteger(cTID('LA_M'), 25);
    desc1.putInteger(cTID('STSH'), 45);
    desc1.putInteger(cTID('STSS'), 10);
    desc1.putInteger(cTID('STHH'), 60);
    desc1.putInteger(cTID('STHS'), 5);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    desc1.putInteger(cTID('GRNA'), 35);
    desc1.putInteger(cTID('GRNS'), 40);
    desc1.putInteger(cTID('GRNF'), 60);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 10);
    desc1.putInteger(cTID('RSat'), -5);
    desc1.putInteger(cTID('GHue'), 30);
    desc1.putInteger(cTID('GSat'), -15);
    desc1.putInteger(cTID('BHue'), 0);
    desc1.putInteger(cTID('BSat'), -20);
    desc1.putInteger(cTID('TMMs'), 0);
    desc1.putInteger(cTID('PGTM'), 0);
    desc1.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(19);
    list1.putInteger(31);
    list1.putInteger(29);
    list1.putInteger(62);
    list1.putInteger(51);
    list1.putInteger(93);
    list1.putInteger(84);
    list1.putInteger(130);
    list1.putInteger(125);
    list1.putInteger(173);
    list1.putInteger(181);
    list1.putInteger(210);
    list1.putInteger(226);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(4);
    list2.putInteger(0);
    list2.putInteger(53);
    list2.putInteger(12);
    list2.putInteger(83);
    list2.putInteger(49);
    list2.putInteger(136);
    list2.putInteger(126);
    list2.putInteger(203);
    list2.putInteger(214);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(43);
    list3.putInteger(16);
    list3.putInteger(88);
    list3.putInteger(58);
    list3.putInteger(125);
    list3.putInteger(112);
    list3.putInteger(193);
    list3.putInteger(204);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(45);
    list4.putInteger(11);
    list4.putInteger(94);
    list4.putInteger(67);
    list4.putInteger(129);
    list4.putInteger(122);
    list4.putInteger(166);
    list4.putInteger(184);
    list4.putInteger(217);
    list4.putInteger(241);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="35mm Film I"\n     crs:Amount="1"\n     crs:UUID="D6AF8BBDB8D372623C3E88201D8ED186"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="+1"\n      crs:Exposure2012="-0.09"\n      crs:Contrast2012="-20"\n      crs:Highlights2012="-45"\n      crs:Shadows2012="+60"\n      crs:Whites2012="-35"\n      crs:Blacks2012="+70"\n      crs:Clarity2012="+10"\n      crs:Vibrance="+20"\n      crs:Saturation="-15"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="30"\n      crs:ParametricMidtoneSplit="48"\n      crs:ParametricHighlightSplit="89"\n      crs:Sharpness="15"\n      crs:SharpenRadius="+1.0"\n      crs:SharpenDetail="25"\n      crs:SharpenEdgeMasking="0"\n      crs:LuminanceSmoothing="5"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReduction="10"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="+15"\n      crs:HueAdjustmentOrange="0"\n      crs:HueAdjustmentYellow="-5"\n      crs:HueAdjustmentGreen="-25"\n      crs:HueAdjustmentAqua="+40"\n      crs:HueAdjustmentBlue="-10"\n      crs:HueAdjustmentPurple="+15"\n      crs:HueAdjustmentMagenta="-5"\n      crs:SaturationAdjustmentRed="-25"\n      crs:SaturationAdjustmentOrange="-15"\n      crs:SaturationAdjustmentYellow="-30"\n      crs:SaturationAdjustmentGreen="-60"\n      crs:SaturationAdjustmentAqua="-15"\n      crs:SaturationAdjustmentBlue="-15"\n      crs:SaturationAdjustmentPurple="-20"\n      crs:SaturationAdjustmentMagenta="-45"\n      crs:LuminanceAdjustmentRed="-20"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="0"\n      crs:LuminanceAdjustmentGreen="+40"\n      crs:LuminanceAdjustmentAqua="+30"\n      crs:LuminanceAdjustmentBlue="+15"\n      crs:LuminanceAdjustmentPurple="+20"\n      crs:LuminanceAdjustmentMagenta="+25"\n      crs:SplitToningShadowHue="45"\n      crs:SplitToningShadowSaturation="10"\n      crs:SplitToningHighlightHue="60"\n      crs:SplitToningHighlightSaturation="5"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="35"\n      crs:GrainSize="40"\n      crs:GrainFrequency="60"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+10"\n      crs:RedSaturation="-5"\n      crs:GreenHue="+30"\n      crs:GreenSaturation="-15"\n      crs:BlueHue="0"\n      crs:BlueSaturation="-20"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 19</rdf:li>\n       <rdf:li>31, 29</rdf:li>\n       <rdf:li>62, 51</rdf:li>\n       <rdf:li>93, 84</rdf:li>\n       <rdf:li>130, 125</rdf:li>\n       <rdf:li>173, 181</rdf:li>\n       <rdf:li>210, 226</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>4, 0</rdf:li>\n       <rdf:li>53, 12</rdf:li>\n       <rdf:li>83, 49</rdf:li>\n       <rdf:li>136, 126</rdf:li>\n       <rdf:li>203, 214</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 16</rdf:li>\n       <rdf:li>88, 58</rdf:li>\n       <rdf:li>125, 112</rdf:li>\n       <rdf:li>193, 204</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>45, 11</rdf:li>\n       <rdf:li>94, 67</rdf:li>\n       <rdf:li>129, 122</rdf:li>\n       <rdf:li>166, 184</rdf:li>\n       <rdf:li>217, 241</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), '35mm Film I');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

Film35mm_1();
