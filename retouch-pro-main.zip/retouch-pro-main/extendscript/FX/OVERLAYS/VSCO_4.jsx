$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== VSCO IV ==============
//
function FilmVSCO_4() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), -25);
    desc1.putInteger(cTID('Sh12'), -30);
    desc1.putInteger(cTID('Wh12'), -5);
    desc1.putInteger(cTID('Bk12'), 80);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), -10);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), 45);
    desc1.putInteger(cTID('HA_G'), -50);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), 5);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 0);
    desc1.putInteger(cTID('SA_R'), -30);
    desc1.putInteger(cTID('SA_O'), -20);
    desc1.putInteger(cTID('SA_Y'), -35);
    desc1.putInteger(cTID('SA_G'), -75);
    desc1.putInteger(cTID('SA_A'), -70);
    desc1.putInteger(cTID('SA_B'), -80);
    desc1.putInteger(cTID('SA_P'), -85);
    desc1.putInteger(cTID('SA_M'), 25);
    desc1.putInteger(cTID('LA_R'), 0);
    desc1.putInteger(cTID('LA_O'), -15);
    desc1.putInteger(cTID('LA_Y'), -10);
    desc1.putInteger(cTID('LA_G'), -15);
    desc1.putInteger(cTID('LA_A'), 10);
    desc1.putInteger(cTID('LA_B'), 5);
    desc1.putInteger(cTID('LA_P'), 5);
    desc1.putInteger(cTID('LA_M'), 15);
    desc1.putInteger(cTID('STSH'), 65);
    desc1.putInteger(cTID('STSS'), 5);
    desc1.putInteger(cTID('STHH'), 45);
    desc1.putInteger(cTID('STHS'), 30);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    var list1 = new ActionList();
    list1.putInteger(6);
    list1.putInteger(0);
    list1.putInteger(101);
    list1.putInteger(104);
    list1.putInteger(193);
    list1.putInteger(205);
    list1.putInteger(255);
    list1.putInteger(247);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(38);
    list2.putInteger(22);
    list2.putInteger(118);
    list2.putInteger(127);
    list2.putInteger(193);
    list2.putInteger(202);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(38);
    list3.putInteger(22);
    list3.putInteger(117);
    list3.putInteger(125);
    list3.putInteger(193);
    list3.putInteger(202);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(42);
    list4.putInteger(23);
    list4.putInteger(120);
    list4.putInteger(125);
    list4.putInteger(194);
    list4.putInteger(202);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="VSCO IV"\n     crs:Amount="1"\n     crs:UUID="F11CFA3756FDB7233924C55A8CBD87AD"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="-25"\n      crs:Highlights2012="0"\n      crs:Shadows2012="-30"\n      crs:Whites2012="-5"\n      crs:Blacks2012="+80"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="-10"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="+45"\n      crs:HueAdjustmentGreen="-50"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="+5"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="0"\n      crs:SaturationAdjustmentRed="-30"\n      crs:SaturationAdjustmentOrange="-20"\n      crs:SaturationAdjustmentYellow="-35"\n      crs:SaturationAdjustmentGreen="-75"\n      crs:SaturationAdjustmentAqua="-70"\n      crs:SaturationAdjustmentBlue="-80"\n      crs:SaturationAdjustmentPurple="-85"\n      crs:SaturationAdjustmentMagenta="+25"\n      crs:LuminanceAdjustmentRed="0"\n      crs:LuminanceAdjustmentOrange="-15"\n      crs:LuminanceAdjustmentYellow="-10"\n      crs:LuminanceAdjustmentGreen="-15"\n      crs:LuminanceAdjustmentAqua="+10"\n      crs:LuminanceAdjustmentBlue="+5"\n      crs:LuminanceAdjustmentPurple="+5"\n      crs:LuminanceAdjustmentMagenta="+15"\n      crs:SplitToningShadowHue="65"\n      crs:SplitToningShadowSaturation="5"\n      crs:SplitToningHighlightHue="45"\n      crs:SplitToningHighlightSaturation="30"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="0"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="0"\n      crs:RedSaturation="0"\n      crs:GreenHue="0"\n      crs:GreenSaturation="0"\n      crs:BlueHue="0"\n      crs:BlueSaturation="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>6, 0</rdf:li>\n       <rdf:li>101, 104</rdf:li>\n       <rdf:li>193, 205</rdf:li>\n       <rdf:li>255, 247</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>38, 22</rdf:li>\n       <rdf:li>118, 127</rdf:li>\n       <rdf:li>193, 202</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>38, 22</rdf:li>\n       <rdf:li>117, 125</rdf:li>\n       <rdf:li>193, 202</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>42, 23</rdf:li>\n       <rdf:li>120, 125</rdf:li>\n       <rdf:li>194, 202</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'VSCO IV');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmVSCO_4();
