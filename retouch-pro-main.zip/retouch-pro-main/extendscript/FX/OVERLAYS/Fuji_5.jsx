$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Fujifilm V ==============
//
function FilmFuji_5() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Hi12'), 25);
    desc1.putInteger(cTID('Sh12'), 25);
    desc1.putInteger(cTID('Wh12'), -30);
    desc1.putInteger(cTID('Bk12'), -5);
    desc1.putInteger(cTID('Strt'), -10);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 24);
    desc1.putInteger(cTID('PC_2'), 51);
    desc1.putInteger(cTID('PC_3'), 76);
    desc1.putInteger(cTID('HA_R'), -10);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), -5);
    desc1.putInteger(cTID('HA_G'), 10);
    desc1.putInteger(cTID('HA_A'), 10);
    desc1.putInteger(cTID('HA_B'), 10);
    desc1.putInteger(cTID('HA_P'), 15);
    desc1.putInteger(cTID('HA_M'), 5);
    desc1.putInteger(cTID('SA_R'), -5);
    desc1.putInteger(cTID('SA_O'), -10);
    desc1.putInteger(cTID('SA_Y'), -10);
    desc1.putInteger(cTID('SA_G'), -10);
    desc1.putInteger(cTID('SA_A'), -10);
    desc1.putInteger(cTID('SA_B'), -75);
    desc1.putInteger(cTID('SA_P'), -50);
    desc1.putInteger(cTID('SA_M'), 0);
    desc1.putInteger(cTID('LA_R'), -25);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), -20);
    desc1.putInteger(cTID('LA_G'), -10);
    desc1.putInteger(cTID('LA_A'), -5);
    desc1.putInteger(cTID('LA_B'), -15);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 5);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 15);
    desc1.putInteger(cTID('RSat'), 5);
    desc1.putInteger(cTID('GHue'), -15);
    desc1.putInteger(cTID('GSat'), -5);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), -10);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(21);
    list1.putInteger(22);
    list1.putInteger(37);
    list1.putInteger(48);
    list1.putInteger(58);
    list1.putInteger(113);
    list1.putInteger(114);
    list1.putInteger(206);
    list1.putInteger(183);
    list1.putInteger(255);
    list1.putInteger(226);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(39);
    list2.putInteger(24);
    list2.putInteger(66);
    list2.putInteger(54);
    list2.putInteger(97);
    list2.putInteger(108);
    list2.putInteger(162);
    list2.putInteger(179);
    list2.putInteger(212);
    list2.putInteger(220);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(36);
    list3.putInteger(22);
    list3.putInteger(74);
    list3.putInteger(65);
    list3.putInteger(93);
    list3.putInteger(101);
    list3.putInteger(112);
    list3.putInteger(129);
    list3.putInteger(155);
    list3.putInteger(173);
    list3.putInteger(214);
    list3.putInteger(222);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(38);
    list4.putInteger(21);
    list4.putInteger(74);
    list4.putInteger(60);
    list4.putInteger(94);
    list4.putInteger(97);
    list4.putInteger(121);
    list4.putInteger(138);
    list4.putInteger(171);
    list4.putInteger(189);
    list4.putInteger(212);
    list4.putInteger(223);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="Fujifilm V"\n     crs:Amount="1"\n     crs:UUID="27C5288F29662F3F97DD12F8284D3998"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="0"\n      crs:Highlights2012="+25"\n      crs:Shadows2012="+25"\n      crs:Whites2012="-30"\n      crs:Blacks2012="-5"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="-10"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="24"\n      crs:ParametricMidtoneSplit="51"\n      crs:ParametricHighlightSplit="76"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:HueAdjustmentRed="-10"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="-5"\n      crs:HueAdjustmentGreen="+10"\n      crs:HueAdjustmentAqua="+10"\n      crs:HueAdjustmentBlue="+10"\n      crs:HueAdjustmentPurple="+15"\n      crs:HueAdjustmentMagenta="+5"\n      crs:SaturationAdjustmentRed="-5"\n      crs:SaturationAdjustmentOrange="-10"\n      crs:SaturationAdjustmentYellow="-10"\n      crs:SaturationAdjustmentGreen="-10"\n      crs:SaturationAdjustmentAqua="-10"\n      crs:SaturationAdjustmentBlue="-75"\n      crs:SaturationAdjustmentPurple="-50"\n      crs:SaturationAdjustmentMagenta="0"\n      crs:LuminanceAdjustmentRed="-25"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="-20"\n      crs:LuminanceAdjustmentGreen="-10"\n      crs:LuminanceAdjustmentAqua="-5"\n      crs:LuminanceAdjustmentBlue="-15"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="+5"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="0"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+15"\n      crs:RedSaturation="+5"\n      crs:GreenHue="-15"\n      crs:GreenSaturation="-5"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="-10"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 21</rdf:li>\n       <rdf:li>22, 37</rdf:li>\n       <rdf:li>48, 58</rdf:li>\n       <rdf:li>113, 114</rdf:li>\n       <rdf:li>206, 183</rdf:li>\n       <rdf:li>255, 226</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 24</rdf:li>\n       <rdf:li>66, 54</rdf:li>\n       <rdf:li>97, 108</rdf:li>\n       <rdf:li>162, 179</rdf:li>\n       <rdf:li>212, 220</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>36, 22</rdf:li>\n       <rdf:li>74, 65</rdf:li>\n       <rdf:li>93, 101</rdf:li>\n       <rdf:li>112, 129</rdf:li>\n       <rdf:li>155, 173</rdf:li>\n       <rdf:li>214, 222</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>38, 21</rdf:li>\n       <rdf:li>74, 60</rdf:li>\n       <rdf:li>94, 97</rdf:li>\n       <rdf:li>121, 138</rdf:li>\n       <rdf:li>171, 189</rdf:li>\n       <rdf:li>212, 223</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Fujifilm V');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmFuji_5();
