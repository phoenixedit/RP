$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Fujifilm II ==============
//
function FilmFuji_2() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), 10);
    desc1.putInteger(cTID('Hi12'), -40);
    desc1.putInteger(cTID('Sh12'), 20);
    desc1.putInteger(cTID('Wh12'), -30);
    desc1.putInteger(cTID('Bk12'), 65);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 24);
    desc1.putInteger(cTID('PC_2'), 51);
    desc1.putInteger(cTID('PC_3'), 76);
    desc1.putInteger(cTID('HA_R'), 5);
    desc1.putInteger(cTID('HA_O'), 10);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), 15);
    desc1.putInteger(cTID('HA_A'), -20);
    desc1.putInteger(cTID('HA_B'), 10);
    desc1.putInteger(cTID('HA_P'), 40);
    desc1.putInteger(cTID('HA_M'), -10);
    desc1.putInteger(cTID('SA_R'), -5);
    desc1.putInteger(cTID('SA_O'), -20);
    desc1.putInteger(cTID('SA_Y'), 25);
    desc1.putInteger(cTID('SA_G'), 0);
    desc1.putInteger(cTID('SA_A'), -15);
    desc1.putInteger(cTID('SA_B'), -10);
    desc1.putInteger(cTID('SA_P'), 0);
    desc1.putInteger(cTID('SA_M'), 10);
    desc1.putInteger(cTID('LA_R'), -10);
    desc1.putInteger(cTID('LA_O'), 5);
    desc1.putInteger(cTID('LA_Y'), -10);
    desc1.putInteger(cTID('LA_G'), -20);
    desc1.putInteger(cTID('LA_A'), 0);
    desc1.putInteger(cTID('LA_B'), -10);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), -10);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 35);
    desc1.putInteger(cTID('RSat'), 25);
    desc1.putInteger(cTID('GHue'), 30);
    desc1.putInteger(cTID('GSat'), 25);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), 15);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(33);
    list1.putInteger(36);
    list1.putInteger(71);
    list1.putInteger(77);
    list1.putInteger(123);
    list1.putInteger(128);
    list1.putInteger(182);
    list1.putInteger(180);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(35);
    list2.putInteger(20);
    list2.putInteger(89);
    list2.putInteger(88);
    list2.putInteger(150);
    list2.putInteger(168);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(35);
    list3.putInteger(25);
    list3.putInteger(88);
    list3.putInteger(94);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(32);
    list4.putInteger(22);
    list4.putInteger(108);
    list4.putInteger(118);
    list4.putInteger(156);
    list4.putInteger(171);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="Fujifilm II"\n     crs:Amount="1"\n     crs:UUID="ACB6846716596560A11719E945F1D3C1"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+10"\n      crs:Highlights2012="-40"\n      crs:Shadows2012="+20"\n      crs:Whites2012="-30"\n      crs:Blacks2012="+65"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="24"\n      crs:ParametricMidtoneSplit="51"\n      crs:ParametricHighlightSplit="76"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:HueAdjustmentRed="+5"\n      crs:HueAdjustmentOrange="+10"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="+15"\n      crs:HueAdjustmentAqua="-20"\n      crs:HueAdjustmentBlue="+10"\n      crs:HueAdjustmentPurple="+40"\n      crs:HueAdjustmentMagenta="-10"\n      crs:SaturationAdjustmentRed="-5"\n      crs:SaturationAdjustmentOrange="-20"\n      crs:SaturationAdjustmentYellow="+25"\n      crs:SaturationAdjustmentGreen="0"\n      crs:SaturationAdjustmentAqua="-15"\n      crs:SaturationAdjustmentBlue="-10"\n      crs:SaturationAdjustmentPurple="0"\n      crs:SaturationAdjustmentMagenta="+10"\n      crs:LuminanceAdjustmentRed="-10"\n      crs:LuminanceAdjustmentOrange="+5"\n      crs:LuminanceAdjustmentYellow="-10"\n      crs:LuminanceAdjustmentGreen="-20"\n      crs:LuminanceAdjustmentAqua="0"\n      crs:LuminanceAdjustmentBlue="-10"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="-10"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="0"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+35"\n      crs:RedSaturation="+25"\n      crs:GreenHue="+30"\n      crs:GreenSaturation="+25"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="+15"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>33, 36</rdf:li>\n       <rdf:li>71, 77</rdf:li>\n       <rdf:li>123, 128</rdf:li>\n       <rdf:li>182, 180</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>35, 20</rdf:li>\n       <rdf:li>89, 88</rdf:li>\n       <rdf:li>150, 168</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>35, 25</rdf:li>\n       <rdf:li>88, 94</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>32, 22</rdf:li>\n       <rdf:li>108, 118</rdf:li>\n       <rdf:li>156, 171</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Fujifilm II');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmFuji_2();
