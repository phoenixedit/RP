$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Kodak-Z III ==============
//
function FilmKodak_Z_3() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), -10);
    desc1.putInteger(cTID('Hi12'), -10);
    desc1.putInteger(cTID('Sh12'), 15);
    desc1.putInteger(cTID('Wh12'), -15);
    desc1.putInteger(cTID('Bk12'), 10);
    desc1.putInteger(cTID('Vibr'), 5);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), 25);
    desc1.putInteger(cTID('HA_O'), -5);
    desc1.putInteger(cTID('HA_Y'), 10);
    desc1.putInteger(cTID('HA_G'), -25);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), 0);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 0);
    desc1.putInteger(cTID('SA_R'), -10);
    desc1.putInteger(cTID('SA_O'), -5);
    desc1.putInteger(cTID('SA_Y'), -35);
    desc1.putInteger(cTID('SA_G'), -30);
    desc1.putInteger(cTID('SA_A'), -5);
    desc1.putInteger(cTID('SA_B'), -15);
    desc1.putInteger(cTID('SA_P'), 0);
    desc1.putInteger(cTID('SA_M'), 0);
    desc1.putInteger(cTID('LA_R'), -25);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), -15);
    desc1.putInteger(cTID('LA_G'), -10);
    desc1.putInteger(cTID('LA_A'), 0);
    desc1.putInteger(cTID('LA_B'), -15);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('GRNA'), 40);
    desc1.putInteger(cTID('GRNS'), 35);
    desc1.putInteger(cTID('GRNF'), 50);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 35);
    desc1.putInteger(cTID('RSat'), 5);
    desc1.putInteger(cTID('GHue'), 50);
    desc1.putInteger(cTID('GSat'), -25);
    desc1.putInteger(cTID('BHue'), -10);
    desc1.putInteger(cTID('BSat'), -10);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(23);
    list1.putInteger(48);
    list1.putInteger(59);
    list1.putInteger(110);
    list1.putInteger(120);
    list1.putInteger(184);
    list1.putInteger(190);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(39);
    list2.putInteger(13);
    list2.putInteger(87);
    list2.putInteger(60);
    list2.putInteger(127);
    list2.putInteger(120);
    list2.putInteger(197);
    list2.putInteger(206);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(39);
    list3.putInteger(13);
    list3.putInteger(88);
    list3.putInteger(64);
    list3.putInteger(127);
    list3.putInteger(121);
    list3.putInteger(198);
    list3.putInteger(205);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(38);
    list4.putInteger(17);
    list4.putInteger(86);
    list4.putInteger(65);
    list4.putInteger(127);
    list4.putInteger(121);
    list4.putInteger(199);
    list4.putInteger(203);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="Kodak-Z III"\n     crs:Amount="1"\n     crs:UUID="3F4FC8AEF6E6EB5449D2E7B13B4CC137"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="-10"\n      crs:Highlights2012="-10"\n      crs:Shadows2012="+15"\n      crs:Whites2012="-15"\n      crs:Blacks2012="+10"\n      crs:Clarity2012="0"\n      crs:Vibrance="+5"\n      crs:Saturation="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="+25"\n      crs:HueAdjustmentOrange="-5"\n      crs:HueAdjustmentYellow="+10"\n      crs:HueAdjustmentGreen="-25"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="0"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="0"\n      crs:SaturationAdjustmentRed="-10"\n      crs:SaturationAdjustmentOrange="-5"\n      crs:SaturationAdjustmentYellow="-35"\n      crs:SaturationAdjustmentGreen="-30"\n      crs:SaturationAdjustmentAqua="-5"\n      crs:SaturationAdjustmentBlue="-15"\n      crs:SaturationAdjustmentPurple="0"\n      crs:SaturationAdjustmentMagenta="0"\n      crs:LuminanceAdjustmentRed="-25"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="-15"\n      crs:LuminanceAdjustmentGreen="-10"\n      crs:LuminanceAdjustmentAqua="0"\n      crs:LuminanceAdjustmentBlue="-15"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="40"\n      crs:GrainSize="35"\n      crs:GrainFrequency="50"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+35"\n      crs:RedSaturation="+5"\n      crs:GreenHue="+50"\n      crs:GreenSaturation="-25"\n      crs:BlueHue="-10"\n      crs:BlueSaturation="-10"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 23</rdf:li>\n       <rdf:li>48, 59</rdf:li>\n       <rdf:li>110, 120</rdf:li>\n       <rdf:li>184, 190</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 13</rdf:li>\n       <rdf:li>87, 60</rdf:li>\n       <rdf:li>127, 120</rdf:li>\n       <rdf:li>197, 206</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 13</rdf:li>\n       <rdf:li>88, 64</rdf:li>\n       <rdf:li>127, 121</rdf:li>\n       <rdf:li>198, 205</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>38, 17</rdf:li>\n       <rdf:li>86, 65</rdf:li>\n       <rdf:li>127, 121</rdf:li>\n       <rdf:li>199, 203</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Kodak-Z III');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmKodak_Z_3();
