$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== VSCO II ==============
//
function FilmVSCO_2() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Sh12'), 35);
    desc1.putInteger(cTID('Wh12'), -20);
    desc1.putInteger(cTID('Bk12'), 25);
    desc1.putInteger(cTID('Cl12'), -5);
    desc1.putInteger(cTID('Strt'), -5);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 20);
    desc1.putInteger(cTID('PC_2'), 48);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putInteger(cTID('HA_R'), 5);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), 10);
    desc1.putInteger(cTID('HA_A'), 10);
    desc1.putInteger(cTID('HA_B'), 0);
    desc1.putInteger(cTID('HA_P'), 20);
    desc1.putInteger(cTID('HA_M'), 30);
    desc1.putInteger(cTID('SA_R'), -20);
    desc1.putInteger(cTID('SA_O'), -25);
    desc1.putInteger(cTID('SA_Y'), -10);
    desc1.putInteger(cTID('SA_G'), -35);
    desc1.putInteger(cTID('SA_A'), -35);
    desc1.putInteger(cTID('SA_B'), -30);
    desc1.putInteger(cTID('SA_P'), -45);
    desc1.putInteger(cTID('SA_M'), -45);
    desc1.putInteger(cTID('LA_R'), 5);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), -25);
    desc1.putInteger(cTID('LA_G'), 0);
    desc1.putInteger(cTID('LA_A'), 0);
    desc1.putInteger(cTID('LA_B'), -25);
    desc1.putInteger(cTID('LA_P'), -15);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('GRNA'), 20);
    desc1.putInteger(cTID('GRNS'), 20);
    desc1.putInteger(cTID('GRNF'), 65);
    desc1.putInteger(cTID('BlkB'), -5);
    desc1.putInteger(cTID('RHue'), 25);
    desc1.putInteger(cTID('RSat'), 40);
    desc1.putInteger(cTID('GHue'), 35);
    desc1.putInteger(cTID('GSat'), 5);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), -5);
    desc1.putInteger(cTID('TMMs'), 0);
    desc1.putInteger(cTID('PGTM'), 0);
    desc1.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(6);
    list1.putInteger(62);
    list1.putInteger(57);
    list1.putInteger(188);
    list1.putInteger(189);
    list1.putInteger(255);
    list1.putInteger(245);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(40);
    list2.putInteger(9);
    list2.putInteger(76);
    list2.putInteger(46);
    list2.putInteger(126);
    list2.putInteger(122);
    list2.putInteger(182);
    list2.putInteger(204);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(36);
    list3.putInteger(10);
    list3.putInteger(76);
    list3.putInteger(46);
    list3.putInteger(124);
    list3.putInteger(122);
    list3.putInteger(181);
    list3.putInteger(201);
    list3.putInteger(219);
    list3.putInteger(230);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(36);
    list4.putInteger(10);
    list4.putInteger(76);
    list4.putInteger(46);
    list4.putInteger(122);
    list4.putInteger(118);
    list4.putInteger(183);
    list4.putInteger(206);
    list4.putInteger(222);
    list4.putInteger(235);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="VSCO II"\n     crs:Amount="1"\n     crs:UUID="12DD1940D41852141C49499BD7C2BE6A"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="0"\n      crs:Highlights2012="0"\n      crs:Shadows2012="+35"\n      crs:Whites2012="-20"\n      crs:Blacks2012="+25"\n      crs:Clarity2012="-5"\n      crs:Vibrance="0"\n      crs:Saturation="-5"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="20"\n      crs:ParametricMidtoneSplit="48"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:HueAdjustmentRed="+5"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="+10"\n      crs:HueAdjustmentAqua="+10"\n      crs:HueAdjustmentBlue="0"\n      crs:HueAdjustmentPurple="+20"\n      crs:HueAdjustmentMagenta="+30"\n      crs:SaturationAdjustmentRed="-20"\n      crs:SaturationAdjustmentOrange="-25"\n      crs:SaturationAdjustmentYellow="-10"\n      crs:SaturationAdjustmentGreen="-35"\n      crs:SaturationAdjustmentAqua="-35"\n      crs:SaturationAdjustmentBlue="-30"\n      crs:SaturationAdjustmentPurple="-45"\n      crs:SaturationAdjustmentMagenta="-45"\n      crs:LuminanceAdjustmentRed="+5"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="-25"\n      crs:LuminanceAdjustmentGreen="0"\n      crs:LuminanceAdjustmentAqua="0"\n      crs:LuminanceAdjustmentBlue="-25"\n      crs:LuminanceAdjustmentPurple="-15"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="20"\n      crs:GrainSize="20"\n      crs:GrainFrequency="65"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="-5"\n      crs:RedHue="+25"\n      crs:RedSaturation="+40"\n      crs:GreenHue="+35"\n      crs:GreenSaturation="+5"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="-5"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 6</rdf:li>\n       <rdf:li>62, 57</rdf:li>\n       <rdf:li>188, 189</rdf:li>\n       <rdf:li>255, 245</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>40, 9</rdf:li>\n       <rdf:li>76, 46</rdf:li>\n       <rdf:li>126, 122</rdf:li>\n       <rdf:li>182, 204</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>36, 10</rdf:li>\n       <rdf:li>76, 46</rdf:li>\n       <rdf:li>124, 122</rdf:li>\n       <rdf:li>181, 201</rdf:li>\n       <rdf:li>219, 230</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>36, 10</rdf:li>\n       <rdf:li>76, 46</rdf:li>\n       <rdf:li>122, 118</rdf:li>\n       <rdf:li>183, 206</rdf:li>\n       <rdf:li>222, 235</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'VSCO II');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmVSCO_2();
