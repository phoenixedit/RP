$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== VSCO I ==============
//
function FilmVSCO_1() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), 15);
    desc1.putInteger(cTID('Sh12'), 60);
    desc1.putInteger(cTID('Wh12'), -15);
    desc1.putInteger(cTID('Bk12'), 80);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 14);
    desc1.putInteger(cTID('PC_2'), 60);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putInteger(cTID('HA_R'), 10);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), -5);
    desc1.putInteger(cTID('HA_G'), 15);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), 10);
    desc1.putInteger(cTID('HA_P'), 30);
    desc1.putInteger(cTID('HA_M'), 15);
    desc1.putInteger(cTID('SA_R'), -10);
    desc1.putInteger(cTID('SA_O'), -5);
    desc1.putInteger(cTID('SA_Y'), 0);
    desc1.putInteger(cTID('SA_G'), -30);
    desc1.putInteger(cTID('SA_A'), 0);
    desc1.putInteger(cTID('SA_B'), -95);
    desc1.putInteger(cTID('SA_P'), -100);
    desc1.putInteger(cTID('SA_M'), -20);
    desc1.putInteger(cTID('LA_R'), -15);
    desc1.putInteger(cTID('LA_O'), -10);
    desc1.putInteger(cTID('LA_Y'), 0);
    desc1.putInteger(cTID('LA_G'), -25);
    desc1.putInteger(cTID('LA_A'), -15);
    desc1.putInteger(cTID('LA_B'), 0);
    desc1.putInteger(cTID('LA_P'), -10);
    desc1.putInteger(cTID('LA_M'), 5);
    desc1.putInteger(cTID('GRNA'), 15);
    desc1.putInteger(cTID('GRNS'), 25);
    desc1.putInteger(cTID('GRNF'), 50);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 10);
    desc1.putInteger(cTID('RSat'), 5);
    desc1.putInteger(cTID('GHue'), 10);
    desc1.putInteger(cTID('GSat'), -10);
    desc1.putInteger(cTID('BHue'), -15);
    desc1.putInteger(cTID('BSat'), 25);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(10);
    list1.putInteger(38);
    list1.putInteger(36);
    list1.putInteger(96);
    list1.putInteger(80);
    list1.putInteger(155);
    list1.putInteger(140);
    list1.putInteger(211);
    list1.putInteger(197);
    list1.putInteger(255);
    list1.putInteger(228);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(47);
    list2.putInteger(19);
    list2.putInteger(115);
    list2.putInteger(122);
    list2.putInteger(178);
    list2.putInteger(203);
    list2.putInteger(235);
    list2.putInteger(242);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(45);
    list3.putInteger(18);
    list3.putInteger(114);
    list3.putInteger(121);
    list3.putInteger(174);
    list3.putInteger(203);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(42);
    list4.putInteger(21);
    list4.putInteger(115);
    list4.putInteger(121);
    list4.putInteger(177);
    list4.putInteger(205);
    list4.putInteger(215);
    list4.putInteger(235);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="VSCO I"\n     crs:Amount="1"\n     crs:UUID="5E8CB49C245BD84B7A0BF9DBD181AF18"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+15"\n      crs:Highlights2012="0"\n      crs:Shadows2012="+60"\n      crs:Whites2012="-15"\n      crs:Blacks2012="+80"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="14"\n      crs:ParametricMidtoneSplit="60"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:HueAdjustmentRed="+10"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="-5"\n      crs:HueAdjustmentGreen="+15"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="+10"\n      crs:HueAdjustmentPurple="+30"\n      crs:HueAdjustmentMagenta="+15"\n      crs:SaturationAdjustmentRed="-10"\n      crs:SaturationAdjustmentOrange="-5"\n      crs:SaturationAdjustmentYellow="0"\n      crs:SaturationAdjustmentGreen="-30"\n      crs:SaturationAdjustmentAqua="0"\n      crs:SaturationAdjustmentBlue="-95"\n      crs:SaturationAdjustmentPurple="-100"\n      crs:SaturationAdjustmentMagenta="-20"\n      crs:LuminanceAdjustmentRed="-15"\n      crs:LuminanceAdjustmentOrange="-10"\n      crs:LuminanceAdjustmentYellow="0"\n      crs:LuminanceAdjustmentGreen="-25"\n      crs:LuminanceAdjustmentAqua="-15"\n      crs:LuminanceAdjustmentBlue="0"\n      crs:LuminanceAdjustmentPurple="-10"\n      crs:LuminanceAdjustmentMagenta="+5"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="220"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="50"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="15"\n      crs:GrainSize="25"\n      crs:GrainFrequency="50"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+10"\n      crs:RedSaturation="+5"\n      crs:GreenHue="+10"\n      crs:GreenSaturation="-10"\n      crs:BlueHue="-15"\n      crs:BlueSaturation="+25"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 10</rdf:li>\n       <rdf:li>38, 36</rdf:li>\n       <rdf:li>96, 80</rdf:li>\n       <rdf:li>155, 140</rdf:li>\n       <rdf:li>211, 197</rdf:li>\n       <rdf:li>255, 228</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>47, 19</rdf:li>\n       <rdf:li>115, 122</rdf:li>\n       <rdf:li>178, 203</rdf:li>\n       <rdf:li>235, 242</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>45, 18</rdf:li>\n       <rdf:li>114, 121</rdf:li>\n       <rdf:li>174, 203</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>42, 21</rdf:li>\n       <rdf:li>115, 121</rdf:li>\n       <rdf:li>177, 205</rdf:li>\n       <rdf:li>215, 235</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'VSCO I');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmVSCO_1();
