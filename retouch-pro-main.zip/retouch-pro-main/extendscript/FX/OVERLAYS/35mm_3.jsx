$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== 35mm Film III ==============
//
function Film35mm_3() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), 1);
    desc1.putDouble(cTID('Ex12'), -0.25);
    desc1.putInteger(cTID('Cr12'), -40);
    desc1.putInteger(cTID('Hi12'), -50);
    desc1.putInteger(cTID('Sh12'), 30);
    desc1.putInteger(cTID('Wh12'), 20);
    desc1.putInteger(cTID('Bk12'), 15);
    desc1.putInteger(cTID('Cl12'), 15);
    desc1.putInteger(cTID('Vibr'), 30);
    desc1.putInteger(cTID('Strt'), -15);
    desc1.putInteger(cTID('PC_S'), 20);
    desc1.putInteger(cTID('PC_D'), 5);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 14);
    desc1.putInteger(cTID('PC_2'), 43);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putInteger(cTID('Shrp'), 10);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('LNR '), 5);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), -10);
    desc1.putInteger(cTID('HA_O'), -5);
    desc1.putInteger(cTID('HA_Y'), -5);
    desc1.putInteger(cTID('HA_G'), -15);
    desc1.putInteger(cTID('HA_A'), 15);
    desc1.putInteger(cTID('HA_B'), -10);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 20);
    desc1.putInteger(cTID('SA_R'), -20);
    desc1.putInteger(cTID('SA_O'), -40);
    desc1.putInteger(cTID('SA_Y'), -45);
    desc1.putInteger(cTID('SA_G'), -80);
    desc1.putInteger(cTID('SA_A'), -35);
    desc1.putInteger(cTID('SA_B'), -5);
    desc1.putInteger(cTID('SA_P'), -100);
    desc1.putInteger(cTID('SA_M'), -60);
    desc1.putInteger(cTID('LA_R'), 5);
    desc1.putInteger(cTID('LA_O'), -25);
    desc1.putInteger(cTID('LA_Y'), -10);
    desc1.putInteger(cTID('LA_G'), -55);
    desc1.putInteger(cTID('LA_A'), -5);
    desc1.putInteger(cTID('LA_B'), 50);
    desc1.putInteger(cTID('LA_P'), 15);
    desc1.putInteger(cTID('LA_M'), 25);
    desc1.putInteger(cTID('STSH'), 50);
    desc1.putInteger(cTID('STSS'), 15);
    desc1.putInteger(cTID('STHH'), 215);
    desc1.putInteger(cTID('STHS'), 10);
    desc1.putInteger(cTID('STB '), 5);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    desc1.putInteger(cTID('GRNA'), 35);
    desc1.putInteger(cTID('GRNS'), 35);
    desc1.putInteger(cTID('GRNF'), 40);
    desc1.putInteger(cTID('BlkB'), -5);
    desc1.putInteger(cTID('RHue'), 30);
    desc1.putInteger(cTID('RSat'), 20);
    desc1.putInteger(cTID('GHue'), 75);
    desc1.putInteger(cTID('GSat'), 0);
    desc1.putInteger(cTID('BHue'), -5);
    desc1.putInteger(cTID('BSat'), 25);
    desc1.putInteger(cTID('TMMs'), 0);
    desc1.putInteger(cTID('PGTM'), 0);
    desc1.putInteger(cTID('RGBt'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(30);
    list1.putInteger(48);
    list1.putInteger(56);
    list1.putInteger(90);
    list1.putInteger(89);
    list1.putInteger(128);
    list1.putInteger(128);
    list1.putInteger(180);
    list1.putInteger(190);
    list1.putInteger(216);
    list1.putInteger(222);
    list1.putInteger(255);
    list1.putInteger(250);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(20);
    list2.putInteger(3);
    list2.putInteger(60);
    list2.putInteger(20);
    list2.putInteger(119);
    list2.putInteger(121);
    list2.putInteger(177);
    list2.putInteger(202);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(53);
    list3.putInteger(21);
    list3.putInteger(120);
    list3.putInteger(125);
    list3.putInteger(179);
    list3.putInteger(205);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(43);
    list4.putInteger(22);
    list4.putInteger(121);
    list4.putInteger(122);
    list4.putInteger(175);
    list4.putInteger(200);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="35mm Film III"\n     crs:Amount="1"\n     crs:UUID="A520B59DD121995F33339621135EE44D"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="+1"\n      crs:Exposure2012="-0.25"\n      crs:Contrast2012="-40"\n      crs:Highlights2012="-50"\n      crs:Shadows2012="+30"\n      crs:Whites2012="+20"\n      crs:Blacks2012="+15"\n      crs:Clarity2012="+15"\n      crs:Vibrance="+30"\n      crs:Saturation="-15"\n      crs:ParametricShadows="+20"\n      crs:ParametricDarks="+5"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="14"\n      crs:ParametricMidtoneSplit="43"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="10"\n      crs:SharpenRadius="+1.0"\n      crs:SharpenDetail="25"\n      crs:SharpenEdgeMasking="0"\n      crs:LuminanceSmoothing="5"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="-10"\n      crs:HueAdjustmentOrange="-5"\n      crs:HueAdjustmentYellow="-5"\n      crs:HueAdjustmentGreen="-15"\n      crs:HueAdjustmentAqua="+15"\n      crs:HueAdjustmentBlue="-10"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="+20"\n      crs:SaturationAdjustmentRed="-20"\n      crs:SaturationAdjustmentOrange="-40"\n      crs:SaturationAdjustmentYellow="-45"\n      crs:SaturationAdjustmentGreen="-80"\n      crs:SaturationAdjustmentAqua="-35"\n      crs:SaturationAdjustmentBlue="-5"\n      crs:SaturationAdjustmentPurple="-100"\n      crs:SaturationAdjustmentMagenta="-60"\n      crs:LuminanceAdjustmentRed="+5"\n      crs:LuminanceAdjustmentOrange="-25"\n      crs:LuminanceAdjustmentYellow="-10"\n      crs:LuminanceAdjustmentGreen="-55"\n      crs:LuminanceAdjustmentAqua="-5"\n      crs:LuminanceAdjustmentBlue="+50"\n      crs:LuminanceAdjustmentPurple="+15"\n      crs:LuminanceAdjustmentMagenta="+25"\n      crs:SplitToningShadowHue="50"\n      crs:SplitToningShadowSaturation="15"\n      crs:SplitToningHighlightHue="215"\n      crs:SplitToningHighlightSaturation="10"\n      crs:SplitToningBalance="+5"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="35"\n      crs:GrainSize="35"\n      crs:GrainFrequency="40"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="-5"\n      crs:RedHue="+30"\n      crs:RedSaturation="+20"\n      crs:GreenHue="+75"\n      crs:GreenSaturation="0"\n      crs:BlueHue="-5"\n      crs:BlueSaturation="+25"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 30</rdf:li>\n       <rdf:li>48, 56</rdf:li>\n       <rdf:li>90, 89</rdf:li>\n       <rdf:li>128, 128</rdf:li>\n       <rdf:li>180, 190</rdf:li>\n       <rdf:li>216, 222</rdf:li>\n       <rdf:li>255, 250</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>20, 3</rdf:li>\n       <rdf:li>60, 20</rdf:li>\n       <rdf:li>119, 121</rdf:li>\n       <rdf:li>177, 202</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>53, 21</rdf:li>\n       <rdf:li>120, 125</rdf:li>\n       <rdf:li>179, 205</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>121, 122</rdf:li>\n       <rdf:li>175, 200</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), '35mm Film III');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

Film35mm_3();
