$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Kodak-Z V ==============
//
function FilmKodak_Z_5() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), -25);
    desc1.putInteger(cTID('Hi12'), -70);
    desc1.putInteger(cTID('Sh12'), 35);
    desc1.putInteger(cTID('Wh12'), -25);
    desc1.putInteger(cTID('Bk12'), 50);
    desc1.putInteger(cTID('PC_S'), -5);
    desc1.putInteger(cTID('PC_D'), 10);
    desc1.putInteger(cTID('PC_L'), 10);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 25);
    desc1.putInteger(cTID('PC_2'), 50);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), -15);
    desc1.putInteger(cTID('HA_O'), 10);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), -5);
    desc1.putInteger(cTID('HA_A'), 35);
    desc1.putInteger(cTID('HA_B'), -15);
    desc1.putInteger(cTID('HA_P'), -25);
    desc1.putInteger(cTID('HA_M'), 25);
    desc1.putInteger(cTID('SA_R'), -30);
    desc1.putInteger(cTID('SA_O'), -35);
    desc1.putInteger(cTID('SA_Y'), -25);
    desc1.putInteger(cTID('SA_G'), -35);
    desc1.putInteger(cTID('SA_A'), -60);
    desc1.putInteger(cTID('SA_B'), -100);
    desc1.putInteger(cTID('SA_P'), 0);
    desc1.putInteger(cTID('SA_M'), -25);
    desc1.putInteger(cTID('LA_R'), -10);
    desc1.putInteger(cTID('LA_O'), -10);
    desc1.putInteger(cTID('LA_Y'), 15);
    desc1.putInteger(cTID('LA_G'), -15);
    desc1.putInteger(cTID('LA_A'), -5);
    desc1.putInteger(cTID('LA_B'), 5);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('STSH'), 75);
    desc1.putInteger(cTID('STSS'), 15);
    desc1.putInteger(cTID('STHH'), 175);
    desc1.putInteger(cTID('STHS'), 0);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    desc1.putInteger(cTID('GRNA'), 40);
    desc1.putInteger(cTID('GRNS'), 60);
    desc1.putInteger(cTID('GRNF'), 50);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 15);
    desc1.putInteger(cTID('RSat'), 30);
    desc1.putInteger(cTID('GHue'), 35);
    desc1.putInteger(cTID('GSat'), 10);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), 30);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(45);
    list1.putInteger(54);
    list1.putInteger(62);
    list1.putInteger(157);
    list1.putInteger(153);
    list1.putInteger(218);
    list1.putInteger(224);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(45);
    list2.putInteger(15);
    list2.putInteger(75);
    list2.putInteger(55);
    list2.putInteger(99);
    list2.putInteger(95);
    list2.putInteger(170);
    list2.putInteger(180);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(33);
    list3.putInteger(8);
    list3.putInteger(78);
    list3.putInteger(63);
    list3.putInteger(102);
    list3.putInteger(103);
    list3.putInteger(172);
    list3.putInteger(186);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(39);
    list4.putInteger(9);
    list4.putInteger(72);
    list4.putInteger(51);
    list4.putInteger(101);
    list4.putInteger(101);
    list4.putInteger(161);
    list4.putInteger(181);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="Kodak-Z V"\n     crs:Amount="1"\n     crs:UUID="B36508843F0D44B3245C15C5B19A958F"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="-25"\n      crs:Highlights2012="-70"\n      crs:Shadows2012="+35"\n      crs:Whites2012="-25"\n      crs:Blacks2012="+50"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="-5"\n      crs:ParametricDarks="+10"\n      crs:ParametricLights="+10"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="-15"\n      crs:HueAdjustmentOrange="+10"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="-5"\n      crs:HueAdjustmentAqua="+35"\n      crs:HueAdjustmentBlue="-15"\n      crs:HueAdjustmentPurple="-25"\n      crs:HueAdjustmentMagenta="+25"\n      crs:SaturationAdjustmentRed="-30"\n      crs:SaturationAdjustmentOrange="-35"\n      crs:SaturationAdjustmentYellow="-25"\n      crs:SaturationAdjustmentGreen="-35"\n      crs:SaturationAdjustmentAqua="-60"\n      crs:SaturationAdjustmentBlue="-100"\n      crs:SaturationAdjustmentPurple="0"\n      crs:SaturationAdjustmentMagenta="-25"\n      crs:LuminanceAdjustmentRed="-10"\n      crs:LuminanceAdjustmentOrange="-10"\n      crs:LuminanceAdjustmentYellow="+15"\n      crs:LuminanceAdjustmentGreen="-15"\n      crs:LuminanceAdjustmentAqua="-5"\n      crs:LuminanceAdjustmentBlue="+5"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="75"\n      crs:SplitToningShadowSaturation="15"\n      crs:SplitToningHighlightHue="175"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="40"\n      crs:GrainSize="60"\n      crs:GrainFrequency="50"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+15"\n      crs:RedSaturation="+30"\n      crs:GreenHue="+35"\n      crs:GreenSaturation="+10"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="+30"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 45</rdf:li>\n       <rdf:li>54, 62</rdf:li>\n       <rdf:li>157, 153</rdf:li>\n       <rdf:li>218, 224</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>45, 15</rdf:li>\n       <rdf:li>75, 55</rdf:li>\n       <rdf:li>99, 95</rdf:li>\n       <rdf:li>170, 180</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>33, 8</rdf:li>\n       <rdf:li>78, 63</rdf:li>\n       <rdf:li>102, 103</rdf:li>\n       <rdf:li>172, 186</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>39, 9</rdf:li>\n       <rdf:li>72, 51</rdf:li>\n       <rdf:li>101, 101</rdf:li>\n       <rdf:li>161, 181</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Kodak-Z V');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmKodak_Z_5();
