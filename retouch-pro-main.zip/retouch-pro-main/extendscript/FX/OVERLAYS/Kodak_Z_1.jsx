$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Kodak-Z I ==============
//
function FilmKodak_Z_1() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Converti in oggetto avanzato
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('newPlacedLayer'), undefined, dialogMode);
  }

  // Filtro Camera Raw
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CrVe'), '14.0.1');
    desc1.putInteger(cTID('PrVN'), 5);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putInteger(cTID('Cr12'), 10);
    desc1.putInteger(cTID('Hi12'), -55);
    desc1.putInteger(cTID('Sh12'), 45);
    desc1.putInteger(cTID('Wh12'), 25);
    desc1.putInteger(cTID('Bk12'), 25);
    desc1.putInteger(cTID('PC_S'), -28);
    desc1.putInteger(cTID('PC_D'), 9);
    desc1.putInteger(cTID('PC_L'), -9);
    desc1.putInteger(cTID('PC_H'), -26);
    desc1.putInteger(cTID('PC_1'), 25);
    desc1.putInteger(cTID('PC_2'), 50);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('HA_R'), 20);
    desc1.putInteger(cTID('HA_O'), 0);
    desc1.putInteger(cTID('HA_Y'), -25);
    desc1.putInteger(cTID('HA_G'), 0);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), -45);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 0);
    desc1.putInteger(cTID('SA_R'), -35);
    desc1.putInteger(cTID('SA_O'), -10);
    desc1.putInteger(cTID('SA_Y'), -10);
    desc1.putInteger(cTID('SA_G'), -50);
    desc1.putInteger(cTID('SA_A'), 0);
    desc1.putInteger(cTID('SA_B'), -95);
    desc1.putInteger(cTID('SA_P'), 0);
    desc1.putInteger(cTID('SA_M'), 0);
    desc1.putInteger(cTID('LA_R'), -20);
    desc1.putInteger(cTID('LA_O'), -10);
    desc1.putInteger(cTID('LA_Y'), -25);
    desc1.putInteger(cTID('LA_G'), -25);
    desc1.putInteger(cTID('LA_A'), -20);
    desc1.putInteger(cTID('LA_B'), 5);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('STSH'), 30);
    desc1.putInteger(cTID('STSS'), 5);
    desc1.putInteger(cTID('STHH'), 200);
    desc1.putInteger(cTID('STHS'), 5);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('CgMH'), 0);
    desc1.putInteger(cTID('CgMS'), 0);
    desc1.putInteger(cTID('CgSL'), 0);
    desc1.putInteger(cTID('CgML'), 0);
    desc1.putInteger(cTID('CgHL'), 0);
    desc1.putInteger(cTID('CgBl'), 100);
    desc1.putInteger(cTID('CgGH'), 0);
    desc1.putInteger(cTID('CgGS'), 0);
    desc1.putInteger(cTID('CgGL'), 0);
    desc1.putInteger(cTID('GRNA'), 40);
    desc1.putInteger(cTID('GRNS'), 25);
    desc1.putInteger(cTID('GRNF'), 50);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 10);
    desc1.putInteger(cTID('RSat'), 0);
    desc1.putInteger(cTID('GHue'), 0);
    desc1.putInteger(cTID('GSat'), 0);
    desc1.putInteger(cTID('BHue'), 0);
    desc1.putInteger(cTID('BSat'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(32);
    list1.putInteger(36);
    list1.putInteger(38);
    list1.putInteger(84);
    list1.putInteger(84);
    list1.putInteger(130);
    list1.putInteger(139);
    list1.putInteger(209);
    list1.putInteger(217);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(102);
    list2.putInteger(102);
    list2.putInteger(172);
    list2.putInteger(180);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(103);
    list3.putInteger(103);
    list3.putInteger(168);
    list3.putInteger(171);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(109);
    list4.putInteger(107);
    list4.putInteger(172);
    list4.putInteger(174);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000 1.000000, 0000/00/00-00:00:00        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="Kodak-Z I"\n     crs:Amount="1"\n     crs:UUID="39DEE878D39E1AD78BA3C29D7F369105"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Analogue Beauty</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="14.0.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+10"\n      crs:Highlights2012="-55"\n      crs:Shadows2012="+45"\n      crs:Whites2012="+25"\n      crs:Blacks2012="+25"\n      crs:Clarity2012="0"\n      crs:Vibrance="0"\n      crs:Saturation="0"\n      crs:ParametricShadows="-28"\n      crs:ParametricDarks="+9"\n      crs:ParametricLights="-9"\n      crs:ParametricHighlights="-26"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="25"\n      crs:ColorNoiseReductionDetail="50"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:HueAdjustmentRed="+20"\n      crs:HueAdjustmentOrange="0"\n      crs:HueAdjustmentYellow="-25"\n      crs:HueAdjustmentGreen="0"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="-45"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="0"\n      crs:SaturationAdjustmentRed="-35"\n      crs:SaturationAdjustmentOrange="-10"\n      crs:SaturationAdjustmentYellow="-10"\n      crs:SaturationAdjustmentGreen="-50"\n      crs:SaturationAdjustmentAqua="0"\n      crs:SaturationAdjustmentBlue="-95"\n      crs:SaturationAdjustmentPurple="0"\n      crs:SaturationAdjustmentMagenta="0"\n      crs:LuminanceAdjustmentRed="-20"\n      crs:LuminanceAdjustmentOrange="-10"\n      crs:LuminanceAdjustmentYellow="-25"\n      crs:LuminanceAdjustmentGreen="-25"\n      crs:LuminanceAdjustmentAqua="-20"\n      crs:LuminanceAdjustmentBlue="+5"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="30"\n      crs:SplitToningShadowSaturation="5"\n      crs:SplitToningHighlightHue="200"\n      crs:SplitToningHighlightSaturation="5"\n      crs:SplitToningBalance="0"\n      crs:ColorGradeMidtoneHue="0"\n      crs:ColorGradeMidtoneSat="0"\n      crs:ColorGradeShadowLum="0"\n      crs:ColorGradeMidtoneLum="0"\n      crs:ColorGradeHighlightLum="0"\n      crs:ColorGradeBlending="100"\n      crs:ColorGradeGlobalHue="0"\n      crs:ColorGradeGlobalSat="0"\n      crs:ColorGradeGlobalLum="0"\n      crs:AutoLateralCA="0"\n      crs:VignetteAmount="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:GrainAmount="40"\n      crs:GrainSize="25"\n      crs:GrainFrequency="50"\n      crs:PostCropVignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+10"\n      crs:RedSaturation="0"\n      crs:GreenHue="0"\n      crs:GreenSaturation="0"\n      crs:BlueHue="0"\n      crs:BlueSaturation="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 32</rdf:li>\n       <rdf:li>36, 38</rdf:li>\n       <rdf:li>84, 84</rdf:li>\n       <rdf:li>130, 139</rdf:li>\n       <rdf:li>209, 217</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>102, 102</rdf:li>\n       <rdf:li>172, 180</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>103, 103</rdf:li>\n       <rdf:li>168, 171</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>109, 107</rdf:li>\n       <rdf:li>172, 174</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Kodak-Z I');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    step2(); // Converti in oggetto avanzato
    step3(); // Filtro Camera Raw
    step4(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

FilmKodak_Z_1();
