$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== White ==============
//
function White() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 37);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'WHITE');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), -3);
    desc1.putInteger(cTID('Tint'), 0);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -11);
    desc1.putInteger(cTID('Shrp'), 35);
    desc1.putInteger(cTID('LNR '), 23);
    desc1.putInteger(cTID('CNR '), 0);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 3);
    desc1.putInteger(cTID('RSat'), 6);
    desc1.putInteger(cTID('GHue'), 5);
    desc1.putInteger(cTID('GSat'), 3);
    desc1.putInteger(cTID('BHue'), -6);
    desc1.putInteger(cTID('BSat'), -9);
    desc1.putInteger(cTID('Vibr'), 20);
    desc1.putInteger(cTID('HA_R'), 0);
    desc1.putInteger(cTID('HA_O'), -15);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), 15);
    desc1.putInteger(cTID('HA_A'), 0);
    desc1.putInteger(cTID('HA_B'), 14);
    desc1.putInteger(cTID('HA_P'), -10);
    desc1.putInteger(cTID('HA_M'), -15);
    desc1.putInteger(cTID('SA_R'), 5);
    desc1.putInteger(cTID('SA_O'), -5);
    desc1.putInteger(cTID('SA_Y'), -80);
    desc1.putInteger(cTID('SA_G'), -9);
    desc1.putInteger(cTID('SA_A'), -20);
    desc1.putInteger(cTID('SA_B'), -15);
    desc1.putInteger(cTID('SA_P'), -30);
    desc1.putInteger(cTID('SA_M'), -15);
    desc1.putInteger(cTID('LA_R'), 3);
    desc1.putInteger(cTID('LA_O'), -8);
    desc1.putInteger(cTID('LA_Y'), 70);
    desc1.putInteger(cTID('LA_G'), -24);
    desc1.putInteger(cTID('LA_A'), 28);
    desc1.putInteger(cTID('LA_B'), 70);
    desc1.putInteger(cTID('LA_P'), 21);
    desc1.putInteger(cTID('LA_M'), 2);
    desc1.putInteger(cTID('STSH'), 0);
    desc1.putInteger(cTID('STSS'), 0);
    desc1.putInteger(cTID('STHH'), 0);
    desc1.putInteger(cTID('STHS'), 0);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 12);
    desc1.putInteger(cTID('PC_1'), 25);
    desc1.putInteger(cTID('PC_2'), 35);
    desc1.putInteger(cTID('PC_3'), 54);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 21);
    desc1.putInteger(cTID('ShpM'), 10);
    desc1.putInteger(cTID('PCVA'), 4);
    desc1.putInteger(cTID('PCVM'), 50);
    desc1.putInteger(cTID('PCVF'), 50);
    desc1.putInteger(cTID('PCVR'), 0);
    desc1.putInteger(cTID('PCVS'), 1);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 13);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), 0);
    desc1.putInteger(cTID('Cr12'), 12);
    desc1.putInteger(cTID('Hi12'), -79);
    desc1.putInteger(cTID('Sh12'), 29);
    desc1.putInteger(cTID('Wh12'), 60);
    desc1.putInteger(cTID('Bk12'), -12);
    desc1.putInteger(cTID('Cl12'), 15);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(4);
    list1.putInteger(29);
    list1.putInteger(44);
    list1.putInteger(84);
    list1.putInteger(134);
    list1.putInteger(124);
    list1.putInteger(173);
    list1.putInteger(248);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Blanca04"\n     crs:Amount="1.000000"\n     crs:UUID="CD3BC10FB7B6C74D8BC992BCFBC76F13"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond - Blanca</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="-3"\n      crs:IncrementalTint="0"\n      crs:Saturation="-11"\n      crs:Sharpness="35"\n      crs:LuminanceSmoothing="23"\n      crs:ColorNoiseReduction="0"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+3"\n      crs:RedSaturation="+6"\n      crs:GreenHue="+5"\n      crs:GreenSaturation="+3"\n      crs:BlueHue="-6"\n      crs:BlueSaturation="-9"\n      crs:Vibrance="+20"\n      crs:HueAdjustmentRed="0"\n      crs:HueAdjustmentOrange="-15"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="+15"\n      crs:HueAdjustmentAqua="0"\n      crs:HueAdjustmentBlue="+14"\n      crs:HueAdjustmentPurple="-10"\n      crs:HueAdjustmentMagenta="-15"\n      crs:SaturationAdjustmentRed="+5"\n      crs:SaturationAdjustmentOrange="-5"\n      crs:SaturationAdjustmentYellow="-80"\n      crs:SaturationAdjustmentGreen="-9"\n      crs:SaturationAdjustmentAqua="-20"\n      crs:SaturationAdjustmentBlue="-15"\n      crs:SaturationAdjustmentPurple="-30"\n      crs:SaturationAdjustmentMagenta="-15"\n      crs:LuminanceAdjustmentRed="+3"\n      crs:LuminanceAdjustmentOrange="-8"\n      crs:LuminanceAdjustmentYellow="+70"\n      crs:LuminanceAdjustmentGreen="-24"\n      crs:LuminanceAdjustmentAqua="+28"\n      crs:LuminanceAdjustmentBlue="+70"\n      crs:LuminanceAdjustmentPurple="+21"\n      crs:LuminanceAdjustmentMagenta="+2"\n      crs:SplitToningShadowHue="0"\n      crs:SplitToningShadowSaturation="0"\n      crs:SplitToningHighlightHue="0"\n      crs:SplitToningHighlightSaturation="0"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="+12"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="35"\n      crs:ParametricHighlightSplit="54"\n      crs:SharpenRadius="+1.0"\n      crs:SharpenDetail="21"\n      crs:SharpenEdgeMasking="10"\n      crs:PostCropVignetteAmount="+4"\n      crs:PostCropVignetteMidpoint="50"\n      crs:PostCropVignetteFeather="50"\n      crs:PostCropVignetteRoundness="0"\n      crs:PostCropVignetteStyle="1"\n      crs:GrainAmount="0"\n      crs:LuminanceNoiseReductionDetail="13"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+12"\n      crs:Highlights2012="-79"\n      crs:Shadows2012="+29"\n      crs:Whites2012="+60"\n      crs:Blacks2012="-12"\n      crs:Clarity2012="+15"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="True"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 4</rdf:li>\n       <rdf:li>29, 44</rdf:li>\n       <rdf:li>84, 134</rdf:li>\n       <rdf:li>124, 173</rdf:li>\n       <rdf:li>248, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Filtro Camera Raw
    step5(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

White();
