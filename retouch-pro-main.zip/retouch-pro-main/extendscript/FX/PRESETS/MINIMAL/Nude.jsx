$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Nude ==============
//
function Nude() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 35);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'NUDE');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Orng'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 2);
    desc1.putInteger(cTID('Tint'), -5);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), 23);
    desc1.putInteger(cTID('Shrp'), 0);
    desc1.putInteger(cTID('LNR '), 16);
    desc1.putInteger(cTID('CNR '), 0);
    desc1.putInteger(cTID('VigA'), 10);
    desc1.putInteger(cTID('VigM'), 50);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 22);
    desc1.putInteger(cTID('RSat'), -23);
    desc1.putInteger(cTID('GHue'), 40);
    desc1.putInteger(cTID('GSat'), -25);
    desc1.putInteger(cTID('BHue'), -35);
    desc1.putInteger(cTID('BSat'), -15);
    desc1.putInteger(cTID('Vibr'), -17);
    desc1.putInteger(cTID('HA_R'), 10);
    desc1.putInteger(cTID('HA_O'), 5);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), -6);
    desc1.putInteger(cTID('HA_A'), -36);
    desc1.putInteger(cTID('HA_B'), -36);
    desc1.putInteger(cTID('HA_P'), 14);
    desc1.putInteger(cTID('HA_M'), 34);
    desc1.putInteger(cTID('SA_R'), -24);
    desc1.putInteger(cTID('SA_O'), -28);
    desc1.putInteger(cTID('SA_Y'), -32);
    desc1.putInteger(cTID('SA_G'), -21);
    desc1.putInteger(cTID('SA_A'), -16);
    desc1.putInteger(cTID('SA_B'), -51);
    desc1.putInteger(cTID('SA_P'), -39);
    desc1.putInteger(cTID('SA_M'), 12);
    desc1.putInteger(cTID('LA_R'), -17);
    desc1.putInteger(cTID('LA_O'), -32);
    desc1.putInteger(cTID('LA_Y'), 44);
    desc1.putInteger(cTID('LA_G'), 40);
    desc1.putInteger(cTID('LA_A'), -17);
    desc1.putInteger(cTID('LA_B'), -14);
    desc1.putInteger(cTID('LA_P'), 5);
    desc1.putInteger(cTID('LA_M'), 6);
    desc1.putInteger(cTID('STSH'), 36);
    desc1.putInteger(cTID('STSS'), 5);
    desc1.putInteger(cTID('STHH'), 233);
    desc1.putInteger(cTID('STHS'), 8);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 14);
    desc1.putInteger(cTID('PC_2'), 60);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('LPEn'), 1);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 1);
    desc1.putDouble(cTID('Ex12'), 0.2);
    desc1.putInteger(cTID('Cr12'), 17);
    desc1.putInteger(cTID('Hi12'), -57);
    desc1.putInteger(cTID('Sh12'), 77);
    desc1.putInteger(cTID('Wh12'), 11);
    desc1.putInteger(cTID('Bk12'), 34);
    desc1.putInteger(cTID('Cl12'), 11);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 39);
    desc1.putInteger(cTID('DPHH'), 76);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 33);
    desc1.putInteger(cTID('DPGH'), 65);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(35);
    list1.putInteger(47);
    list1.putInteger(56);
    list1.putInteger(128);
    list1.putInteger(126);
    list1.putInteger(217);
    list1.putInteger(210);
    list1.putInteger(255);
    list1.putInteger(250);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(43);
    list2.putInteger(22);
    list2.putInteger(113);
    list2.putInteger(123);
    list2.putInteger(178);
    list2.putInteger(203);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(43);
    list3.putInteger(22);
    list3.putInteger(112);
    list3.putInteger(121);
    list3.putInteger(181);
    list3.putInteger(201);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(43);
    list4.putInteger(22);
    list4.putInteger(114);
    list4.putInteger(122);
    list4.putInteger(179);
    list4.putInteger(201);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('LPSe'), 0);
    desc1.putString(cTID('LPNa'), '');
    desc1.putString(cTID('LPFN'), '');
    desc1.putInteger(cTID('LPDA'), 100);
    desc1.putInteger(cTID('LPCA'), 100);
    desc1.putInteger(cTID('LPVA'), 100);
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Influencer07"\n     crs:Amount="1.000000"\n     crs:UUID="419E40B2D8383E4F99EC4FFCB58DEF89"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond - Influencer</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="+2"\n      crs:IncrementalTint="-5"\n      crs:Saturation="+23"\n      crs:LuminanceSmoothing="16"\n      crs:ColorNoiseReduction="0"\n      crs:VignetteAmount="+10"\n      crs:VignetteMidpoint="50"\n      crs:ShadowTint="0"\n      crs:RedHue="+22"\n      crs:RedSaturation="-23"\n      crs:GreenHue="+40"\n      crs:GreenSaturation="-25"\n      crs:BlueHue="-35"\n      crs:BlueSaturation="-15"\n      crs:Vibrance="-17"\n      crs:HueAdjustmentRed="+10"\n      crs:HueAdjustmentOrange="+5"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="-6"\n      crs:HueAdjustmentAqua="-36"\n      crs:HueAdjustmentBlue="-36"\n      crs:HueAdjustmentPurple="+14"\n      crs:HueAdjustmentMagenta="+34"\n      crs:SaturationAdjustmentRed="-24"\n      crs:SaturationAdjustmentOrange="-28"\n      crs:SaturationAdjustmentYellow="-32"\n      crs:SaturationAdjustmentGreen="-21"\n      crs:SaturationAdjustmentAqua="-16"\n      crs:SaturationAdjustmentBlue="-51"\n      crs:SaturationAdjustmentPurple="-39"\n      crs:SaturationAdjustmentMagenta="+12"\n      crs:LuminanceAdjustmentRed="-17"\n      crs:LuminanceAdjustmentOrange="-32"\n      crs:LuminanceAdjustmentYellow="+44"\n      crs:LuminanceAdjustmentGreen="+40"\n      crs:LuminanceAdjustmentAqua="-17"\n      crs:LuminanceAdjustmentBlue="-14"\n      crs:LuminanceAdjustmentPurple="+5"\n      crs:LuminanceAdjustmentMagenta="+6"\n      crs:SplitToningShadowHue="36"\n      crs:SplitToningShadowSaturation="5"\n      crs:SplitToningHighlightHue="233"\n      crs:SplitToningHighlightSaturation="8"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="14"\n      crs:ParametricMidtoneSplit="60"\n      crs:ParametricHighlightSplit="75"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:LensProfileEnable="1"\n      crs:LensManualDistortionAmount="0"\n      crs:PerspectiveVertical="0"\n      crs:PerspectiveHorizontal="0"\n      crs:PerspectiveRotate="0.0"\n      crs:PerspectiveScale="100"\n      crs:PerspectiveAspect="0"\n      crs:PerspectiveUpright="0"\n      crs:PerspectiveX="0.00"\n      crs:PerspectiveY="0.00"\n      crs:AutoLateralCA="1"\n      crs:Exposure2012="+0.20"\n      crs:Contrast2012="+17"\n      crs:Highlights2012="-57"\n      crs:Shadows2012="+77"\n      crs:Whites2012="+11"\n      crs:Blacks2012="+34"\n      crs:Clarity2012="+11"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="39"\n      crs:DefringePurpleHueHi="76"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="33"\n      crs:DefringeGreenHueHi="65"\n      crs:Dehaze="0"\n      crs:Texture="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName="Custom"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE"\n      crs:LensProfileSetup="LensDefaults">\n     <crs:ToneCurve>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurve>\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 35</rdf:li>\n       <rdf:li>47, 56</rdf:li>\n       <rdf:li>128, 126</rdf:li>\n       <rdf:li>217, 210</rdf:li>\n       <rdf:li>255, 250</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>113, 123</rdf:li>\n       <rdf:li>178, 203</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>112, 121</rdf:li>\n       <rdf:li>181, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>114, 122</rdf:li>\n       <rdf:li>179, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Imposta
    step5(); // Filtro Camera Raw
    step6(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Nude();
