$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Glam 7 ==============
//
function Glam7() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 692);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Glamour 7');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Vlt '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 8);
    desc1.putInteger(cTID('Tint'), 2);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -34);
    desc1.putInteger(cTID('Shrp'), 32);
    desc1.putInteger(cTID('LNR '), 32);
    desc1.putInteger(cTID('CNR '), 21);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 3);
    desc1.putInteger(cTID('RHue'), 43);
    desc1.putInteger(cTID('RSat'), 12);
    desc1.putInteger(cTID('GHue'), 53);
    desc1.putInteger(cTID('GSat'), 3);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), -16);
    desc1.putInteger(cTID('Vibr'), -65);
    desc1.putInteger(cTID('HA_R'), -5);
    desc1.putInteger(cTID('HA_O'), -11);
    desc1.putInteger(cTID('HA_Y'), -66);
    desc1.putInteger(cTID('HA_G'), 16);
    desc1.putInteger(cTID('HA_A'), -40);
    desc1.putInteger(cTID('HA_B'), -25);
    desc1.putInteger(cTID('HA_P'), -2);
    desc1.putInteger(cTID('HA_M'), -3);
    desc1.putInteger(cTID('SA_R'), 5);
    desc1.putInteger(cTID('SA_O'), 12);
    desc1.putInteger(cTID('SA_Y'), 13);
    desc1.putInteger(cTID('SA_G'), -57);
    desc1.putInteger(cTID('SA_A'), -46);
    desc1.putInteger(cTID('SA_B'), -55);
    desc1.putInteger(cTID('SA_P'), -29);
    desc1.putInteger(cTID('SA_M'), -18);
    desc1.putInteger(cTID('LA_R'), -21);
    desc1.putInteger(cTID('LA_O'), -15);
    desc1.putInteger(cTID('LA_Y'), -31);
    desc1.putInteger(cTID('LA_G'), 25);
    desc1.putInteger(cTID('LA_A'), -23);
    desc1.putInteger(cTID('LA_B'), 6);
    desc1.putInteger(cTID('LA_P'), -4);
    desc1.putInteger(cTID('LA_M'), 7);
    desc1.putInteger(cTID('STSH'), 40);
    desc1.putInteger(cTID('STSS'), 31);
    desc1.putInteger(cTID('STHH'), 49);
    desc1.putInteger(cTID('STHS'), 15);
    desc1.putInteger(cTID('STB '), 66);
    desc1.putInteger(cTID('PC_S'), 5);
    desc1.putInteger(cTID('PC_D'), 9);
    desc1.putInteger(cTID('PC_L'), 2);
    desc1.putInteger(cTID('PC_H'), -5);
    desc1.putInteger(cTID('PC_1'), 15);
    desc1.putInteger(cTID('PC_2'), 67);
    desc1.putInteger(cTID('PC_3'), 87);
    desc1.putDouble(cTID('ShpR'), 1.1);
    desc1.putInteger(cTID('ShpD'), 22);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 7);
    desc1.putInteger(cTID('GRNS'), 20);
    desc1.putInteger(cTID('GRNF'), 40);
    desc1.putInteger(cTID('LNRD'), 40);
    desc1.putInteger(cTID('CNRD'), 47);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNRS'), 48);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), 0.09);
    desc1.putInteger(cTID('Cr12'), -3);
    desc1.putInteger(cTID('Hi12'), -11);
    desc1.putInteger(cTID('Sh12'), 68);
    desc1.putInteger(cTID('Wh12'), -11);
    desc1.putInteger(cTID('Bk12'), 52);
    desc1.putInteger(cTID('Cl12'), 28);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(2);
    list1.putInteger(46);
    list1.putInteger(20);
    list1.putInteger(116);
    list1.putInteger(105);
    list1.putInteger(176);
    list1.putInteger(173);
    list1.putInteger(254);
    list1.putInteger(211);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(23);
    list2.putInteger(9);
    list2.putInteger(60);
    list2.putInteger(43);
    list2.putInteger(136);
    list2.putInteger(144);
    list2.putInteger(204);
    list2.putInteger(212);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(22);
    list3.putInteger(10);
    list3.putInteger(60);
    list3.putInteger(42);
    list3.putInteger(136);
    list3.putInteger(145);
    list3.putInteger(205);
    list3.putInteger(214);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(23);
    list4.putInteger(9);
    list4.putInteger(59);
    list4.putInteger(42);
    list4.putInteger(136);
    list4.putInteger(145);
    list4.putInteger(204);
    list4.putInteger(214);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="cinema18"\n     crs:Amount="1.000000"\n     crs:UUID="0E916EDF0526654D9040097B89C1030D"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Vision - Cinema</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="+8"\n      crs:IncrementalTint="+2"\n      crs:Saturation="-34"\n      crs:Sharpness="32"\n      crs:LuminanceSmoothing="32"\n      crs:ColorNoiseReduction="21"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="+3"\n      crs:RedHue="+43"\n      crs:RedSaturation="+12"\n      crs:GreenHue="+53"\n      crs:GreenSaturation="+3"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="-16"\n      crs:Vibrance="-65"\n      crs:HueAdjustmentRed="-5"\n      crs:HueAdjustmentOrange="-11"\n      crs:HueAdjustmentYellow="-66"\n      crs:HueAdjustmentGreen="+16"\n      crs:HueAdjustmentAqua="-40"\n      crs:HueAdjustmentBlue="-25"\n      crs:HueAdjustmentPurple="-2"\n      crs:HueAdjustmentMagenta="-3"\n      crs:SaturationAdjustmentRed="+5"\n      crs:SaturationAdjustmentOrange="+12"\n      crs:SaturationAdjustmentYellow="+13"\n      crs:SaturationAdjustmentGreen="-57"\n      crs:SaturationAdjustmentAqua="-46"\n      crs:SaturationAdjustmentBlue="-55"\n      crs:SaturationAdjustmentPurple="-29"\n      crs:SaturationAdjustmentMagenta="-18"\n      crs:LuminanceAdjustmentRed="-21"\n      crs:LuminanceAdjustmentOrange="-15"\n      crs:LuminanceAdjustmentYellow="-31"\n      crs:LuminanceAdjustmentGreen="+25"\n      crs:LuminanceAdjustmentAqua="-23"\n      crs:LuminanceAdjustmentBlue="+6"\n      crs:LuminanceAdjustmentPurple="-4"\n      crs:LuminanceAdjustmentMagenta="+7"\n      crs:SplitToningShadowHue="40"\n      crs:SplitToningShadowSaturation="31"\n      crs:SplitToningHighlightHue="49"\n      crs:SplitToningHighlightSaturation="15"\n      crs:SplitToningBalance="+66"\n      crs:ParametricShadows="+5"\n      crs:ParametricDarks="+9"\n      crs:ParametricLights="+2"\n      crs:ParametricHighlights="-5"\n      crs:ParametricShadowSplit="15"\n      crs:ParametricMidtoneSplit="67"\n      crs:ParametricHighlightSplit="87"\n      crs:SharpenRadius="+1.1"\n      crs:SharpenDetail="22"\n      crs:SharpenEdgeMasking="0"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="7"\n      crs:GrainSize="20"\n      crs:GrainFrequency="40"\n      crs:LuminanceNoiseReductionDetail="40"\n      crs:ColorNoiseReductionDetail="47"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReductionSmoothness="48"\n      crs:LensProfileEnable="0"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="+0.09"\n      crs:Contrast2012="-3"\n      crs:Highlights2012="-11"\n      crs:Shadows2012="+68"\n      crs:Whites2012="-11"\n      crs:Blacks2012="+52"\n      crs:Clarity2012="+28"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:Texture="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName="Custom"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurve>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurve>\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 2</rdf:li>\n       <rdf:li>46, 20</rdf:li>\n       <rdf:li>116, 105</rdf:li>\n       <rdf:li>176, 173</rdf:li>\n       <rdf:li>254, 211</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>23, 9</rdf:li>\n       <rdf:li>60, 43</rdf:li>\n       <rdf:li>136, 144</rdf:li>\n       <rdf:li>204, 212</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>22, 10</rdf:li>\n       <rdf:li>60, 42</rdf:li>\n       <rdf:li>136, 145</rdf:li>\n       <rdf:li>205, 214</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>23, 9</rdf:li>\n       <rdf:li>59, 42</rdf:li>\n       <rdf:li>136, 145</rdf:li>\n       <rdf:li>204, 214</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Imposta
    step5(); // Filtro Camera Raw
    step6(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Glam7();
