$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Dark ==============
//
function Dark() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 168);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'LOTUS');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), -15);
    desc1.putInteger(cTID('Tint'), -8);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -36);
    desc1.putInteger(cTID('Shrp'), 0);
    desc1.putInteger(cTID('LNR '), 0);
    desc1.putInteger(cTID('CNR '), 0);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), -44);
    desc1.putInteger(cTID('RHue'), 8);
    desc1.putInteger(cTID('RSat'), 8);
    desc1.putInteger(cTID('GHue'), 5);
    desc1.putInteger(cTID('GSat'), 28);
    desc1.putInteger(cTID('BHue'), -93);
    desc1.putInteger(cTID('BSat'), -1);
    desc1.putInteger(cTID('Vibr'), -31);
    desc1.putInteger(cTID('HA_R'), 97);
    desc1.putInteger(cTID('HA_O'), -37);
    desc1.putInteger(cTID('HA_Y'), -96);
    desc1.putInteger(cTID('HA_G'), -95);
    desc1.putInteger(cTID('HA_A'), 16);
    desc1.putInteger(cTID('HA_B'), -30);
    desc1.putInteger(cTID('HA_P'), 3);
    desc1.putInteger(cTID('HA_M'), 15);
    desc1.putInteger(cTID('SA_R'), 6);
    desc1.putInteger(cTID('SA_O'), -31);
    desc1.putInteger(cTID('SA_Y'), -65);
    desc1.putInteger(cTID('SA_G'), -49);
    desc1.putInteger(cTID('SA_A'), -82);
    desc1.putInteger(cTID('SA_B'), -69);
    desc1.putInteger(cTID('SA_P'), -42);
    desc1.putInteger(cTID('SA_M'), -42);
    desc1.putInteger(cTID('LA_R'), -10);
    desc1.putInteger(cTID('LA_O'), -11);
    desc1.putInteger(cTID('LA_Y'), -39);
    desc1.putInteger(cTID('LA_G'), -25);
    desc1.putInteger(cTID('LA_A'), -5);
    desc1.putInteger(cTID('LA_B'), -8);
    desc1.putInteger(cTID('LA_P'), -1);
    desc1.putInteger(cTID('LA_M'), 6);
    desc1.putInteger(cTID('STSH'), 357);
    desc1.putInteger(cTID('STSS'), 7);
    desc1.putInteger(cTID('STHH'), 201);
    desc1.putInteger(cTID('STHS'), 14);
    desc1.putInteger(cTID('STB '), -38);
    desc1.putInteger(cTID('PC_S'), 58);
    desc1.putInteger(cTID('PC_D'), 3);
    desc1.putInteger(cTID('PC_L'), -28);
    desc1.putInteger(cTID('PC_H'), -9);
    desc1.putInteger(cTID('PC_1'), 25);
    desc1.putInteger(cTID('PC_2'), 50);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putDouble(cTID('ShpR'), 0.6);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), 0);
    desc1.putInteger(cTID('Cr12'), 20);
    desc1.putInteger(cTID('Hi12'), -34);
    desc1.putInteger(cTID('Sh12'), -25);
    desc1.putInteger(cTID('Wh12'), -17);
    desc1.putInteger(cTID('Bk12'), 7);
    desc1.putInteger(cTID('Cl12'), 39);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(57);
    list1.putInteger(78);
    list1.putInteger(62);
    list1.putInteger(125);
    list1.putInteger(120);
    list1.putInteger(203);
    list1.putInteger(204);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Browy01"\n     crs:Amount="1.000000"\n     crs:UUID="1BA94854BC9AC74C821FD139C1BEF776"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond-Browy</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="-15"\n      crs:IncrementalTint="-8"\n      crs:Saturation="-36"\n      crs:Sharpness="0"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="-44"\n      crs:RedHue="+8"\n      crs:RedSaturation="+8"\n      crs:GreenHue="+5"\n      crs:GreenSaturation="+28"\n      crs:BlueHue="-93"\n      crs:BlueSaturation="-1"\n      crs:Vibrance="-31"\n      crs:HueAdjustmentRed="+97"\n      crs:HueAdjustmentOrange="-37"\n      crs:HueAdjustmentYellow="-96"\n      crs:HueAdjustmentGreen="-95"\n      crs:HueAdjustmentAqua="+16"\n      crs:HueAdjustmentBlue="-30"\n      crs:HueAdjustmentPurple="+3"\n      crs:HueAdjustmentMagenta="+15"\n      crs:SaturationAdjustmentRed="+6"\n      crs:SaturationAdjustmentOrange="-31"\n      crs:SaturationAdjustmentYellow="-65"\n      crs:SaturationAdjustmentGreen="-49"\n      crs:SaturationAdjustmentAqua="-82"\n      crs:SaturationAdjustmentBlue="-69"\n      crs:SaturationAdjustmentPurple="-42"\n      crs:SaturationAdjustmentMagenta="-42"\n      crs:LuminanceAdjustmentRed="-10"\n      crs:LuminanceAdjustmentOrange="-11"\n      crs:LuminanceAdjustmentYellow="-39"\n      crs:LuminanceAdjustmentGreen="-25"\n      crs:LuminanceAdjustmentAqua="-5"\n      crs:LuminanceAdjustmentBlue="-8"\n      crs:LuminanceAdjustmentPurple="-1"\n      crs:LuminanceAdjustmentMagenta="+6"\n      crs:SplitToningShadowHue="357"\n      crs:SplitToningShadowSaturation="7"\n      crs:SplitToningHighlightHue="201"\n      crs:SplitToningHighlightSaturation="14"\n      crs:SplitToningBalance="-38"\n      crs:ParametricShadows="+58"\n      crs:ParametricDarks="+3"\n      crs:ParametricLights="-28"\n      crs:ParametricHighlights="-9"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:SharpenRadius="+0.6"\n      crs:SharpenDetail="25"\n      crs:SharpenEdgeMasking="0"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+20"\n      crs:Highlights2012="-34"\n      crs:Shadows2012="-25"\n      crs:Whites2012="-17"\n      crs:Blacks2012="+7"\n      crs:Clarity2012="+39"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 57</rdf:li>\n       <rdf:li>78, 62</rdf:li>\n       <rdf:li>125, 120</rdf:li>\n       <rdf:li>203, 204</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'DARK');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Orng'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Filtro Camera Raw
    step5(); // Imposta
    step6(); // Imposta
    step7(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Dark();
