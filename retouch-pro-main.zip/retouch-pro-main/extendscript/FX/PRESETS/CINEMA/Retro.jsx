$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Retro ==============
//
function Retro() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 51);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'RETRO');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Orng'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('AsSh'));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), 0);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -31);
    desc1.putInteger(cTID('Shrp'), 0);
    desc1.putInteger(cTID('LNR '), 0);
    desc1.putInteger(cTID('CNR '), 0);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 32);
    desc1.putInteger(cTID('RSat'), 17);
    desc1.putInteger(cTID('GHue'), 35);
    desc1.putInteger(cTID('GSat'), 0);
    desc1.putInteger(cTID('BHue'), -20);
    desc1.putInteger(cTID('BSat'), 14);
    desc1.putInteger(cTID('Vibr'), 0);
    desc1.putInteger(cTID('HA_R'), -4);
    desc1.putInteger(cTID('HA_O'), -20);
    desc1.putInteger(cTID('HA_Y'), 4);
    desc1.putInteger(cTID('HA_G'), 0);
    desc1.putInteger(cTID('HA_A'), 28);
    desc1.putInteger(cTID('HA_B'), 4);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 19);
    desc1.putInteger(cTID('SA_R'), -25);
    desc1.putInteger(cTID('SA_O'), -32);
    desc1.putInteger(cTID('SA_Y'), -60);
    desc1.putInteger(cTID('SA_G'), -70);
    desc1.putInteger(cTID('SA_A'), -30);
    desc1.putInteger(cTID('SA_B'), -29);
    desc1.putInteger(cTID('SA_P'), -13);
    desc1.putInteger(cTID('SA_M'), -10);
    desc1.putInteger(cTID('LA_R'), -6);
    desc1.putInteger(cTID('LA_O'), -7);
    desc1.putInteger(cTID('LA_Y'), 4);
    desc1.putInteger(cTID('LA_G'), 29);
    desc1.putInteger(cTID('LA_A'), 9);
    desc1.putInteger(cTID('LA_B'), 6);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('STSH'), 51);
    desc1.putInteger(cTID('STSS'), 32);
    desc1.putInteger(cTID('STHH'), 209);
    desc1.putInteger(cTID('STHS'), 17);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 25);
    desc1.putInteger(cTID('PC_2'), 50);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), -0.21);
    desc1.putInteger(cTID('Cr12'), 34);
    desc1.putInteger(cTID('Hi12'), -100);
    desc1.putInteger(cTID('Sh12'), 100);
    desc1.putInteger(cTID('Wh12'), -100);
    desc1.putInteger(cTID('Bk12'), 100);
    desc1.putInteger(cTID('Cl12'), 62);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(63);
    list1.putInteger(58);
    list1.putInteger(93);
    list1.putInteger(119);
    list1.putInteger(139);
    list1.putInteger(184);
    list1.putInteger(189);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(44);
    list2.putInteger(22);
    list2.putInteger(90);
    list2.putInteger(56);
    list2.putInteger(124);
    list2.putInteger(125);
    list2.putInteger(194);
    list2.putInteger(208);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(44);
    list3.putInteger(16);
    list3.putInteger(93);
    list3.putInteger(59);
    list3.putInteger(125);
    list3.putInteger(126);
    list3.putInteger(193);
    list3.putInteger(203);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(42);
    list4.putInteger(18);
    list4.putInteger(89);
    list4.putInteger(63);
    list4.putInteger(123);
    list4.putInteger(125);
    list4.putInteger(198);
    list4.putInteger(212);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Beso01"\n     crs:Amount="1.000000"\n     crs:UUID="C70A421D61054E4C9D28F0F9537CB94E"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond - Beso</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="As Shot"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="0"\n      crs:Saturation="-31"\n      crs:LuminanceSmoothing="0"\n      crs:ColorNoiseReduction="0"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+32"\n      crs:RedSaturation="+17"\n      crs:GreenHue="+35"\n      crs:GreenSaturation="0"\n      crs:BlueHue="-20"\n      crs:BlueSaturation="+14"\n      crs:Vibrance="0"\n      crs:HueAdjustmentRed="-4"\n      crs:HueAdjustmentOrange="-20"\n      crs:HueAdjustmentYellow="+4"\n      crs:HueAdjustmentGreen="0"\n      crs:HueAdjustmentAqua="+28"\n      crs:HueAdjustmentBlue="+4"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="+19"\n      crs:SaturationAdjustmentRed="-25"\n      crs:SaturationAdjustmentOrange="-32"\n      crs:SaturationAdjustmentYellow="-60"\n      crs:SaturationAdjustmentGreen="-70"\n      crs:SaturationAdjustmentAqua="-30"\n      crs:SaturationAdjustmentBlue="-29"\n      crs:SaturationAdjustmentPurple="-13"\n      crs:SaturationAdjustmentMagenta="-10"\n      crs:LuminanceAdjustmentRed="-6"\n      crs:LuminanceAdjustmentOrange="-7"\n      crs:LuminanceAdjustmentYellow="+4"\n      crs:LuminanceAdjustmentGreen="+29"\n      crs:LuminanceAdjustmentAqua="+9"\n      crs:LuminanceAdjustmentBlue="+6"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="51"\n      crs:SplitToningShadowSaturation="32"\n      crs:SplitToningHighlightHue="209"\n      crs:SplitToningHighlightSaturation="17"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="25"\n      crs:ParametricMidtoneSplit="50"\n      crs:ParametricHighlightSplit="75"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LensProfileEnable="0"\n      crs:LensManualDistortionAmount="0"\n      crs:PerspectiveVertical="0"\n      crs:PerspectiveHorizontal="0"\n      crs:PerspectiveRotate="0.0"\n      crs:PerspectiveScale="100"\n      crs:PerspectiveAspect="0"\n      crs:PerspectiveUpright="0"\n      crs:PerspectiveX="0.00"\n      crs:PerspectiveY="0.00"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="-0.21"\n      crs:Contrast2012="+34"\n      crs:Highlights2012="-100"\n      crs:Shadows2012="+100"\n      crs:Whites2012="-100"\n      crs:Blacks2012="+100"\n      crs:Clarity2012="+62"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:Texture="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName="Custom"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurve>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurve>\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 63</rdf:li>\n       <rdf:li>58, 93</rdf:li>\n       <rdf:li>119, 139</rdf:li>\n       <rdf:li>184, 189</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>44, 22</rdf:li>\n       <rdf:li>90, 56</rdf:li>\n       <rdf:li>124, 125</rdf:li>\n       <rdf:li>194, 208</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>44, 16</rdf:li>\n       <rdf:li>93, 59</rdf:li>\n       <rdf:li>125, 126</rdf:li>\n       <rdf:li>193, 203</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>42, 18</rdf:li>\n       <rdf:li>89, 63</rdf:li>\n       <rdf:li>123, 125</rdf:li>\n       <rdf:li>198, 212</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Imposta
    step5(); // Filtro Camera Raw
    step6(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Retro();
