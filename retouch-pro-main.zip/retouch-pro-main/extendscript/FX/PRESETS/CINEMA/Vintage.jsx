$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Vintage ==============
//
function Vintage() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 53);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Vintage');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Ylw '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), -64);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), 4);
    desc1.putInteger(cTID('Shrp'), 40);
    desc1.putInteger(cTID('LNR '), 25);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), -11);
    desc1.putInteger(cTID('RHue'), 24);
    desc1.putInteger(cTID('RSat'), -20);
    desc1.putInteger(cTID('GHue'), 20);
    desc1.putInteger(cTID('GSat'), -20);
    desc1.putInteger(cTID('BHue'), -13);
    desc1.putInteger(cTID('BSat'), -5);
    desc1.putInteger(cTID('Vibr'), -27);
    desc1.putInteger(cTID('HA_R'), 34);
    desc1.putInteger(cTID('HA_O'), 11);
    desc1.putInteger(cTID('HA_Y'), -23);
    desc1.putInteger(cTID('HA_G'), -53);
    desc1.putInteger(cTID('HA_A'), -1);
    desc1.putInteger(cTID('HA_B'), -19);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 10);
    desc1.putInteger(cTID('SA_R'), 20);
    desc1.putInteger(cTID('SA_O'), -24);
    desc1.putInteger(cTID('SA_Y'), -42);
    desc1.putInteger(cTID('SA_G'), -59);
    desc1.putInteger(cTID('SA_A'), -25);
    desc1.putInteger(cTID('SA_B'), -19);
    desc1.putInteger(cTID('SA_P'), -10);
    desc1.putInteger(cTID('SA_M'), 0);
    desc1.putInteger(cTID('LA_R'), -5);
    desc1.putInteger(cTID('LA_O'), -5);
    desc1.putInteger(cTID('LA_Y'), 34);
    desc1.putInteger(cTID('LA_G'), 34);
    desc1.putInteger(cTID('LA_A'), -29);
    desc1.putInteger(cTID('LA_B'), -21);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('STSH'), 40);
    desc1.putInteger(cTID('STSS'), 15);
    desc1.putInteger(cTID('STHH'), 52);
    desc1.putInteger(cTID('STHS'), 8);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 49);
    desc1.putInteger(cTID('PC_D'), 39);
    desc1.putInteger(cTID('PC_L'), -9);
    desc1.putInteger(cTID('PC_H'), -12);
    desc1.putInteger(cTID('PC_1'), 10);
    desc1.putInteger(cTID('PC_2'), 45);
    desc1.putInteger(cTID('PC_3'), 78);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), -0.52);
    desc1.putInteger(cTID('Cr12'), 12);
    desc1.putInteger(cTID('Hi12'), -100);
    desc1.putInteger(cTID('Sh12'), 33);
    desc1.putInteger(cTID('Wh12'), 26);
    desc1.putInteger(cTID('Bk12'), -51);
    desc1.putInteger(cTID('Cl12'), 0);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(4);
    list1.putInteger(60);
    list1.putInteger(56);
    list1.putInteger(127);
    list1.putInteger(127);
    list1.putInteger(190);
    list1.putInteger(197);
    list1.putInteger(255);
    list1.putInteger(231);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(43);
    list2.putInteger(24);
    list2.putInteger(80);
    list2.putInteger(72);
    list2.putInteger(119);
    list2.putInteger(130);
    list2.putInteger(160);
    list2.putInteger(187);
    list2.putInteger(202);
    list2.putInteger(223);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(44);
    list3.putInteger(29);
    list3.putInteger(82);
    list3.putInteger(75);
    list3.putInteger(118);
    list3.putInteger(130);
    list3.putInteger(200);
    list3.putInteger(224);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(44);
    list4.putInteger(30);
    list4.putInteger(83);
    list4.putInteger(75);
    list4.putInteger(119);
    list4.putInteger(130);
    list4.putInteger(202);
    list4.putInteger(222);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="vintage7"\n     crs:Amount="1.000000"\n     crs:UUID="4E532627F2B8DC4BBCA397AD2809E737"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Vision - Vintage</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="-64"\n      crs:Saturation="+4"\n      crs:Sharpness="40"\n      crs:LuminanceSmoothing="25"\n      crs:ColorNoiseReduction="25"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="-11"\n      crs:RedHue="+24"\n      crs:RedSaturation="-20"\n      crs:GreenHue="+20"\n      crs:GreenSaturation="-20"\n      crs:BlueHue="-13"\n      crs:BlueSaturation="-5"\n      crs:Vibrance="-27"\n      crs:HueAdjustmentRed="+34"\n      crs:HueAdjustmentOrange="+11"\n      crs:HueAdjustmentYellow="-23"\n      crs:HueAdjustmentGreen="-53"\n      crs:HueAdjustmentAqua="-1"\n      crs:HueAdjustmentBlue="-19"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="+10"\n      crs:SaturationAdjustmentRed="+20"\n      crs:SaturationAdjustmentOrange="-24"\n      crs:SaturationAdjustmentYellow="-42"\n      crs:SaturationAdjustmentGreen="-59"\n      crs:SaturationAdjustmentAqua="-25"\n      crs:SaturationAdjustmentBlue="-19"\n      crs:SaturationAdjustmentPurple="-10"\n      crs:SaturationAdjustmentMagenta="0"\n      crs:LuminanceAdjustmentRed="-5"\n      crs:LuminanceAdjustmentOrange="-5"\n      crs:LuminanceAdjustmentYellow="+34"\n      crs:LuminanceAdjustmentGreen="+34"\n      crs:LuminanceAdjustmentAqua="-29"\n      crs:LuminanceAdjustmentBlue="-21"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="40"\n      crs:SplitToningShadowSaturation="15"\n      crs:SplitToningHighlightHue="52"\n      crs:SplitToningHighlightSaturation="8"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="+49"\n      crs:ParametricDarks="+39"\n      crs:ParametricLights="-9"\n      crs:ParametricHighlights="-12"\n      crs:ParametricShadowSplit="10"\n      crs:ParametricMidtoneSplit="45"\n      crs:ParametricHighlightSplit="78"\n      crs:SharpenRadius="+1.0"\n      crs:SharpenDetail="25"\n      crs:SharpenEdgeMasking="0"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:ColorNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:LensProfileEnable="0"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="-0.52"\n      crs:Contrast2012="+12"\n      crs:Highlights2012="-100"\n      crs:Shadows2012="+33"\n      crs:Whites2012="+26"\n      crs:Blacks2012="-51"\n      crs:Clarity2012="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:Texture="0"\n      crs:ConvertToGrayscale="False"\n      crs:ToneCurveName="Custom"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurve>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurve>\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 4</rdf:li>\n       <rdf:li>60, 56</rdf:li>\n       <rdf:li>127, 127</rdf:li>\n       <rdf:li>190, 197</rdf:li>\n       <rdf:li>255, 231</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 24</rdf:li>\n       <rdf:li>80, 72</rdf:li>\n       <rdf:li>119, 130</rdf:li>\n       <rdf:li>160, 187</rdf:li>\n       <rdf:li>202, 223</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>44, 29</rdf:li>\n       <rdf:li>82, 75</rdf:li>\n       <rdf:li>118, 130</rdf:li>\n       <rdf:li>200, 224</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>44, 30</rdf:li>\n       <rdf:li>83, 75</rdf:li>\n       <rdf:li>119, 130</rdf:li>\n       <rdf:li>202, 222</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Imposta
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'VINTAGE');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Imposta
    step5(); // Filtro Camera Raw
    step6(); // Imposta
    step7(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Vintage();
