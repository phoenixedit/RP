$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Dreamy ==============
//
function Dreamy() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 25);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Dreamy');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 0);
    desc1.putInteger(cTID('Tint'), 9);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -10);
    desc1.putInteger(cTID('Shrp'), 27);
    desc1.putInteger(cTID('LNR '), 22);
    desc1.putInteger(cTID('CNR '), 24);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 4);
    desc1.putInteger(cTID('RHue'), 0);
    desc1.putInteger(cTID('RSat'), 0);
    desc1.putInteger(cTID('GHue'), 0);
    desc1.putInteger(cTID('GSat'), 0);
    desc1.putInteger(cTID('BHue'), -25);
    desc1.putInteger(cTID('BSat'), -9);
    desc1.putInteger(cTID('Vibr'), 0);
    desc1.putInteger(cTID('HA_R'), 10);
    desc1.putInteger(cTID('HA_O'), -3);
    desc1.putInteger(cTID('HA_Y'), 0);
    desc1.putInteger(cTID('HA_G'), -10);
    desc1.putInteger(cTID('HA_A'), -15);
    desc1.putInteger(cTID('HA_B'), -18);
    desc1.putInteger(cTID('HA_P'), -21);
    desc1.putInteger(cTID('HA_M'), -23);
    desc1.putInteger(cTID('SA_R'), -15);
    desc1.putInteger(cTID('SA_O'), -20);
    desc1.putInteger(cTID('SA_Y'), -80);
    desc1.putInteger(cTID('SA_G'), -10);
    desc1.putInteger(cTID('SA_A'), -15);
    desc1.putInteger(cTID('SA_B'), -45);
    desc1.putInteger(cTID('SA_P'), -15);
    desc1.putInteger(cTID('SA_M'), -20);
    desc1.putInteger(cTID('LA_R'), 10);
    desc1.putInteger(cTID('LA_O'), -40);
    desc1.putInteger(cTID('LA_Y'), 24);
    desc1.putInteger(cTID('LA_G'), 7);
    desc1.putInteger(cTID('LA_A'), -4);
    desc1.putInteger(cTID('LA_B'), -29);
    desc1.putInteger(cTID('LA_P'), -5);
    desc1.putInteger(cTID('LA_M'), -3);
    desc1.putInteger(cTID('STSH'), 281);
    desc1.putInteger(cTID('STSS'), 4);
    desc1.putInteger(cTID('STHH'), 321);
    desc1.putInteger(cTID('STHS'), 6);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 5);
    desc1.putInteger(cTID('PC_D'), 16);
    desc1.putInteger(cTID('PC_L'), 8);
    desc1.putInteger(cTID('PC_H'), 6);
    desc1.putInteger(cTID('PC_1'), 17);
    desc1.putInteger(cTID('PC_2'), 62);
    desc1.putInteger(cTID('PC_3'), 84);
    desc1.putDouble(cTID('ShpR'), 0.9);
    desc1.putInteger(cTID('ShpD'), 9);
    desc1.putInteger(cTID('ShpM'), 17);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 33);
    desc1.putInteger(cTID('CNRD'), 11);
    desc1.putInteger(cTID('LNRC'), 18);
    desc1.putInteger(cTID('CNRS'), 29);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), 0.24);
    desc1.putInteger(cTID('Cr12'), 0);
    desc1.putInteger(cTID('Hi12'), -16);
    desc1.putInteger(cTID('Sh12'), 61);
    desc1.putInteger(cTID('Wh12'), 21);
    desc1.putInteger(cTID('Bk12'), 51);
    desc1.putInteger(cTID('Cl12'), 35);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(25);
    list1.putInteger(49);
    list1.putInteger(55);
    list1.putInteger(93);
    list1.putInteger(96);
    list1.putInteger(173);
    list1.putInteger(170);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(43);
    list2.putInteger(22);
    list2.putInteger(113);
    list2.putInteger(123);
    list2.putInteger(178);
    list2.putInteger(203);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(43);
    list3.putInteger(22);
    list3.putInteger(112);
    list3.putInteger(121);
    list3.putInteger(181);
    list3.putInteger(201);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(43);
    list4.putInteger(22);
    list4.putInteger(114);
    list4.putInteger(122);
    list4.putInteger(179);
    list4.putInteger(201);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Roma01"\n     crs:Amount="1.000000"\n     crs:UUID="4AAB2026E94A3A4B92D41E1FE0BCBA20"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond-Roma</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="0"\n      crs:IncrementalTint="+9"\n      crs:Saturation="-10"\n      crs:Sharpness="27"\n      crs:LuminanceSmoothing="22"\n      crs:ColorNoiseReduction="24"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="+4"\n      crs:RedHue="0"\n      crs:RedSaturation="0"\n      crs:GreenHue="0"\n      crs:GreenSaturation="0"\n      crs:BlueHue="-25"\n      crs:BlueSaturation="-9"\n      crs:Vibrance="0"\n      crs:HueAdjustmentRed="+10"\n      crs:HueAdjustmentOrange="-3"\n      crs:HueAdjustmentYellow="0"\n      crs:HueAdjustmentGreen="-10"\n      crs:HueAdjustmentAqua="-15"\n      crs:HueAdjustmentBlue="-18"\n      crs:HueAdjustmentPurple="-21"\n      crs:HueAdjustmentMagenta="-23"\n      crs:SaturationAdjustmentRed="-15"\n      crs:SaturationAdjustmentOrange="-20"\n      crs:SaturationAdjustmentYellow="-80"\n      crs:SaturationAdjustmentGreen="-10"\n      crs:SaturationAdjustmentAqua="-15"\n      crs:SaturationAdjustmentBlue="-45"\n      crs:SaturationAdjustmentPurple="-15"\n      crs:SaturationAdjustmentMagenta="-20"\n      crs:LuminanceAdjustmentRed="+10"\n      crs:LuminanceAdjustmentOrange="-40"\n      crs:LuminanceAdjustmentYellow="+24"\n      crs:LuminanceAdjustmentGreen="+7"\n      crs:LuminanceAdjustmentAqua="-4"\n      crs:LuminanceAdjustmentBlue="-29"\n      crs:LuminanceAdjustmentPurple="-5"\n      crs:LuminanceAdjustmentMagenta="-3"\n      crs:SplitToningShadowHue="281"\n      crs:SplitToningShadowSaturation="4"\n      crs:SplitToningHighlightHue="321"\n      crs:SplitToningHighlightSaturation="6"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="+5"\n      crs:ParametricDarks="+16"\n      crs:ParametricLights="+8"\n      crs:ParametricHighlights="+6"\n      crs:ParametricShadowSplit="17"\n      crs:ParametricMidtoneSplit="62"\n      crs:ParametricHighlightSplit="84"\n      crs:SharpenRadius="+0.9"\n      crs:SharpenDetail="9"\n      crs:SharpenEdgeMasking="17"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LuminanceNoiseReductionDetail="33"\n      crs:ColorNoiseReductionDetail="11"\n      crs:LuminanceNoiseReductionContrast="18"\n      crs:ColorNoiseReductionSmoothness="29"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="+0.24"\n      crs:Contrast2012="0"\n      crs:Highlights2012="-16"\n      crs:Shadows2012="+61"\n      crs:Whites2012="+21"\n      crs:Blacks2012="+51"\n      crs:Clarity2012="+35"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 25</rdf:li>\n       <rdf:li>49, 55</rdf:li>\n       <rdf:li>93, 96</rdf:li>\n       <rdf:li>173, 170</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>113, 123</rdf:li>\n       <rdf:li>178, 203</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>112, 121</rdf:li>\n       <rdf:li>181, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 22</rdf:li>\n       <rdf:li>114, 122</rdf:li>\n       <rdf:li>179, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Filtro Camera Raw
    step5(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Dreamy();
