$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Coco ==============
//
function Coco() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 11);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Coco');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), 13);
    desc1.putInteger(cTID('Tint'), 21);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -32);
    desc1.putInteger(cTID('Shrp'), 25);
    desc1.putInteger(cTID('LNR '), 12);
    desc1.putInteger(cTID('CNR '), 25);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 38);
    desc1.putInteger(cTID('RSat'), 25);
    desc1.putInteger(cTID('GHue'), 100);
    desc1.putInteger(cTID('GSat'), -11);
    desc1.putInteger(cTID('BHue'), -11);
    desc1.putInteger(cTID('BSat'), -10);
    desc1.putInteger(cTID('Vibr'), -14);
    desc1.putInteger(cTID('HA_R'), 16);
    desc1.putInteger(cTID('HA_O'), -6);
    desc1.putInteger(cTID('HA_Y'), 25);
    desc1.putInteger(cTID('HA_G'), 30);
    desc1.putInteger(cTID('HA_A'), 10);
    desc1.putInteger(cTID('HA_B'), -13);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 20);
    desc1.putInteger(cTID('SA_R'), 21);
    desc1.putInteger(cTID('SA_O'), -3);
    desc1.putInteger(cTID('SA_Y'), -70);
    desc1.putInteger(cTID('SA_G'), -62);
    desc1.putInteger(cTID('SA_A'), 21);
    desc1.putInteger(cTID('SA_B'), 27);
    desc1.putInteger(cTID('SA_P'), 3);
    desc1.putInteger(cTID('SA_M'), 7);
    desc1.putInteger(cTID('LA_R'), -23);
    desc1.putInteger(cTID('LA_O'), -13);
    desc1.putInteger(cTID('LA_Y'), 58);
    desc1.putInteger(cTID('LA_G'), -50);
    desc1.putInteger(cTID('LA_A'), -27);
    desc1.putInteger(cTID('LA_B'), -34);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 1);
    desc1.putInteger(cTID('STSH'), 48);
    desc1.putInteger(cTID('STSS'), 10);
    desc1.putInteger(cTID('STHH'), 225);
    desc1.putInteger(cTID('STHS'), 4);
    desc1.putInteger(cTID('STB '), 0);
    desc1.putInteger(cTID('PC_S'), 43);
    desc1.putInteger(cTID('PC_D'), 19);
    desc1.putInteger(cTID('PC_L'), -7);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 14);
    desc1.putInteger(cTID('PC_2'), 43);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 1);
    desc1.putDouble(cTID('Ex12'), 0);
    desc1.putInteger(cTID('Cr12'), 8);
    desc1.putInteger(cTID('Hi12'), -98);
    desc1.putInteger(cTID('Sh12'), 86);
    desc1.putInteger(cTID('Wh12'), 49);
    desc1.putInteger(cTID('Bk12'), 78);
    desc1.putInteger(cTID('Cl12'), 0);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(0);
    list1.putInteger(255);
    list1.putInteger(255);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(30);
    list2.putInteger(7);
    list2.putInteger(59);
    list2.putInteger(25);
    list2.putInteger(118);
    list2.putInteger(119);
    list2.putInteger(184);
    list2.putInteger(201);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(60);
    list3.putInteger(32);
    list3.putInteger(118);
    list3.putInteger(125);
    list3.putInteger(183);
    list3.putInteger(204);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(61);
    list4.putInteger(42);
    list4.putInteger(117);
    list4.putInteger(125);
    list4.putInteger(179);
    list4.putInteger(201);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Coco01"\n     crs:Amount="1.000000"\n     crs:UUID="574D3F062A2D2247B8FB6A5D898BFD14"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond - Coco</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="+13"\n      crs:IncrementalTint="+21"\n      crs:Saturation="-32"\n      crs:Sharpness="25"\n      crs:LuminanceSmoothing="12"\n      crs:ColorNoiseReduction="25"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+38"\n      crs:RedSaturation="+25"\n      crs:GreenHue="+100"\n      crs:GreenSaturation="-11"\n      crs:BlueHue="-11"\n      crs:BlueSaturation="-10"\n      crs:Vibrance="-14"\n      crs:HueAdjustmentRed="+16"\n      crs:HueAdjustmentOrange="-6"\n      crs:HueAdjustmentYellow="+25"\n      crs:HueAdjustmentGreen="+30"\n      crs:HueAdjustmentAqua="+10"\n      crs:HueAdjustmentBlue="-13"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="+20"\n      crs:SaturationAdjustmentRed="+21"\n      crs:SaturationAdjustmentOrange="-3"\n      crs:SaturationAdjustmentYellow="-70"\n      crs:SaturationAdjustmentGreen="-62"\n      crs:SaturationAdjustmentAqua="+21"\n      crs:SaturationAdjustmentBlue="+27"\n      crs:SaturationAdjustmentPurple="+3"\n      crs:SaturationAdjustmentMagenta="+7"\n      crs:LuminanceAdjustmentRed="-23"\n      crs:LuminanceAdjustmentOrange="-13"\n      crs:LuminanceAdjustmentYellow="+58"\n      crs:LuminanceAdjustmentGreen="-50"\n      crs:LuminanceAdjustmentAqua="-27"\n      crs:LuminanceAdjustmentBlue="-34"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="+1"\n      crs:SplitToningShadowHue="48"\n      crs:SplitToningShadowSaturation="10"\n      crs:SplitToningHighlightHue="225"\n      crs:SplitToningHighlightSaturation="4"\n      crs:SplitToningBalance="0"\n      crs:ParametricShadows="+43"\n      crs:ParametricDarks="+19"\n      crs:ParametricLights="-7"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="14"\n      crs:ParametricMidtoneSplit="43"\n      crs:ParametricHighlightSplit="75"\n      crs:SharpenRadius="+1.0"\n      crs:SharpenDetail="25"\n      crs:SharpenEdgeMasking="0"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:ColorNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:LensManualDistortionAmount="0"\n      crs:AutoLateralCA="1"\n      crs:Exposure2012="0.00"\n      crs:Contrast2012="+8"\n      crs:Highlights2012="-98"\n      crs:Shadows2012="+86"\n      crs:Whites2012="+49"\n      crs:Blacks2012="+78"\n      crs:Clarity2012="0"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>30, 7</rdf:li>\n       <rdf:li>59, 25</rdf:li>\n       <rdf:li>118, 119</rdf:li>\n       <rdf:li>184, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>60, 32</rdf:li>\n       <rdf:li>118, 125</rdf:li>\n       <rdf:li>183, 204</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>61, 42</rdf:li>\n       <rdf:li>117, 125</rdf:li>\n       <rdf:li>179, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Bl  '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Filtro Camera Raw
    step5(); // Crea
    step6(); // Imposta
    return true;
  } catch (error) {
    return false;
  }
}

Coco();
