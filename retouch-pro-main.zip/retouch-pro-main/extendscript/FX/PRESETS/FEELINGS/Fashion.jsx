$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Fashion ==============
//
function Fashion() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 21);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Fashion');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Gry '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Filtro Camera Raw
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putString(cTID('CMod'), 'Filter');
    desc1.putEnumerated(cTID('Sett'), cTID('Sett'), cTID('Cst '));
    desc1.putEnumerated(cTID('WBal'), cTID('WBal'), cTID('Cst '));
    desc1.putInteger(cTID('Temp'), -5);
    desc1.putInteger(cTID('Tint'), 11);
    desc1.putBoolean(cTID('CtoG'), false);
    desc1.putInteger(cTID('Strt'), -16);
    desc1.putInteger(cTID('Shrp'), 0);
    desc1.putInteger(cTID('LNR '), 7);
    desc1.putInteger(cTID('CNR '), 30);
    desc1.putInteger(cTID('VigA'), 0);
    desc1.putInteger(cTID('BlkB'), 0);
    desc1.putInteger(cTID('RHue'), 5);
    desc1.putInteger(cTID('RSat'), 11);
    desc1.putInteger(cTID('GHue'), 5);
    desc1.putInteger(cTID('GSat'), -10);
    desc1.putInteger(cTID('BHue'), -10);
    desc1.putInteger(cTID('BSat'), -49);
    desc1.putInteger(cTID('Vibr'), -14);
    desc1.putInteger(cTID('HA_R'), 10);
    desc1.putInteger(cTID('HA_O'), -7);
    desc1.putInteger(cTID('HA_Y'), -25);
    desc1.putInteger(cTID('HA_G'), 65);
    desc1.putInteger(cTID('HA_A'), -44);
    desc1.putInteger(cTID('HA_B'), 27);
    desc1.putInteger(cTID('HA_P'), 0);
    desc1.putInteger(cTID('HA_M'), 0);
    desc1.putInteger(cTID('SA_R'), 0);
    desc1.putInteger(cTID('SA_O'), -8);
    desc1.putInteger(cTID('SA_Y'), -32);
    desc1.putInteger(cTID('SA_G'), -57);
    desc1.putInteger(cTID('SA_A'), -30);
    desc1.putInteger(cTID('SA_B'), -50);
    desc1.putInteger(cTID('SA_P'), 0);
    desc1.putInteger(cTID('SA_M'), 0);
    desc1.putInteger(cTID('LA_R'), -50);
    desc1.putInteger(cTID('LA_O'), -35);
    desc1.putInteger(cTID('LA_Y'), 0);
    desc1.putInteger(cTID('LA_G'), -28);
    desc1.putInteger(cTID('LA_A'), 49);
    desc1.putInteger(cTID('LA_B'), 41);
    desc1.putInteger(cTID('LA_P'), 0);
    desc1.putInteger(cTID('LA_M'), 0);
    desc1.putInteger(cTID('STSH'), 30);
    desc1.putInteger(cTID('STSS'), 3);
    desc1.putInteger(cTID('STHH'), 51);
    desc1.putInteger(cTID('STHS'), 3);
    desc1.putInteger(cTID('STB '), -1);
    desc1.putInteger(cTID('PC_S'), 0);
    desc1.putInteger(cTID('PC_D'), 0);
    desc1.putInteger(cTID('PC_L'), 0);
    desc1.putInteger(cTID('PC_H'), 0);
    desc1.putInteger(cTID('PC_1'), 20);
    desc1.putInteger(cTID('PC_2'), 55);
    desc1.putInteger(cTID('PC_3'), 75);
    desc1.putDouble(cTID('ShpR'), 1);
    desc1.putInteger(cTID('ShpD'), 25);
    desc1.putInteger(cTID('ShpM'), 0);
    desc1.putInteger(cTID('PCVA'), 0);
    desc1.putInteger(cTID('GRNA'), 0);
    desc1.putInteger(cTID('LNRD'), 50);
    desc1.putInteger(cTID('CNRD'), 50);
    desc1.putInteger(cTID('LNRC'), 0);
    desc1.putInteger(cTID('CNRS'), 50);
    desc1.putInteger(cTID('LPEn'), 0);
    desc1.putInteger(cTID('MDis'), 0);
    desc1.putInteger(cTID('PerV'), 0);
    desc1.putInteger(cTID('PerH'), 0);
    desc1.putDouble(cTID('PerR'), 0);
    desc1.putInteger(cTID('PerS'), 100);
    desc1.putInteger(cTID('PerA'), 0);
    desc1.putInteger(cTID('PerU'), 0);
    desc1.putDouble(cTID('PerX'), 0);
    desc1.putDouble(cTID('PerY'), 0);
    desc1.putInteger(cTID('AuCA'), 0);
    desc1.putDouble(cTID('Ex12'), 1.11);
    desc1.putInteger(cTID('Cr12'), 28);
    desc1.putInteger(cTID('Hi12'), -81);
    desc1.putInteger(cTID('Sh12'), 3);
    desc1.putInteger(cTID('Wh12'), -6);
    desc1.putInteger(cTID('Bk12'), -25);
    desc1.putInteger(cTID('Cl12'), 19);
    desc1.putInteger(cTID('DfPA'), 0);
    desc1.putInteger(cTID('DPHL'), 30);
    desc1.putInteger(cTID('DPHH'), 70);
    desc1.putInteger(cTID('DfGA'), 0);
    desc1.putInteger(cTID('DPGL'), 40);
    desc1.putInteger(cTID('DPGH'), 60);
    desc1.putInteger(cTID('Dhze'), 0);
    desc1.putInteger(cTID('CrTx'), 0);
    desc1.putInteger(cTID('TMMs'), 0);
    var list1 = new ActionList();
    list1.putInteger(0);
    list1.putInteger(6);
    list1.putInteger(28);
    list1.putInteger(32);
    list1.putInteger(128);
    list1.putInteger(128);
    list1.putInteger(204);
    list1.putInteger(202);
    list1.putInteger(255);
    list1.putInteger(251);
    desc1.putList(cTID('Crv '), list1);
    var list2 = new ActionList();
    list2.putInteger(0);
    list2.putInteger(0);
    list2.putInteger(37);
    list2.putInteger(32);
    list2.putInteger(114);
    list2.putInteger(119);
    list2.putInteger(181);
    list2.putInteger(191);
    list2.putInteger(255);
    list2.putInteger(255);
    desc1.putList(cTID('CrvR'), list2);
    var list3 = new ActionList();
    list3.putInteger(0);
    list3.putInteger(0);
    list3.putInteger(40);
    list3.putInteger(32);
    list3.putInteger(117);
    list3.putInteger(121);
    list3.putInteger(179);
    list3.putInteger(191);
    list3.putInteger(255);
    list3.putInteger(255);
    desc1.putList(cTID('CrvG'), list3);
    var list4 = new ActionList();
    list4.putInteger(0);
    list4.putInteger(0);
    list4.putInteger(43);
    list4.putInteger(30);
    list4.putInteger(119);
    list4.putInteger(122);
    list4.putInteger(178);
    list4.putInteger(201);
    list4.putInteger(255);
    list4.putInteger(255);
    desc1.putList(cTID('CrvB'), list4);
    desc1.putString(cTID('CamP'), 'Embedded');
    desc1.putString(cTID('CP_D'), '54650A341B5B5CCAE8442D0B43A92BCE');
    desc1.putInteger(cTID('PrVe'), 184549376);
    desc1.putString(cTID('Rtch'), '');
    desc1.putString(cTID('REye'), '');
    desc1.putString(cTID('LCs '), '');
    desc1.putString(
      cTID('Upri'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightVersion="151388160"\n   crs:UprightCenterMode="0"\n   crs:UprightCenterNormX="0.5"\n   crs:UprightCenterNormY="0.5"\n   crs:UprightFocalMode="0"\n   crs:UprightFocalLength35mm="35"\n   crs:UprightPreview="False"\n   crs:UprightTransformCount="6"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(
      cTID('GuUr'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/"\n   crs:UprightFourSegmentsCount="0"/>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    desc1.putString(cTID('Look'), '');
    desc1.putString(
      cTID('Pset'),
      '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c140 79.160451, 2017/05/06-01:08:21        ">\n <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n  <rdf:Description rdf:about=""\n    xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">\n   <crs:Preset>\n    <rdf:Description\n     crs:Name="DMP_Moda01"\n     crs:Amount="1.000000"\n     crs:UUID="D5FFD7DBEC8E8547879C0CDD1E60C0CB"\n     crs:SupportsAmount="false">\n    <crs:Group>\n     <rdf:Alt>\n      <rdf:li xml:lang="x-default">Diamond - Moda</rdf:li>\n     </rdf:Alt>\n    </crs:Group>\n    <crs:Parameters>\n     <rdf:Description\n      crs:Version="11.4.1"\n      crs:ProcessVersion="11.0"\n      crs:WhiteBalance="Custom"\n      crs:IncrementalTemperature="-5"\n      crs:IncrementalTint="+11"\n      crs:Saturation="-16"\n      crs:LuminanceSmoothing="7"\n      crs:ColorNoiseReduction="30"\n      crs:VignetteAmount="0"\n      crs:ShadowTint="0"\n      crs:RedHue="+5"\n      crs:RedSaturation="+11"\n      crs:GreenHue="+5"\n      crs:GreenSaturation="-10"\n      crs:BlueHue="-10"\n      crs:BlueSaturation="-49"\n      crs:Vibrance="-14"\n      crs:HueAdjustmentRed="+10"\n      crs:HueAdjustmentOrange="-7"\n      crs:HueAdjustmentYellow="-25"\n      crs:HueAdjustmentGreen="+65"\n      crs:HueAdjustmentAqua="-44"\n      crs:HueAdjustmentBlue="+27"\n      crs:HueAdjustmentPurple="0"\n      crs:HueAdjustmentMagenta="0"\n      crs:SaturationAdjustmentRed="0"\n      crs:SaturationAdjustmentOrange="-8"\n      crs:SaturationAdjustmentYellow="-32"\n      crs:SaturationAdjustmentGreen="-57"\n      crs:SaturationAdjustmentAqua="-30"\n      crs:SaturationAdjustmentBlue="-50"\n      crs:SaturationAdjustmentPurple="0"\n      crs:SaturationAdjustmentMagenta="0"\n      crs:LuminanceAdjustmentRed="-50"\n      crs:LuminanceAdjustmentOrange="-35"\n      crs:LuminanceAdjustmentYellow="0"\n      crs:LuminanceAdjustmentGreen="-28"\n      crs:LuminanceAdjustmentAqua="+49"\n      crs:LuminanceAdjustmentBlue="+41"\n      crs:LuminanceAdjustmentPurple="0"\n      crs:LuminanceAdjustmentMagenta="0"\n      crs:SplitToningShadowHue="30"\n      crs:SplitToningShadowSaturation="3"\n      crs:SplitToningHighlightHue="51"\n      crs:SplitToningHighlightSaturation="3"\n      crs:SplitToningBalance="-1"\n      crs:ParametricShadows="0"\n      crs:ParametricDarks="0"\n      crs:ParametricLights="0"\n      crs:ParametricHighlights="0"\n      crs:ParametricShadowSplit="20"\n      crs:ParametricMidtoneSplit="55"\n      crs:ParametricHighlightSplit="75"\n      crs:PostCropVignetteAmount="0"\n      crs:GrainAmount="0"\n      crs:LuminanceNoiseReductionDetail="50"\n      crs:ColorNoiseReductionDetail="50"\n      crs:LuminanceNoiseReductionContrast="0"\n      crs:ColorNoiseReductionSmoothness="50"\n      crs:LensProfileEnable="0"\n      crs:LensManualDistortionAmount="0"\n      crs:PerspectiveVertical="0"\n      crs:PerspectiveHorizontal="0"\n      crs:PerspectiveRotate="0.0"\n      crs:PerspectiveScale="100"\n      crs:PerspectiveAspect="0"\n      crs:PerspectiveUpright="0"\n      crs:PerspectiveX="0.00"\n      crs:PerspectiveY="0.00"\n      crs:AutoLateralCA="0"\n      crs:Exposure2012="+1.11"\n      crs:Contrast2012="+28"\n      crs:Highlights2012="-81"\n      crs:Shadows2012="+3"\n      crs:Whites2012="-6"\n      crs:Blacks2012="-25"\n      crs:Clarity2012="+19"\n      crs:DefringePurpleAmount="0"\n      crs:DefringePurpleHueLo="30"\n      crs:DefringePurpleHueHi="70"\n      crs:DefringeGreenAmount="0"\n      crs:DefringeGreenHueLo="40"\n      crs:DefringeGreenHueHi="60"\n      crs:Dehaze="0"\n      crs:Texture="0"\n      crs:ConvertToGrayscale="False"\n      crs:OverrideLookVignette="False"\n      crs:ToneCurveName="Custom"\n      crs:ToneCurveName2012="Custom"\n      crs:CameraProfile="Embedded"\n      crs:CameraProfileDigest="54650A341B5B5CCAE8442D0B43A92BCE">\n     <crs:ToneCurve>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurve>\n     <crs:ToneCurvePV2012>\n      <rdf:Seq>\n       <rdf:li>0, 6</rdf:li>\n       <rdf:li>28, 32</rdf:li>\n       <rdf:li>128, 128</rdf:li>\n       <rdf:li>204, 202</rdf:li>\n       <rdf:li>255, 251</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012>\n     <crs:ToneCurvePV2012Red>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>37, 32</rdf:li>\n       <rdf:li>114, 119</rdf:li>\n       <rdf:li>181, 191</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Red>\n     <crs:ToneCurvePV2012Green>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>40, 32</rdf:li>\n       <rdf:li>117, 121</rdf:li>\n       <rdf:li>179, 191</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Green>\n     <crs:ToneCurvePV2012Blue>\n      <rdf:Seq>\n       <rdf:li>0, 0</rdf:li>\n       <rdf:li>43, 30</rdf:li>\n       <rdf:li>119, 122</rdf:li>\n       <rdf:li>178, 201</rdf:li>\n       <rdf:li>255, 255</rdf:li>\n      </rdf:Seq>\n     </crs:ToneCurvePV2012Blue>\n     </rdf:Description>\n    </crs:Parameters>\n    </rdf:Description>\n   </crs:Preset>\n  </rdf:Description>\n </rdf:RDF>\n</x:xmpmeta>\n'
    );
    executeAction(sTID('Adobe Camera Raw Filter'), desc1, dialogMode);
  }

  // Crea
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Unisci visibili
    step3(); // Imposta
    step4(); // Imposta
    step5(); // Filtro Camera Raw
    step6(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

Fashion();
