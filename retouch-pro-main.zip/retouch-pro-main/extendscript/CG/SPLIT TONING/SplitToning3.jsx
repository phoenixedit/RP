$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Split Toning 3 ==============
//
function SplitToning3() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('layerSection'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc1.putObject(cTID('Usng'), sTID('layerSection'), desc2);
    desc1.putBoolean(sTID('below'), true);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Split Toning 3');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Clr '), cTID('Clr '), cTID('Bl  '));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Shadows');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Riempi
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putEnumerated(cTID('Usng'), cTID('FlCn'), cTID('Clr '));
    var desc2 = new ActionDescriptor();
    desc2.putDouble(cTID('Rd  '), 16.0000009462237);
    desc2.putDouble(cTID('Grn '), 1.00389105034992);
    desc2.putDouble(cTID('Bl  '), 209.000002741814);
    desc1.putObject(cTID('Clr '), sTID('RGBColor'), desc2);
    desc1.putUnitDouble(cTID('Opct'), cTID('#Prc'), 100);
    desc1.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Nrml'));
    executeAction(sTID('fill'), desc1, dialogMode);
  }

  // Nascondi
  function step8(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Crea
  function step9(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Applica immagine
  function step10(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var desc2 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Mrgd'));
    desc2.putReference(cTID('T   '), ref1);
    desc2.putBoolean(cTID('Invr'), true);
    desc2.putEnumerated(cTID('Clcl'), cTID('Clcn'), cTID('Mltp'));
    desc2.putBoolean(cTID('PrsT'), true);
    desc1.putObject(cTID('With'), cTID('Clcl'), desc2);
    executeAction(sTID('applyImageEvent'), desc1, dialogMode);
  }

  // Mostra
  function step11(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Imposta
  function step12(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('SftL'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Imposta
  function step13(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putUnitDouble(cTID('Opct'), cTID('#Prc'), 30);
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step14(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step15(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Highlights');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Riempi
  function step16(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putEnumerated(cTID('Usng'), cTID('FlCn'), cTID('Clr '));
    var desc2 = new ActionDescriptor();
    desc2.putDouble(cTID('Rd  '), 253.996109068394);
    desc2.putDouble(cTID('Grn '), 155.000005960464);
    desc2.putDouble(cTID('Bl  '), 2.00000011827797);
    desc1.putObject(cTID('Clr '), sTID('RGBColor'), desc2);
    desc1.putUnitDouble(cTID('Opct'), cTID('#Prc'), 100);
    desc1.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('Nrml'));
    executeAction(sTID('fill'), desc1, dialogMode);
  }

  // Nascondi
  function step17(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('hide'), desc1, dialogMode);
  }

  // Crea
  function step18(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Applica immagine
  function step19(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var desc2 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Mrgd'));
    desc2.putReference(cTID('T   '), ref1);
    desc2.putEnumerated(cTID('Clcl'), cTID('Clcn'), cTID('Mltp'));
    desc2.putBoolean(cTID('PrsT'), true);
    desc1.putObject(cTID('With'), cTID('Clcl'), desc2);
    executeAction(sTID('applyImageEvent'), desc1, dialogMode);
  }

  // Applica immagine
  function step20(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var desc2 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Mrgd'));
    desc2.putReference(cTID('T   '), ref1);
    desc2.putEnumerated(cTID('Clcl'), cTID('Clcn'), cTID('Mltp'));
    desc2.putBoolean(cTID('PrsT'), true);
    desc1.putObject(cTID('With'), cTID('Clcl'), desc2);
    executeAction(sTID('applyImageEvent'), desc1, dialogMode);
  }

  // Mostra
  function step21(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var list1 = new ActionList();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    list1.putReference(ref1);
    desc1.putList(cTID('null'), list1);
    executeAction(sTID('show'), desc1, dialogMode);
  }

  // Imposta
  function step22(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putEnumerated(cTID('Md  '), cTID('BlnM'), cTID('SftL'));
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step23(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID('RGB'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Selezione
  function step24(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), 'Split Toning 3');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(8);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(cTID('slct'), desc1, dialogMode);
  }

  // Sposta
  function step25(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var ref2 = new ActionReference();
    ref2.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Nxt '));
    desc1.putReference(cTID('T   '), ref2);
    executeAction(cTID('move'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Imposta
    step3(); // Crea
    step4(); // Imposta
    step5(); // Crea
    step6(); // Imposta
    step7(); // Riempi
    step8(); // Nascondi
    step9(); // Crea
    step10(); // Applica immagine
    step11(); // Mostra
    step12(); // Imposta
    step13(); // Imposta
    step14(); // Crea
    step15(); // Imposta
    step16(); // Riempi
    step17(); // Nascondi
    step18(); // Crea
    step19(); // Applica immagine
    step20(); // Applica immagine
    step21(); // Mostra
    step22(); // Imposta
    step23(); // Selezione
    step24(); // Selezione
    step25(); // Sposta
    return true;
  } catch (error) {
    return false;
  }
}

SplitToning3();
