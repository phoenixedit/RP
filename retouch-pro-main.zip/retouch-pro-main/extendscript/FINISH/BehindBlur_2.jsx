$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Behind Blur - 2 ==============
//
function BehindBlur_2() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('layerSection'));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(sTID('layerSectionStart'), 36);
    desc1.putInteger(sTID('layerSectionEnd'), 37);
    desc1.putString(cTID('Nm  '), 'Gruppo 1');
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Imposta
  function step2(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Behind Blur - 2');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea
  function step3(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(cTID('Lyr '));
    desc1.putReference(cTID('null'), ref1);
    desc1.putInteger(cTID('LyrI'), 38);
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Unisci visibili
  function step4(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Dplc'), true);
    executeAction(sTID('mergeVisible'), desc1, dialogMode);
  }

  // Imposta
  function step5(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Subject Blur - 2');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Crea livello copiato
  function step6(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  // Imposta
  function step7(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    desc1.putReference(cTID('null'), ref1);
    var desc2 = new ActionDescriptor();
    desc2.putString(cTID('Nm  '), 'Photo Blur - 2');
    desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
    executeAction(sTID('set'), desc1, dialogMode);
  }

  // Selezione
  function step8(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), 'Subject Blur - 2');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(39);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Seleziona soggetto
  function step9(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(sTID('sampleAllLayers'), false);
    executeAction(sTID('autoCutout'), desc1, dialogMode);
  }

  // Seleziona e maschera
  function step10(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putInteger(sTID('smartBrushRadius'), 0);
    desc1.putInteger(sTID('smartBrushSmooth'), 0);
    desc1.putUnitDouble(sTID('smartBrushFeather'), cTID('#Pxl'), 5.3);
    desc1.putUnitDouble(sTID('smartBrushContrast'), cTID('#Prc'), 0);
    desc1.putUnitDouble(sTID('smartBrushShiftEdge'), cTID('#Prc'), 0);
    desc1.putBoolean(sTID('sampleAllLayers'), false);
    desc1.putBoolean(sTID('smartBrushUseSmartRadius'), false);
    desc1.putBoolean(sTID('smartBrushDecontaminate'), false);
    desc1.putUnitDouble(sTID('smartBrushDeconAmount'), cTID('#Prc'), 100);
    desc1.putEnumerated(
      sTID('refineEdgeOutput'),
      sTID('refineEdgeOutput'),
      sTID('selectionOutputToSelection')
    );
    executeAction(sTID('smartBrushWorkspace'), desc1, dialogMode);
  }

  // Selezione
  function step11(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), 'Behind Blur - 2');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(36);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Crea
  function step12(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlS'));
    executeAction(sTID('make'), desc1, dialogMode);
  }

  // Inverti
  function step13(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('invert'), undefined, dialogMode);
  }

  // Selezione
  function step14(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putName(cTID('Lyr '), 'Photo Blur - 2');
    desc1.putReference(cTID('null'), ref1);
    desc1.putBoolean(cTID('MkVs'), false);
    var list1 = new ActionList();
    list1.putInteger(40);
    desc1.putList(cTID('LyrI'), list1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  // Controllo sfocatura
  function step15(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putUnitDouble(cTID('Rds '), cTID('#Pxl'), 16.6);
    executeAction(sTID('gaussianBlur'), desc1, dialogMode);
  }

  try {
    step1(); // Crea
    step2(); // Imposta
    step3(); // Crea
    step4(); // Unisci visibili
    step5(); // Imposta
    step6(); // Crea livello copiato
    step7(); // Imposta
    step8(); // Selezione
    step9(); // Seleziona soggetto
    step10(); // Seleziona e maschera
    step11(); // Selezione
    step12(); // Crea
    step13(); // Inverti
    step14(); // Selezione
    step15(); // Controllo sfocatura
    return true;
  } catch (error) {
    return false;
  }
}

BehindBlur_2();
