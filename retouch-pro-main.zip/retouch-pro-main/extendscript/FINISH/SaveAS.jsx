$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Save AS ==============
//
function SaveAS() {
  // Salva
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(cTID('Cpy '), true);
    try {
      executeAction(sTID('save'), desc1, dialogMode);
    } catch (e) {
      return;
    }
  }
  try {
    step1(true, true); // Salva
    return true;
  } catch (error) {
    return false;
  }
}

SaveAS();
