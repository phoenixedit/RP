$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== Save ==============
//
function Save() {
  // Salva
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    try {
      executeAction(sTID('save'), undefined, dialogMode);
    } catch (e) {
      return;
    }
  }

  try {
    step1(true, true); // Salva
    return true;
  } catch (error) {
    return false;
  }
}

Save();
