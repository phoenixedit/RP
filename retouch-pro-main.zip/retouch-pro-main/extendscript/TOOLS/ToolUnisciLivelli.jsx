$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== UnisciLivelli ==============
//
function TOOL_UnisciLivelli() {
  // Unisci visibili
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    try {
      executeAction(sTID('mergeVisible'), undefined, dialogMode);
    } catch (e) {}
  }

  try {
    step1(); // Unisci visibili
    return true;
  } catch (error) {
    return false;
  }
}

TOOL_UnisciLivelli();
