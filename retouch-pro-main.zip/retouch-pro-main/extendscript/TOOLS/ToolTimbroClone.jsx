$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== TOOL_Timbro_Clone ==============
//
function TOOL_Timbro_Clone() {
  // Selezione
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    var ref1 = new ActionReference();
    ref1.putClass(sTID('cloneStampTool'));
    desc1.putReference(cTID('null'), ref1);
    executeAction(sTID('select'), desc1, dialogMode);
  }

  try {
    step1(); // Selezione
    return true;
  } catch (error) {
    return false;
  }
}

TOOL_Timbro_Clone();
