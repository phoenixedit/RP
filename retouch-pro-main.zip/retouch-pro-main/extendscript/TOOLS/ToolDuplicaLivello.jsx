$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== DuplicaLivello ==============
//
function TOOL_DuplicaLivello() {
  // Crea livello copiato
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    executeAction(sTID('copyToLayer'), undefined, dialogMode);
  }

  try {
    step1(); // Crea livello copiato
    return true;
  } catch (error) {
    return false;
  }
}

TOOL_DuplicaLivello();
