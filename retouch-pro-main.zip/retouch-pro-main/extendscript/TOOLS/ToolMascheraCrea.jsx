$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== TOOL_Maschera ==============
//
function TOOL_Maschera_Crea() {
  // Crea
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putClass(cTID('Nw  '), cTID('Chnl'));
    var ref1 = new ActionReference();
    ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    desc1.putReference(cTID('At  '), ref1);
    desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    try {
      executeAction(sTID('make'), desc1, dialogMode);
    } catch (e) {
      return;
    }
  }

  try {
    step1(); // Crea
    return true;
  } catch (error) {
    return false;
  }
}

TOOL_Maschera_Crea();
