$.localize = true;

cTID = function (s) {
  return app.charIDToTypeID(s);
};
sTID = function (s) {
  return app.stringIDToTypeID(s);
};

//
//==================== TOOL_Seleziona_Cielo ==============
//
function TOOL_Seleziona_Cielo() {
  // Seleziona cielo
  function step1(enabled, withDialog) {
    if (enabled != undefined && !enabled) return;
    var dialogMode = withDialog ? DialogModes.ALL : DialogModes.NO;
    var desc1 = new ActionDescriptor();
    desc1.putBoolean(sTID('sampleAllLayers'), false);
    executeAction(sTID('selectSky'), desc1, dialogMode);
  }

  try {
    step1(); // Seleziona cielo
    return true;
  } catch (error) {
    return false;
  }
}

TOOL_Seleziona_Cielo();
