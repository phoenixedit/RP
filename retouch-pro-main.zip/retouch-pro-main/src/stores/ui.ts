import { shallow } from 'zustand/shallow';
import { createWithEqualityFn } from 'zustand/traditional';
import { Filter, Param } from '../types';
import { LocaleStrings } from '../i18n/translations';

type FnModalType =
  | 'skintone'
  | 'skintexture'
  | 'skinglow'
  | 'redremoval'
  | 'dreaming'
  | 'colorgrading'
  | 'colorclone'
  | 'moodbox'
  | null;

type UIStore = {
  aiError?: {
    request: {
      method: string;
      url: string;
      payload?: Record<string, unknown>;
    };
    response: Record<string, unknown>;
  };
  setAIError: (
    error:
      | {
          request: {
            method: string;
            url: string;
            payload?: Record<string, unknown>;
          };
          response: Record<string, unknown>;
        }
      | undefined
  ) => void;
  aiLayers: { layerId: number; image_id: string; documentId: number }[];
  addAILayer: (aiLayer: { layerId: number; image_id: string; documentId: number }) => void;
  removeAILayer: (layerId: number) => void;
  toast?: { type: 'success' | 'error'; text?: keyof LocaleStrings };
  setToast: (toast: 'success' | 'error' | undefined) => void;
  psToolbar: boolean;
  setPSToolbar: (psToolbar: boolean) => void;
  loading: boolean;
  setIsLoading: (loading: boolean) => void;
  loginError?: string;
  setLoginError: (error: string) => void;
  aiLoading: boolean;
  aiLoadingStatus?:
    | 'ai.starting_elaboration'
    | 'ai.uploading'
    | 'ai.requesting_upload'
    | 'ai.confirming_upload'
    | 'ai.elaborating';
  setAILoadingStatus: (
    aiLoadingStatus:
      | 'ai.starting_elaboration'
      | 'ai.uploading'
      | 'ai.requesting_upload'
      | 'ai.confirming_upload'
      | 'ai.elaborating'
  ) => void;
  setAILoading: (aiLoading: boolean) => void;
  previewData?: {
    url: string;
    key: string;
    uuid: string;
  };
  setPreviewData: (previewURL?: { url: string; key: string; uuid: string }) => void;
  filters: Record<string, Filter>;
  setDefaultFilters: (filters: Record<string, Filter>) => void;
  setFilters: (key: string, param: string, value: unknown) => void;
  toggleFilter: (filterKey: string) => void;
  loadingHasCancel: false | (() => void);
  setLoadingHasCancel: (loadingHasCancel: false | (() => void)) => void;
  isDocumentOpen: boolean;
  setDocumentOpen: (isDocumentOpen: boolean) => void;

  fnModalType: FnModalType;
  setFnModalType: (fnModalType: FnModalType) => void;

  footerHeight: number;
  setFooterHeight: (footerHeight: number) => void;
};

export const useUI = createWithEqualityFn<UIStore>()(
  (set) => ({
    footerHeight: 0,
    setFooterHeight: (footerHeight) => set({ footerHeight }),
    fnModalType: null,
    setFnModalType: (fnModalType) => set({ fnModalType }),
    isDocumentOpen: false,
    setDocumentOpen: (isDocumentOpen) => set({ isDocumentOpen }),
    aiError: undefined,
    setAIError: (aiError) => set({ aiError }),
    aiLayers: [],
    addAILayer: (aiLayer) => set((state) => ({ aiLayers: [...state.aiLayers, aiLayer] })),
    removeAILayer: (layerId) =>
      set((state) => ({ aiLayers: state.aiLayers.filter((l) => l.layerId !== layerId) })),
    aiLoadingStatus: undefined,
    aiLoading: false,
    setAILoading: (aiLoading) => set({ aiLoading }),
    loginError: undefined,
    setLoginError: (loginError) => set({ loginError }),
    psToolbar: false,
    setPSToolbar: (psToolbar: boolean) => set({ psToolbar }),
    loading: false,
    loadingHasCancel: false,
    setLoadingHasCancel: (loadingHasCancel) => set({ loadingHasCancel }),
    setIsLoading: (loading: boolean) => set({ loading }),
    setAILoadingStatus: (aiLoadingStatus) => set({ aiLoadingStatus }),
    setToast: (toast) => set({ toast: toast ? { type: toast } : undefined }),
    previewData: undefined,
    setPreviewData: (previewData) => set({ previewData }),
    filters: {},
    setDefaultFilters: (filters) => set({ filters }),
    setFilters: (key, param, value) => {
      set((state) => ({
        filters: {
          ...state.filters,
          [key]: {
            ...state.filters[key],
            params: {
              ...state.filters[key].params,
              [param]: {
                ...state.filters[key].params[param],
                value,
              } as Param,
            },
          },
        },
      }));
    },
    toggleFilter: (filterKey) => {
      set((state) => ({
        filters: {
          ...state.filters,
          [filterKey]: {
            ...state.filters[filterKey],
            active: !state.filters[filterKey].active,
          },
        },
      }));
    },
  }),
  shallow
);
