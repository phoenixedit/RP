import { createWithEqualityFn } from 'zustand/traditional';
import { persist } from 'zustand/middleware';
import { shallow } from 'zustand/shallow';
import { AppConfig, Languages } from '../types';
import { host } from 'uxp';

const hostLocale = host.uiLocale.split('-')[0];
const currentLanguage = (
  ['en', 'it', 'de', 'es', 'fr', 'ru'].includes(hostLocale) ? hostLocale : 'en'
) as Languages;

type AuthStore = {
  accessToken?: string;
  refreshToken?: string;
  idToken?: string;
  setAccessToken: (token: string) => void;
  setIdToken: (token: string) => void;
  setRefreshToken: (token: string) => void;
  logout: () => void;
  currentLanguage: Languages;
  setCurrentLanguage: (language: Languages) => void;
};

export const useAuth = createWithEqualityFn<AuthStore>()(
  persist(
    (set) => ({
      accessToken: undefined,
      idToken: undefined,
      refreshToken: undefined,
      currentLanguage,
      setAccessToken: (accessToken: string) => set({ accessToken }),
      setIdToken: (idToken: string) => set({ idToken }),
      setRefreshToken: (refreshToken: string) => set({ refreshToken }),
      setCurrentLanguage: (language) => set({ currentLanguage: language }),
      logout: () =>
        set({
          accessToken: undefined,
          idToken: undefined,
        }),
    }),
    {
      name: 'auth-storage',
    }
  ),
  shallow
);
