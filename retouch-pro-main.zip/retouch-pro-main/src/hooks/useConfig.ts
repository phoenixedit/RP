import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { AppConfig } from '../types';
import { appConfigURL } from '../utils';

export const useConfig = () => {
  const {
    data: appConfig,
    isFetching: isFetchingAppConfig,
    isError: isAppConfigError,
  } = useQuery<AppConfig>(['appConfig'], async () => {
    const { data } = await axios.get<AppConfig>(appConfigURL);

    axios.defaults.baseURL = data.api.basePath;
    return data;
  });

  return { appConfig, isFetchingAppConfig, isAppConfigError };
};
