import { localeStrings, type LocaleStrings } from '../i18n/translations';
import { useAuth } from '../stores/auth';

export const useTranslate = () => {
  const { currentLanguage } = useAuth(({ currentLanguage }) => ({ currentLanguage }));

  const t = (key: keyof LocaleStrings) => {
    return localeStrings[currentLanguage][key] ?? key;
  };

  return { t };
};
