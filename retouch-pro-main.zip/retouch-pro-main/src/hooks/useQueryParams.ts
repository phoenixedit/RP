import React from 'react';
import { useLocation } from 'react-router-dom';

export const useQueryParams = <T extends string>(param: string): T => {
  const { search } = useLocation();

  return React.useMemo<T>(() => new URLSearchParams(search).get(param) as T, [search]);
};
