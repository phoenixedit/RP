import axios from 'axios';
import { action } from 'photoshop';
import { storage } from 'uxp';
import { useUI } from './stores/ui';
import { compareVersions } from 'compare-versions';
import { useTranslate } from './hooks/useTranslate';
const packageJson = require('../package.json');
const ps = require('photoshop');

const { localFileSystem: fs } = storage;

/*

export const fetchAndPlaceImage = async (
  url: string,
  layerId: number,
  documentId: number,
  imageId: string
) => {
  const imageResponse = await fetch(url);
  const blob = await imageResponse.arrayBuffer();
  await placeImage(blob, layerId, documentId, imageId);
};

export const createAILayer = async (layerText: string) => {
  let layerId = null;
  let documentId = ps.app.activeDocument.id;
  try {
    await ps.core.executeAsModal(async () => {
      const createLayerBatchPlay = {
        _obj: 'make',
        _target: [
          {
            _ref: 'layer',
          },
        ],
      };
      const [result] = await ps.action.batchPlay([createLayerBatchPlay], {});

      const layerID = result.layerID;

      const renameLayerBatchPlay = {
        _obj: 'set',
        _target: [
          {
            _ref: 'layer',
            _id: layerID,
          },
        ],
        to: {
          _obj: 'layer',
          name: layerText,
        },
      };

      await ps.action.batchPlay([renameLayerBatchPlay], {});

      layerId = layerID;
    });

    if (!layerId) {
      throw new Error('Failed to create layer');
    }
    return { layerId, documentId };
  } catch (error) {
    useUI.setState({ toast: { type: 'error' } });
  }
};

const placeImage = async (
  blob: ArrayBuffer,
  layerId: number,
  documentId: number,
  imageId: string
) => {
  try {
    const tempPath = await fs.getTemporaryFolder();

    const tempFile = await tempPath.createFile('temp.png', { overwrite: true });
    await tempFile.write(blob, {});

    const filetoken = fs.createSessionToken(tempFile);

    await ps.core.executeAsModal(async () => {
      const batchPlayObjectSelectDocument = {
        _obj: 'select',
        _target: {
          _ref: 'document',
          _id: documentId,
        },
      };

      await ps.action.batchPlay([batchPlayObjectSelectDocument], {});

      const batchPlayObject = {
        _obj: 'placeEvent',
        replaceLayer: {
          _obj: 'placeEvent',
          to: {
            _ref: 'layer',
            _id: layerId,
          },
        },
        _isCommand: true,
        fileType: 'png',
        null: {
          _path: filetoken,
          _kind: 'local',
        },
      };
      const [resultLayer] = await ps.action.batchPlay([batchPlayObject], {});

      const renameLayerBatchPlay = {
        _obj: 'set',
        _target: [
          {
            _ref: 'layer',
            _id: resultLayer.ID,
          },
        ],
        to: {
          _obj: 'layer',
          name: imageId,
        },
        layerID: [layerId],
      };

      await ps.action.batchPlay([renameLayerBatchPlay], {});

      // const width = ps.app.activeDocument.activeLayers[0].bounds.width;
      // const height = ps.app.activeDocument.activeLayers[0].bounds.height;

      // ps.app.activeDocument.resizeCanvas(width, height);

      // const batchPlayObjectMerge = {
      //   _obj: 'mergeVisible',
      // };
      // await ps.action.batchPlay([batchPlayObjectMerge], {});
    });
  } catch (error) {
    useUI.setState({ toast: { type: 'error' } });
  }
};

export const getCurrentLayerData = async () => {
  try {
    let result;
    let size;
    await ps.core.executeAsModal(async () => {
      try {
        const p = await ps.imaging.getPixels({
          componentSize: 8,
          applyAlpha: true,
        });

        const data = ps.imaging.encodeImageData({
          imageData: p.imageData,
        });

        size = p.size;
        result = data;
      } catch {
        // Do nothing
      }
    });

    if (size > 50 * 1000 * 1000) {
      throw new Error('apiError.oversize');
    }

    if (!result) {
      throw new Error('apiError.noData');
    }

    return result;
  } catch (error) {
    console.log(error);
    useUI.setState({ toast: { type: 'error', text: error.message } });

    return false;
  }
};

*/

const { batchPlay } = action;

export const ScriptRun = async (jsxFile: string, showHistory: boolean, showSuccess: boolean) => {
  const bpOptions = {
    synchronousExecution: false,
    modalBehavior: 'execute' as const,
  };

  if (!showHistory) {
    bpOptions['historyStateInfo'] = {
      name: 'Retouch Pro',
      target: {
        _ref: 'document',
        _enum: 'ordinal',
        _value: 'targetEnum',
      },
    };
  }

  try {
    let pluginFolder = await fs.getPluginFolder();
    let jsxFileObject = await pluginFolder.getEntry(jsxFile);
    var filetoken = await fs.createSessionToken(jsxFileObject);

    await ps.core.executeAsModal(async () => {
      const [response] = await batchPlay(
        [
          {
            _obj: 'AdobeScriptAutomation Scripts',
            javaScript: {
              _path: filetoken,
              _kind: 'local',
            },
            javaScriptMessage: 'JSM',
            _isCommand: true,
            _options: {
              dialogOptions: 'dontDisplay',
            },
            _target: {
              _enum: 'automationTool',
              _value: 'automationToolClass',
              _ref: 'automationTool',
            },
          },
        ],
        bpOptions
      );
      if (showSuccess) {
        useUI.setState({
          toast: response.javaScriptMessage === 'false' ? { type: 'error' } : { type: 'success' },
        });
      }
    });
  } catch (e) {
    useUI.setState({ toast: { type: 'error' } });
  }
};

export const checkIf8BitMode = async () => {
  try {
    let is8Bit = false;
    await ps.core.executeAsModal(async () => {
      const [result] = await batchPlay(
        [
          {
            _obj: 'get',
            _target: {
              _ref: 'document',
              _enum: 'ordinal',
              _value: 'targetEnum',
            },
          },
        ],
        {
          synchronousExecution: true,
          modalBehavior: 'execute',
        }
      );

      if (result.depth === 8) {
        is8Bit = true;
      } else {
        is8Bit = false;
      }
    });
    return is8Bit;
  } catch (error) {
    return false;
  }
};

// const { localFileSystem: uxpFS } = storage;

// export { uxpFS };

export const needsUpdate = async () => {
  const { data } = await axios.get(
    'https://api.retouchzone.com/versioning/getVersionInfo/retouch_pro_panel',
    {
      headers: {
        Authorization: 'Basic cmV0b3VjaHpvbmU6YWM1U2o0JDg5eD9HNFY=',
      },
    }
  );

  if (!data.success) {
    throw new Error('Failed to check for update');
  }

  const result = compareVersions(packageJson.version, data.data.version);

  console.log('current version', packageJson.version);
  console.log('latest version', data.data.version);
  console.log('result', result);
  console.log('forced', data.data.forced);

  if (result === 0) {
    return false;
  } else {
    return result === -1 && data.data.forced === true;
  }
};

export const checkLicense = async () => {
  // const dataFolder = await uxpFS.getDataFolder();
  // const files = await dataFolder.getEntries();
  // const activationFile = files.find((file) => file.name === 'retouchpro.license');

  const session = localStorage.getItem('retouchpro.license');
  if (session) {
    // const session = await (activationFile as storage.File).read({});

    const payload = {
      session,
      product: JSON.stringify({ name: 'retouch-pro', mode: 'uxp', version: '5.1.0' }),
    };

    const formBody = [];
    for (const property in payload) {
      const encodedKey = encodeURIComponent(property);
      const encodedValue = encodeURIComponent(payload[property]);
      formBody.push(encodedKey + '=' + encodedValue);
    }
    const body = formBody.join('&');

    const { data } = await axios.post('https://api.retouchzone.com/activate', body, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    if (data.error) {
      throw new Error(data.error);
    }

    return true;
  } else {
    return false;
  }
};

export const isProduction = true;
export const apiKey = 'jsepeEY37l3lziZPCnkmd2z3T1jSF2io8NbBH0xC';
export const standaloneURL = 'https://beta.zeroretouch.net';

// export const isProduction = false;
// export const apiKey = 'hdwT6vWplh22NnzmE2axZ3RBF0N6TZ9p6wq3ZYOW';
// export const standaloneURL = 'https://d3gzsdepi5xw86.cloudfront.net';

export const appConfigURL = `${standaloneURL}/assets/app-config${isProduction ? '.prod' : ''}.json`;

export const cancelCommands = {
  moodbox: [],
  colorclone: [
    {
      commandName: 'Color Clone',
      command: [
        // Seleziona il livello "Retouch Clone"
        { _obj: 'select', _target: [{ _ref: 'layer', _name: 'Retouch Clone' }] },
        // Seleziona il livello "Retouch Clone Sat" e aggiungilo alla selezione
        {
          _obj: 'select',
          _target: [{ _ref: 'layer', _name: 'Retouch Clone Sat' }],
          selectionModifier: { _enum: 'selectionModifierType', _value: 'addToSelection' },
        },
        // Elimina i livelli selezionati
        {
          _obj: 'delete',
          _target: [{ _ref: 'layer', _enum: 'ordinal', _value: 'targetEnum' }],
        },
      ],
      options: {
        synchronousExecution: true,
      },
    },
  ],
  colorgrading: [
    {
      commandName: 'Color Grading',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'mrtemp', _ref: 'layer' }],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Annulla Color Balance',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      },
    },
    {
      commandName: 'Color Grading',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
  dreaming: [
    {
      commandName: 'Dreaming',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Dream 1', _ref: 'layer' }],
        },
      ],
      options: {}
    },
    {
      commandName: 'Dreaming',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Dream 2', _ref: 'layer' }],
        },
      ],
      options: {}
    },
    {
      commandName: 'Dreaming',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
  redremoval: [
    {
      commandName: 'Red Removal',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'red remover', _ref: 'layer' }],
        },
      ],
      options: {},
    },
    {
      commandName: 'Color Grading',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
  skinglow: [
    {
      commandName: 'Skin Glow',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Contrast', _ref: 'layer' }],
        },
      ],
      options: {},
    },
    {
      commandName: 'Skin Glow',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Light', _ref: 'layer' }],
        },
      ],
      options: {},
    },
    {
      commandName: 'Color Grading',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
  skintexture: [
    {
      commandName: 'Skin Texture',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Skin Texture', _ref: 'layer' }],
        },
      ],
      options: {},
    },
    {
      commandName: 'Skin Texture',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
  skintone: [
    {
      commandName: 'Skin Tone',
      command: [
        {
          _obj: 'delete',
          _target: [{ _name: 'Skin Tone', _ref: 'layer' }],
        },
      ],
      options: {},
    },
    {
      commandName: 'Skin Tone',
      command: [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ],
      options: {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    }
  ],
};

export const modeCheckWrapper = async (scriptRun: () => Promise<void>, t: ReturnType<typeof useTranslate>['t']) => {
  const is8Bit = await checkIf8BitMode();
  if (is8Bit) {
    await scriptRun();
  } else {
    alert(t('general.8bit_mode_alert'));
  }
};

export const get8BitModeLabel = (label: string, t: ReturnType<typeof useTranslate>['t']) => {
 return `${label} ${t('general.8bit_mode_label')}`;
}
