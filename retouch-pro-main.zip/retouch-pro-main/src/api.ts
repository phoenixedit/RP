import axios, { AxiosError } from 'axios';
import { useAuth } from './stores/auth';
import { useUI } from './stores/ui';

const getPhotoshopAlbumId = async () => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.get<{ uuid: string; name: string }[]>('/albums/obtain', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const albumId = data.find((album) => album.name === 'Photoshop')?.uuid;

  if (!albumId) {
    const { data } = await axios.post<{ album_uuid: string }>(
      '/albums/create',
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    return data.album_uuid;
  }

  return albumId;
};

const getBalance = async () => {
  const token = useAuth.getState().idToken;
  const { data } = await axios.get('/user/wallet/balance', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const { balance } = data;

  return balance ?? 0;
};

const getElaboratedPhotos = async () => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.get('/images/retrieve-paginated?page=0', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const { images, total } = data;

  if (total > 1) {
    const promises = Array.from({ length: total - 1 }, (_, i) =>
      axios.get(`/images/retrieve-paginated?page=${i + 1}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
    );

    const allPhotos = await Promise.all(promises);

    return [images, ...allPhotos.map((photos) => photos.data.images)].flat();
  }

  return images;
};

const getActivities = async () => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.get('/activity/get-elaborations?page=0', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const { activities, total_pages } = data;

  if (total_pages > 1) {
    const promises = Array.from({ length: total_pages - 1 }, (_, i) =>
      axios.get(`/activity/get-elaborations?page=${i + 1}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
    );

    const allActivities = await Promise.all(promises);

    return [activities, ...allActivities.map((activities) => activities.data.activities)].flat();
  }

  return activities;
};

const getPricing = async () => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.get('/payments/info/pricing', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const { filters } = data;
  return filters.reduce(
    (acc, filter) => ({ ...acc, [filter.filter_number]: filter.tokens_for_photo }),
    {}
  );
};

const getTimings = async () => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.get('/activity/info', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  const { filter_execution_time } = data;
  return filter_execution_time.reduce(
    (acc, filter) => ({
      ...acc,
      [filter.filter_number]: filter.seconds_for_photo
        ? Math.floor(filter.seconds_for_photo / 60)
        : 0,
    }),
    {}
  );
};

const previewPhoto = async (
  file: File,
  filters: {
    filterNumber: number;
    referenceImageKey?: string;
    params: {
      [key: string]: number;
    };
  }[],
  previewData?: {
    url: string;
    key: string;
    uuid: string;
  }
) => {
  const token = useAuth.getState().idToken;

  if (!previewData) {
    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.requesting_upload' });

    const { data: requestUploadResponse } = await axios.get<{
      original: {
        signedURL: {
          url: string;
          fields: {
            key: string;
            AWSAccessKeyId: string;
            'x-amz-security-token': string;
            policy: string;
            signature: string;
          };
        };
      };
    }>('/images/request-upload?fileName=preview.png&group=gr0', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if ('errorMessage' in requestUploadResponse) {
      useUI.getState().setAIError({
        request: {
          method: 'GET',
          url: '/images/request-upload?fileName=preview.png&group=gr0',
        },
        response: requestUploadResponse,
      });
      throw new AxiosError('api-error');
    }

    const pipeline = filters.map((filter) => ({
      ...filter,
      referenceImageKey: requestUploadResponse.original.signedURL.fields.key,
    }));

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.uploading' });

    const formData = new FormData();

    formData.append('key', requestUploadResponse.original.signedURL.fields.key);
    formData.append(
      'AWSAccessKeyId',
      requestUploadResponse.original.signedURL.fields.AWSAccessKeyId
    );
    formData.append(
      'x-amz-security-token',
      requestUploadResponse.original.signedURL.fields['x-amz-security-token']
    );
    formData.append('policy', requestUploadResponse.original.signedURL.fields.policy);
    formData.append('signature', requestUploadResponse.original.signedURL.fields.signature);
    formData.append('file', file, 'preview.png');

    await axios.post(requestUploadResponse.original.signedURL.url, formData, {
      headers: {
        'Content-Type': 'image/*',
      },
    });

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.confirming_upload' });
    const { data: confirmUploadResponse } = await axios.post<{
      image: {
        image_id: string;
        image_key: string;
        thumb_key: string;
        mini_key: string;
        // url: string;
        // upload_time: string;
      };
    }>(
      '/images/confirm-and-generate-thumb',
      {
        img_key: requestUploadResponse.original.signedURL.fields.key,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if ('errorMessage' in confirmUploadResponse) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/images/confirm-and-generate-thumb',
          payload: {
            img_key: requestUploadResponse.original.signedURL.fields.key,
          },
        },
        response: confirmUploadResponse,
      });
      throw new AxiosError('api-error');
    }

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.elaborating' });
    const { data: result } = await axios.post<{ signedURL: string }>(
      '/preview/elaborate-thumbnail-v2',
      {
        image_key: {
          uuid: confirmUploadResponse.image.image_id,
          key: confirmUploadResponse.image.image_key,
        },
        pipeline,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if ('errorMessage' in result) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/preview/elaborate-thumbnail-v2',
          payload: {
            image_key: {
              uuid: confirmUploadResponse.image.image_id,
              key: confirmUploadResponse.image.image_key,
            },
            pipeline,
          },
        },
        response: result,
      });
      throw new AxiosError('api-error');
    }

    return {
      url: result.signedURL,
      key: confirmUploadResponse.image.image_key,
      uuid: confirmUploadResponse.image.image_id,
    };
  } else {
    const pipeline = filters.map((filter) => ({
      ...filter,
      referenceImageKey: previewData.key,
    }));

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.elaborating' });

    const { data: result } = await axios.post<{ signedURL: string }>(
      '/preview/elaborate-thumbnail-v2',
      {
        image_key: {
          uuid: previewData.uuid,
          key: previewData.key,
        },
        pipeline,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if ('errorMessage' in result) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/preview/elaborate-thumbnail-v2',
          payload: {
            image_key: {
              uuid: previewData.uuid,
              key: previewData.key,
            },
            pipeline,
          },
        },
        response: result,
      });
      throw new AxiosError('api-error');
    }

    return {
      ...previewData,
      url: result.signedURL,
    };
  }
};

const applyAI = async (
  file: File,
  filters: {
    filterNumber: number;
    referenceImageKey?: string;
    params: {
      [key: string]: number;
    };
  }[],
  aiLayerId: number,
  documentId: number,
  previewData?: {
    url: string;
    key: string;
    uuid: string;
  }
) => {
  const token = useAuth.getState().idToken;

  if (!previewData) {
    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.requesting_upload' });

    const { data: requestUploadResponse } = await axios.get<{
      original: {
        signedURL: {
          url: string;
          fields: {
            key: string;
            AWSAccessKeyId: string;
            'x-amz-security-token': string;
            policy: string;
            signature: string;
          };
        };
      };
    }>('/images/request-upload?fileName=preview.png&group=gr0', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if ('errorMessage' in requestUploadResponse) {
      useUI.getState().setAIError({
        request: {
          method: 'GET',
          url: '/images/request-upload?fileName=preview.png&group=gr0',
        },
        response: requestUploadResponse,
      });
      throw new AxiosError('api-error');
    }

    const pipeline = filters.map((filter) => ({
      ...filter,
      referenceImageKey: requestUploadResponse.original.signedURL.fields.key,
    }));

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.uploading' });

    const formData = new FormData();

    formData.append('key', requestUploadResponse.original.signedURL.fields.key);
    formData.append(
      'AWSAccessKeyId',
      requestUploadResponse.original.signedURL.fields.AWSAccessKeyId
    );
    formData.append(
      'x-amz-security-token',
      requestUploadResponse.original.signedURL.fields['x-amz-security-token']
    );
    formData.append('policy', requestUploadResponse.original.signedURL.fields.policy);
    formData.append('signature', requestUploadResponse.original.signedURL.fields.signature);
    formData.append('file', file, 'preview.png');

    await axios.post(requestUploadResponse.original.signedURL.url, formData, {
      headers: {
        'Content-Type': 'image/*',
      },
    });

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.confirming_upload' });

    const albumId = await getPhotoshopAlbumId();

    const { data: confirmUploadResponse } = await axios.post<{
      image: {
        image_id: string;
        image_key: string;
        thumb_key: string;
        mini_key: string;
        // url: string;
        // upload_time: string;
      };
    }>(
      '/images/confirm-and-generate-thumb',
      {
        img_key: requestUploadResponse.original.signedURL.fields.key,
        album_uuid: albumId,
        album_name: 'Photoshop',
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if ('errorMessage' in confirmUploadResponse) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/images/confirm-and-generate-thumb',
          payload: {
            img_key: requestUploadResponse.original.signedURL.fields.key,
            album_uuid: albumId,
            album_name: 'Photoshop',
          },
        },
        response: confirmUploadResponse,
      });
      throw new AxiosError('api-error');
    }

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.starting_elaboration' });

    const { data: result } = await axios.post<{ signedURL: string }>(
      '/activity/start-elaboration-v2',
      {
        images_ids: [confirmUploadResponse.image.image_id],
        pipeline,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (result && 'errorMessage' in result) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/activity/start-elaboration-v2',
          payload: {
            images_ids: [confirmUploadResponse.image.image_id],
            pipeline,
          },
        },
        response: result,
      });
      throw new AxiosError('api-error');
    }
    useUI
      .getState()
      .addAILayer({
        layerId: aiLayerId,
        image_id: confirmUploadResponse.image.image_id,
        documentId,
      });
    return true;
  } else {
    const pipeline = filters.map((filter) => ({
      ...filter,
      referenceImageKey: previewData.key,
    }));

    useUI.setState({ aiLoading: true, aiLoadingStatus: 'ai.starting_elaboration' });

    const { data: result } = await axios.post<{ signedURL: string }>(
      '/activity/start-elaboration-v2',
      {
        images_ids: [previewData.uuid],
        pipeline,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (result && 'errorMessage' in result) {
      useUI.getState().setAIError({
        request: {
          method: 'POST',
          url: '/activity/start-elaboration-v2',
          payload: {
            images_ids: [previewData.uuid],
            pipeline,
          },
        },
        response: result,
      });
      throw new AxiosError('api-error');
    }

    useUI.getState().addAILayer({ layerId: aiLayerId, documentId, image_id: previewData.uuid });

    return true;
  }
};

const deleteImage = async (imageId: string) => {
  const token = useAuth.getState().idToken;

  const { data } = await axios.post<unknown>(
    '/images/delete',
    {
      images_ids: [imageId],
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return data;
};

const api = {
  getBalance,
  getElaboratedPhotos,
  getPricing,
  getActivities,
  previewPhoto,
  applyAI,
  deleteImage,
  getTimings,
};

export default api;
