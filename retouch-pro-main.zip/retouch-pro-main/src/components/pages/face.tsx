import type { ActionDescriptor } from 'photoshop';
import React, { FC, Fragment, useMemo } from 'react';
import { useTranslate } from '../../hooks/useTranslate';
import { useUI } from '../../stores/ui';
import { ActionSection } from '../../types';
import { cancelCommands, get8BitModeLabel, modeCheckWrapper, ScriptRun } from '../../utils';
import { Accordion } from '../common/accordion';
import { ActionCategory, ActionComponent, ActionsContainer } from '../common/action';
import { Container } from '../common/container';
const { core, action, app } = require('photoshop');
const { localFileSystem } = require('uxp').storage;

const toggleLayersPalette = async () => {
  await core.executeAsModal(async () => {
    await action.batchPlay(
      [
        {
          _obj: 'select',
          _target: [
            {
              _enum: 'menuItemType',
              _ref: 'menuItemClass',
              _value: 'toggleLayersPalette',
            },
          ],
        },
      ] as unknown as ActionDescriptor[],
      {
        historyStateInfo: {
          name: 'Mostra pannello livelli',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    );
  });
};

const createSkinToneLayer = async () => {
  const commands = [
    {
      _obj: 'make',
      _target: [{ _ref: 'adjustmentLayer' }],
      using: {
        _obj: 'adjustmentLayer',
        type: {
          _obj: 'colorBalance',
          highlightLevels: [0, 0, 0],
          midtoneLevels: [0, 0, 0],
          shadowLevels: [0, 0, 0],
          preserveLuminosity: true,
        },
      },
    },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', name: 'Skin Tone' },
    },
    {
      _obj: 'colorRange',
      colorModel: 0,
      colors: { _enum: 'colors', _value: 'skinTone' },
      fuzziness: 60,
    },
    {
      _obj: 'make',
      at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
      new: { _class: 'channel' },
      using: { _enum: 'userMaskEnabled', _value: 'revealSelection' },
    },
  ];

  await action.batchPlay(commands as unknown as ActionDescriptor[], {
    modalBehavior: 'execute',
  });
};

const createSkinTextureLayer = async () => {
  await action.batchPlay(
    [
      { _obj: 'copyToLayer' },
      {
        _obj: 'highPass',
        radius: { _unit: 'pixelsUnit', _value: 2.0 },
      },
      {
        _obj: 'set',
        _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
        to: { _obj: 'layer', mode: { _enum: 'blendMode', _value: 'linearLight' } },
      },
      {
        _obj: 'set',
        _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
        to: { _obj: 'layer', name: 'Skin Texture' },
      },
    ],
    { modalBehavior: 'execute' }
  );

  await action.batchPlay(
    [
      {
        _obj: 'set',
        _target: [{ _name: 'Skin Texture', _ref: 'layer' }],
        to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: 0 } },
      },
    ],
    {}
  );

  await action.batchPlay(
    [
      {
        UseFacesKey: true,
        _obj: 'colorRange',
        colorModel: 0,
        colors: { _enum: 'colors', _value: 'skinTone' },
        fuzziness: 40,
      },
      {
        _obj: 'make',
        at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
        new: { _class: 'channel' },
        using: { _enum: 'userMaskEnabled', _value: 'revealSelection' },
      },
    ],
    { modalBehavior: 'execute' }
  );
};

const createGlowingSkin = async () => {
  const commands = [
    { _obj: 'make', _target: [{ _ref: 'layer' }] },

    { _obj: 'mergeVisible', duplicate: true },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', name: 'Contrast' },
    },

    {
      _obj: 'set',
      _target: [{ _name: 'Contrast', _ref: 'layer' }],
      to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: 0 } },
    },

    { _obj: 'mergeVisible', duplicate: true },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', name: 'Light' },
    },

    {
      _obj: 'set',
      _target: [{ _name: 'Light', _ref: 'layer' }],
      to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: 0 } },
    },

    {
      UseFacesKey: true,
      _obj: 'colorRange',
      colorModel: 0,
      colors: { _enum: 'colors', _value: 'skinTone' },
      fuzziness: 40,
    },
    {
      _obj: 'make',
      at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
      new: { _class: 'channel' },
      using: { _enum: 'userMaskEnabled', _value: 'revealSelection' },
    },

    {
      _obj: 'select',
      _target: [{ _name: 'Contrast', _ref: 'layer' }],
      makeVisible: false,
    },
    {
      UseFacesKey: true,
      _obj: 'colorRange',
      colorModel: 0,
      colors: { _enum: 'colors', _value: 'skinTone' },
      fuzziness: 40,
    },
    {
      _obj: 'make',
      at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
      new: { _class: 'channel' },
      using: { _enum: 'userMaskEnabled', _value: 'revealSelection' },
    },

    {
      _obj: 'select',
      _target: [{ _enum: 'channel', _ref: 'channel', _value: 'RGB' }],
      makeVisible: false,
    },

    { _obj: 'hide', null: [{ _name: 'Light', _ref: 'layer' }] },

    {
      _obj: 'gaussianBlur',
      radius: { _unit: 'pixelsUnit', _value: 34.6 },
    },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', mode: { _enum: 'blendMode', _value: 'softLight' } },
    },
    { _obj: 'show', null: [{ _name: 'Light', _ref: 'layer' }] },

    {
      _obj: 'select',
      _target: [{ _name: 'Light', _ref: 'layer' }],
      makeVisible: false,
    },
    {
      _obj: 'levels',
      adjustment: [
        {
          _obj: 'levelsAdjustment',
          channel: { _enum: 'channel', _ref: 'channel', _value: 'composite' },
          gamma: 2.02,
        },
      ],
      presetKind: { _enum: 'presetKindType', _value: 'presetKindCustom' },
    },

    {
      _obj: 'select',
      _target: [{ _name: 'Contrast', _ref: 'layer' }],
      makeVisible: false,
    },
    {
      _obj: 'move',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      adjustment: false,
      to: { _index: 3, _ref: 'layer' },
      version: 5,
    },
  ];
  await action.batchPlay(commands, { modalBehavior: 'execute' });
};

const createRedRemoval = async () => {
  await action.batchPlay(
    [
      {
        _obj: 'make',
        _target: [{ _ref: 'adjustmentLayer' }],
        using: {
          _obj: 'adjustmentLayer',
          type: {
            _obj: 'hueSaturation',
            colorize: false,
            presetKind: { _enum: 'presetKindType', _value: 'presetKindDefault' },
          },
        },
      },

      {
        _obj: 'select',
        _target: [{ _enum: 'channel', _ref: 'channel', _value: 'RGB' }],
        makeVisible: false,
      },

      {
        _obj: 'set',
        _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
        to: { _obj: 'layer', name: 'red remover' },
      },

      {
        _obj: 'delete',
        _target: [{ _enum: 'channel', _ref: 'channel', _value: 'mask' }],
      },

      {
        UseFacesKey: true,
        _obj: 'colorRange',
        colorModel: 0,
        colors: { _enum: 'colors', _value: 'skinTone' },
        fuzziness: 40,
      },

      {
        _obj: 'make',
        at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
        new: { _class: 'channel' },
        using: { _enum: 'userMaskEnabled', _value: 'revealSelection' },
      },

      {
        _obj: 'select',
        _target: [{ _enum: 'channel', _ref: 'channel', _value: 'RGB' }],
        makeVisible: false,
      },

      {
        _obj: 'set',
        _target: [{ _enum: 'ordinal', _ref: 'adjustmentLayer', _value: 'targetEnum' }],
        to: {
          _obj: 'hueSaturation',
          adjustment: [
            {
              _obj: 'hueSatAdjustmentV2',
              beginRamp: 315,
              beginSustain: 345,
              endRamp: 45,
              endSustain: 15,
              hue: 0,
              lightness: 0,
              localRange: 1,
              saturation: 0,
            },
          ],
        },
      },
    ],
    { modalBehavior: 'execute' }
  );
};

const createDreaming = async () => {
  const commands = [
    { _obj: 'make', _target: [{ _ref: 'layer' }] },
    { _obj: 'mergeVisible', duplicate: true },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', name: 'Dream 1' },
    },
    {
      _obj: 'duplicate',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      name: 'Dream 2',
    },
    { _obj: 'select', _target: [{ _name: 'Dream 1', _ref: 'layer' }] },
    { _obj: 'gaussianBlur', radius: { _unit: 'pixelsUnit', _value: 40 } },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', mode: { _enum: 'blendMode', _value: 'overlay' } },
    },
    { _obj: 'select', _target: [{ _name: 'Dream 2', _ref: 'layer' }] },
    { _obj: 'gaussianBlur', radius: { _unit: 'pixelsUnit', _value: 40 } },
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', mode: { _enum: 'blendMode', _value: 'lighten' } },
    },
    {
      _obj: 'set',
      _target: [{ _name: 'Dream 1', _ref: 'layer' }],
      to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: 0 } },
    },
    {
      _obj: 'set',
      _target: [{ _name: 'Dream 2', _ref: 'layer' }],
      to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: 0 } },
    },
  ];
  await action.batchPlay(commands, {
    historyStateInfo: {
      name: 'Dream',
      target: { _ref: 'document', _enum: 'ordinal', _value: 'targetEnum' },
    },
  });
};

const createColorGrading = async () => {
  const commands = [
    // Create a "Color Balance" adjustment layer
    {
      _obj: 'make',
      _target: [{ _ref: 'adjustmentLayer' }],
      using: {
        _obj: 'adjustmentLayer',
        type: {
          _obj: 'colorBalance',
          highlightLevels: [0, 0, 0],
          midtoneLevels: [0, 0, 0],
          preserveLuminosity: true,
          shadowLevels: [0, 0, 0],
        },
      },
    },
    // Rename the adjustment layer to "mrtemp"
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: { _obj: 'layer', name: 'mrtemp' },
    },
  ];

  await action.batchPlay(commands, {
    historyStateInfo: {
      name: 'Ctp Color Balance',
      target: { _ref: 'document', _enum: 'ordinal', _value: 'targetEnum' },
    },
  });
};

const applyCloneWithSource = async (sourceDocumentName: string) => {
  const command = [
    // Crea un nuovo livello duplicato dal livello visibile corrente
    { _obj: 'make', _target: [{ _ref: 'layer' }] },

    // Duplica e unisci i livelli visibili
    { _obj: 'mergeVisible', duplicate: true },

    // Applica il Retouch Clone dal documento sorgente
    {
      _obj: 'matchColor',
      colorRange: 100, // Gamma di colori applicata (massimo)
      fade: 0, // Nessuna dissolvenza applicata
      neutralize: true, // Neutralizza il colore per ridurre eventuali dominanti
      lightness: 100, // Aumenta la luminosità del risultato
      selection: true, // Applica l'effetto a tutta la selezione
      source: {
        _ref: [
          { _property: 'background', _ref: 'layer' }, // Livello di background del documento sorgente
          { _name: sourceDocumentName, _ref: 'document' }, // Nome del documento sorgente
        ],
      },
    },

    // Rinomina il livello risultante come 'Retouch Clone' e imposta la modalità di fusione a 'color'
    {
      _obj: 'set',
      _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
      to: {
        _obj: 'layer',
        name: 'Retouch Clone', // Nome del nuovo livello
        mode: { _enum: 'blendMode', _value: 'color' }, // Modalità di fusione: 'color'
      },
    },
  ];

  // Esegui il comando batchPlay per applicare il Retouch Clone
  await action.batchPlay(command, {
    historyStateInfo: {
      name: 'Retouch Clone',
      target: { _ref: 'document', _enum: 'ordinal', _value: 'targetEnum' },
    },
  });
};

const createCloneHueSaturationLayer = async () => {
  await action.batchPlay(
    [
      {
        _obj: 'make',
        _target: [{ _ref: 'adjustmentLayer' }],
        using: {
          _obj: 'adjustmentLayer',
          type: {
            _obj: 'hueSaturation',
          },
        },
      },
      {
        _obj: 'set',
        _target: [{ _ref: 'layer', _enum: 'ordinal', _value: 'targetEnum' }],
        to: { _obj: 'layer', name: 'Retouch Clone Sat' }, // Rinomina il livello di regolazione in 'Retouch Clone Sat'
      },
    ],
    { synchronousExecution: true }
  );
};

export const Face: FC<{ spacing: number }> = ({ spacing }) => {
  const { t } = useTranslate();
  const { setFnModalType, fnModalType } = useUI();
  const faceSections = useMemo<ActionSection[]>(
    () => [
      {
        name: t('face.effectsAndColor'),
        icon: '/assets/actionCategories/effectsAndColor.jpg',
        categories: [
          {
            category: null,
            actions: [
              {
                name: t('face.effectsAndColor.dreaming'),
                type: fnModalType === 'dreaming' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'dreaming') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createDreaming();
                    },
                    { commandName: 'Dreaming' }
                  );
                  setFnModalType('dreaming');
                },
              },
              {
                name: t('face.effectsAndColor.colorGrading'),
                type: fnModalType === 'colorgrading' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'colorgrading') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createColorGrading();
                    },
                    { commandName: 'Color Grading' }
                  );

                  setFnModalType('colorgrading');
                },
              },
              {
                name: t('face.effectsAndColor.colorClone'),
                type: fnModalType === 'colorclone' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'colorclone') {
                    setFnModalType(null);
                    return;
                  }

                  const currentDocument = app.activeDocument;
                  let hasOpenedFile = false;
                  await core.executeAsModal(
                    async () => {
                      const entry = await localFileSystem.getFileForOpening();

                      if (entry) {
                        const sourceDocument = await app.open(entry);
                        const sourceDocumentName = sourceDocument.name;

                        app.activeDocument = currentDocument;

                        await applyCloneWithSource(sourceDocumentName);
                        await sourceDocument.closeWithoutSaving();

                        await createCloneHueSaturationLayer();
                        hasOpenedFile = true;
                      }
                    },
                    { commandName: 'Color Clone' }
                  );

                  if (hasOpenedFile) {
                    setFnModalType('colorclone');
                  }
                },
              },
            ],
          },
        ],
      },
      {
        name: t('face.skin'),
        icon: '/assets/actionCategories/skin.png',
        categories: [
          {
            category: null,
            actions: [
              {
                name: t('face.skin.easy'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/SKIN/Skin_Easy.jsxbin', false, true),
              },
              {
                name: t('face.skin.skin_tone'),
                type: fnModalType === 'skintone' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'skintone') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createSkinToneLayer();
                    },
                    { commandName: 'Skin Tone' }
                  );

                  setFnModalType('skintone');
                },
              },
              {
                name: t('face.skin.frequency_sep'),
                type: 'bean',
                action: () =>
                  ScriptRun('bin/RETOUCH/SKIN/Skin_FrequencySeparation.jsxbin', false, true),
              },
              {
                name: t('face.skin.frequency_sep_16bit'),
                type: 'bean',
                action: () =>
                  ScriptRun(
                    'bin/RETOUCH/SKIN/Retouch_FrequencySeparation16bit.jsxbin',
                    false,
                    true
                  ),
              },
              {
                name: t('face.skin.grain'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/SKIN/Skin_Grain.jsxbin', false, true),
              },
              {
                name: t('face.skin.texture'),
                type: fnModalType === 'skintexture' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'skintexture') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createSkinTextureLayer();
                    },
                    { commandName: 'Skin Texture' }
                  );

                  setFnModalType('skintexture');
                },
              },
              {
                name: t('face.skin.dodge_and_burn'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/SKIN/Skin_Dodge_Burn.jsxbin', false, true),
              },
              {
                name: t('face.skin.contrast'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/SKIN/Skin_Contrast.jsxbin', false, true),
              },
              {
                name: t('face.skin.grey_50'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/SKIN/D_BGrey50.jsxbin', false, true),
              },
              {
                name: t('face.skin.skin_glow'),
                type: fnModalType === 'skinglow' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'skinglow') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createGlowingSkin();
                    },
                    { commandName: 'Skin Glow' }
                  );

                  setFnModalType('skinglow');
                },
              },
              {
                name: t('face.skin.facialbody_hair_removal'),
                type: 'bean',
                action: () =>
                  ScriptRun('bin/RETOUCH/SKIN/Skin_Facialandbodyhair.jsxbin', false, true),
              },
              {
                name: t('face.skin.red_removal'),
                type: fnModalType === 'redremoval' ? 'yellowFilledBean' : 'bean',
                action: async () => {
                  if (fnModalType) {
                    for (const command of cancelCommands[fnModalType]) {
                      await core.executeAsModal(
                        async () => {
                          await action.batchPlay(
                            command.command as unknown as ActionDescriptor[],
                            command.options
                          );
                        },
                        { commandName: command.commandName }
                      );
                    }
                  }

                  if (fnModalType === 'redremoval') {
                    setFnModalType(null);
                    return;
                  }

                  if (!fnModalType) {
                    await toggleLayersPalette();
                  }

                  await core.executeAsModal(
                    async () => {
                      await createRedRemoval();
                    },
                    { commandName: 'Red Removal' }
                  );

                  setFnModalType('redremoval');
                },
              },
            ],
          },
        ],
      },
      {
        name: t('face.face'),
        icon: '/assets/actionCategories/face.png',
        categories: [
          {
            category: t('face.face.size'),
            actions: [
              {
                type: 'face',
                name: 'Face', // used as key
                chinDecrease: () => ScriptRun('bin/FACE/FORM/Chin-1.jsxbin', false, true),
                chinIncrease: () => ScriptRun('bin/FACE/FORM/Chin+1.jsxbin', false, true),
                foreheadDecrease: () => ScriptRun('bin/FACE/FORM/Forehead-1.jsxbin', false, true),
                foreheadIncrease: () => ScriptRun('bin/FACE/FORM/Forehead+1.jsxbin', false, true),
                jawDecrease: () => ScriptRun('bin/FACE/FORM/Jaw-1.jsxbin', false, true),
                jawIncrease: () => ScriptRun('bin/FACE/FORM/Jaw+1.jsxbin', false, true),
                widenessDecrease: () => ScriptRun('bin/FACE/FORM/FaceWide-1.jsxbin', false, true),
                widenessIncrease: () => ScriptRun('bin/FACE/FORM/FaceWide+1.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('face.face.effects'),
            actions: [
              // {
              //   type: 'bean',
              //   name: 'Freckless',
              //   action: () => {},
              // },
              {
                type: 'bean',
                name: t('face.face.effects.fard'),
                action: () => ScriptRun('bin/FACE/FACE/Fard.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('face.face.effects.eyeliner_3'),
                action: () => ScriptRun('bin/FACE/FACE/Eyeliner.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('face.eyes'),
        icon: '/assets/actionCategories/eyes.png',
        categories: [
          {
            category: t('face.eyes.size'),
            actions: [
              {
                type: 'eyes',
                name: 'Eyes', // used as key
                leftEyeDimensionDecrease: () =>
                  ScriptRun('bin/FACE/EYES/DimensionLeft-1.jsxbin', false, true),
                leftEyeDimensionIncrease: () =>
                  ScriptRun('bin/FACE/EYES/DimensionLeft+1.jsxbin', false, true),
                leftEyeHeightDecrease: () =>
                  ScriptRun('bin/FACE/EYES/HeightLeft-1.jsxbin', false, true),
                leftEyeHeightIncrease: () =>
                  ScriptRun('bin/FACE/EYES/HeightLeft+1.jsxbin', false, true),
                leftEyeWidenessDecrease: () =>
                  ScriptRun('bin/FACE/EYES/WideLeft-1.jsxbin', false, true),
                leftEyeWidenessIncrease: () =>
                  ScriptRun('bin/FACE/EYES/WideLeft+1.jsxbin', false, true),
                rightEyeDimensionDecrease: () =>
                  ScriptRun('bin/FACE/EYES/DimensionRight-1.jsxbin', false, true),
                rightEyeDimensionIncrease: () =>
                  ScriptRun('bin/FACE/EYES/DimensionRight+1.jsxbin', false, true),
                rightEyeHeightDecrease: () =>
                  ScriptRun('bin/FACE/EYES/HeightRight-1.jsxbin', false, true),
                rightEyeHeightIncrease: () =>
                  ScriptRun('bin/FACE/EYES/HeightRight+1.jsxbin', false, true),
                rightEyeWidenessDecrease: () =>
                  ScriptRun('bin/FACE/EYES/WideRight-1.jsxbin', false, true),
                rightEyeWidenessIncrease: () =>
                  ScriptRun('bin/FACE/EYES/WideRight+1.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('face.eyes.effects'),
            actions: [
              {
                name: t('face.eyes.effects.iris'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_Iris.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.whiten'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_Whiten.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.color'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_IrisColor.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.black_pupil'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_BlackPupil.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.veins_remove'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_VeinsRemove.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.reflection'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_Reflections.jsxbin', false, true),
              },
              {
                name: t('face.eyes.effects.final_touch'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/EYES/Eyes_Details.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('face.lips_and_teeth'),
        icon: '/assets/actionCategories/lips_and_teeth.png',
        categories: [
          {
            category: t('face.lips_and_teeth.size'),
            actions: [
              {
                type: 'lips',
                name: 'Lips', // used as key
                widenessDecrease: () => ScriptRun('bin/FACE/MOUTH/MouthWide-1.jsxbin', false, true),
                widenessIncrease: () => ScriptRun('bin/FACE/MOUTH/MouthWide+1.jsxbin', false, true),
                topLipDecrease: () => ScriptRun('bin/FACE/MOUTH/TopLip-1.jsxbin', false, true),
                topLipIncrease: () => ScriptRun('bin/FACE/MOUTH/TopLip+1.jsxbin', false, true),
                bottomLipDecrease: () =>
                  ScriptRun('bin/FACE/MOUTH/BottomLip-1.jsxbin', false, true),
                bottomLipIncrease: () =>
                  ScriptRun('bin/FACE/MOUTH/BottomLip+1.jsxbin', false, true),
                heightDecrease: () => ScriptRun('bin/FACE/MOUTH/MouthHeight-1.jsxbin', false, true),
                heightIncrease: () => ScriptRun('bin/FACE/MOUTH/MouthHeight+1.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('face.lips_and_teeth.smile'),
            actions: [
              {
                type: 'plusminus',
                name: 'Smile',
                increase: () => ScriptRun('bin/FACE/MOUTH/Smile+1.jsxbin', false, true),
                decrease: () => ScriptRun('bin/FACE/MOUTH/Smile-1.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('face.lips_and_teeth.effects'),
            actions: [
              {
                name: t('face.lips_and_teeth.effects.white_teeth'),
                type: 'bean',
                action: () =>
                  ScriptRun('bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_WhiteTeeth.jsxbin', false, true),
              },
              {
                name: t('face.lips_and_teeth.effects.dominant_teeth'),
                type: 'bean',
                action: () =>
                  ScriptRun(
                    'bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_DominantTeeth.jsxbin',
                    false,
                    true
                  ),
              },
              {
                name: t('face.lips_and_teeth.effects.lips_dodge_and_burn'),
                type: 'bean',
                action: () =>
                  ScriptRun('bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_Dodge_Burn.jsxbin', false, true),
              },
              {
                name: t('face.lips_and_teeth.effects.lips_glow'),
                type: 'bean',
                action: () =>
                  ScriptRun('bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_LipGlow.jsxbin', false, true),
              },
              {
                name: t('face.lips_and_teeth.effects.add_lipstick'),
                type: 'bean',
                action: () =>
                  ScriptRun(
                    'bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_AddLipstick.jsxbin',
                    false,
                    true
                  ),
              },
              {
                name: get8BitModeLabel(t('face.lips_and_teeth.effects.wet_lips'), t),
                type: 'bean',
                action: () =>
                  modeCheckWrapper(
                    () =>
                      ScriptRun(
                        'bin/RETOUCH/LIPS AND TEETH/Lips_Teeth_WetLips.jsxbin',
                        false,
                        true
                      ),
                    t
                  ),
              },
            ],
          },
        ],
      },
      {
        name: t('face.hair'),
        icon: '/assets/actionCategories/hair.png',
        categories: [
          {
            category: null,
            actions: [
              {
                name: t('face.hair.hair_enhancer'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/HAIR/Hair_HairEnhancer.jsxbin', false, true),
              },
              {
                name: t('face.hair.hair_dodge_and_burn'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/HAIR/Hair_Dodge_Burn.jsxbin', false, true),
              },
              {
                name: t('face.hair.hair_color'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/HAIR/Hair_HairColor.jsxbin', false, true),
              },
              {
                name: t('face.hair.hair_details'),
                type: 'bean',
                action: () => ScriptRun('bin/RETOUCH/HAIR/Hair_Details.jsxbin', false, true),
              },
            ],
          },
        ],
      },
    ],
    [t]
  );
  return (
    <Container $external>
      {faceSections.map((section) => (
        <Accordion title={section.name} icon={section.icon} key={section.name}>
          {section.categories.map(({ actions, category }) => (
            <Fragment key={category}>
              {category && <ActionCategory>{category}</ActionCategory>}
              <ActionsContainer key={category}>
                {actions.map((action) => (
                  <ActionComponent action={action} key={action.name} />
                ))}
              </ActionsContainer>
            </Fragment>
          ))}
        </Accordion>
      ))}
      <div style={{ height: spacing }} />
    </Container>
  );
};
