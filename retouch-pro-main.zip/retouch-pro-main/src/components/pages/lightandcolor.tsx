import React, { FC, Fragment, useMemo } from 'react';
import { Container } from '../common/container';
import { Accordion } from '../common/accordion';
import { ActionSection } from '../../types';
import { ActionCategory, ActionComponent, ActionsContainer } from '../common/action';
import { ScriptRun } from '../../utils';
import { Script } from 'vm';
import { useTranslate } from '../../hooks/useTranslate';
import { useUI } from '../../stores/ui';
export const LightAndColor: FC<{ spacing: number }> = ({ spacing }) => {
  const { t } = useTranslate()
  const { setFnModalType, fnModalType } = useUI();
  const lightAndColorSections = useMemo<ActionSection[]>(
    () => [
      {
        name: t('light_and_color.presets'),
        icon: '/assets/actionCategories/presets.png',
        categories: [
          {
            category: t('light_and_color.presets.looks'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.summer'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Summer.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.sunny'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Sunny.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.spring'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Spring.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.winter'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Winter.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.sunset'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Sunset.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: 'Autumn',
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Autumn.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.snowy'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Snowy.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.looks.cloudy'),
                action: () => ScriptRun('bin/FX/PRESETS/LOOKS/Looks_Cloudy.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.presets.ambient'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_1'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Clear.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_2'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Dark.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_3'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Lotus.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_4'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Sand.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_5'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/SOFT.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_6'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Teal.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_7'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Touch.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.ambient.amb_8'),
                action: () => ScriptRun('bin/FX/PRESETS/AMBIENT/Wood.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.presets.glamour'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_1'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_2'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_3'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_4'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam4.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_5'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam5.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_6'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam6.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_7'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam7.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.glamour.glam_8'),
                action: () => ScriptRun('bin/FX/PRESETS/GLAMOUR/Glam8.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.presets.cinema'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.choco'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Choco.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.gold'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Gold.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.cream'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Cream.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.old'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Old.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.retro'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Retro.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.vintage'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Vintage.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.pink'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Pink.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.cinema.cinema'),
                action: () => ScriptRun('bin/FX/PRESETS/CINEMA/Cinema.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.presets.feelings'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.ora_teal'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/OraTeal.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.coco'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Coco.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.dreamy'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Dreamy.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.thai'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Thai.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.desert'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Desert.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.fashion'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Fashion.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.fawn'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Fawn.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.feelings.peach'),
                action: () => ScriptRun('bin/FX/PRESETS/FEELINGS/Peach.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.presets.minimal'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.nude'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Nude.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.ora_black'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/OraBlack.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.black'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Black.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.white'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/White.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.grey'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Grey.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.coffee'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Coffee.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.neon'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Neon.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.presets.minimal.cappuccino'),
                action: () => ScriptRun('bin/FX/PRESETS/MINIMAL/Cappuccino.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('light_and_color.films'),
        icon: '/assets/actionCategories/films.png',
        categories: [
          {
            category: t('light_and_color.films.35mm'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.films.35mm.35mm_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/35mm_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.35mm.35mm_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/35mm_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.35mm.35mm_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/35mm_3.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.films.fuji'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.films.fuji.fuji_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Fuji_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.fuji.fuji_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Fuji_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.fuji.fuji_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Fuji_3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.fuji.fuji_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Fuji_4.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.fuji.fuji_5'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Fuji_5.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.films.kodak_z'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.films.kodak_z.kodak_z_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Kodak_Z_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.kodak_z.kodak_z_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Kodak_Z_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.kodak_z.kodak_z_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Kodak_Z_3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.kodak_z.kodak_z_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Kodak_Z_4.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.kodak_z.kodak_z_5'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Kodak_Z_5.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('light_and_color.films.vsco'),
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.films.vsco.vsco_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/VSCO_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.vsco.vsco_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/VSCO_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.vsco.vsco_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/VSCO_3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.vsco.vsco_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/VSCO_4.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.films.vsco.vsco_5'),
                action: () => ScriptRun('bin/FX/OVERLAYS/VSCO_5.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('light_and_color.split_toning'),
        icon: '/assets/actionCategories/split_toning.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_1'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning1.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_1.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_2'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning2.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_2.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_3'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning3.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_3.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_4'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning4.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_4.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_5'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning5.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_5.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_6'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning6.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_6.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_7'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning7.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_7.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_8'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning8.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_8.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_9'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning9.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_9.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_10'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning10.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_10.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_11'),
                noMargin: false,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning11.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_11.png',
              },
              {
                type: 'imageBeanLarge',
                name: t('light_and_color.split_toning.split_12'),
                noMargin: true,
                action: () => ScriptRun('bin/CG/SPLIT TONING/SplitToning12.jsxbin', false, true),
                image: '/assets/split_toning/split_toning_12.png',
              },
            ],
          },
        ],
      },
      {
        name: t('light_and_color.color_filters'),
        icon: '/assets/actionCategories/color_filters.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: fnModalType === 'moodbox' ? 'yellowFilledBean' : 'bean',
                name: t('light_and_color.color_filters.moodbox'),

                action: () => fnModalType === 'moodbox' ? setFnModalType(null) : setFnModalType('moodbox'),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.warm'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/Warm.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.cold'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/Cold.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.ice'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/Ice.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.warm_shadows'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/WarmShadows.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.warm_highlights'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/Warmhighlights.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.cold_shadows'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/ColdShadows.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_filters.cold_highlights'),
                action: () => ScriptRun('bin/CG/COLOR FILTERS/Coldhghlights.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('light_and_color.lighting'),
        icon: '/assets/actionCategories/lighting.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.lighting.dark_background'),
                action: () => ScriptRun('bin/FINISH/DarkBackground.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.lighting.color_background'),
                action: () => ScriptRun('bin/FINISH/ColorBackground.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.lighting.light_background'),
                action: () => ScriptRun('bin/FINISH/LightBackground.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.lighting.minimize_shadows'),
                action: () => ScriptRun('bin/CLOTHES/Clothes_MinimizeShadows.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.lighting.minimize_highlights'),
                action: () => ScriptRun('bin/FINISH/Clothes_MinimizeHighlights.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('light_and_color.color_profile'),
        icon: '/assets/actionCategories/color_profile.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'bean',
                name: t('light_and_color.color_profile.srgb'),
                action: () => ScriptRun('bin/FINISH/SRGB.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_profile.adobe_1998'),
                action: () => ScriptRun('bin/FINISH/Adobe1998.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('light_and_color.color_profile.coated39'),
                action: () => ScriptRun('bin/FINISH/Coated39.jsxbin', false, true),
              },
            ],
          },
        ],
      },
    ],
    [t]
  );

  return (
    <Container $external>
      {lightAndColorSections.map((section) => (
        <Accordion title={section.name} icon={section.icon} key={section.name}>
          {section.categories.map(({ actions, category }) => (
            <Fragment key={category}>
              {category && <ActionCategory>{category}</ActionCategory>}
              <ActionsContainer>
                {actions.map((action) => (
                  <ActionComponent action={action} key={action.name} />
                ))}
              </ActionsContainer>
            </Fragment>
          ))}
        </Accordion>
      ))}
      <div style={{ height: spacing }} />
    </Container>
  );
};
