import React, { FC, useState, useRef, useEffect, useMemo } from 'react';
import { Container } from '../common/container';
import styled from 'styled-components';
import { Slider } from '../common/slider';
const { action, core } = require('photoshop');
const schemes = {
  analogous: [0, 30, 60],
  triad: [0, 120, 240],
  complementary: [0, 180],
  splitComplementary: [0, 150, 210],
  tetrad: [0, 90, 180, 270],
  square: [0, 90, 180, 270],
};

const hlsToRgb = (h, l, s) => {
  l /= 100;
  s /= 100;

  function hueToRgb(p, q, t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  }

  let r, g, b;

  if (s === 0) {
    r = g = b = l; // Achromatic (gray)
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hueToRgb(p, q, h / 360 + 1 / 3);
    g = hueToRgb(p, q, h / 360);
    b = hueToRgb(p, q, h / 360 - 1 / 3);
  }

  return {
    red: Math.round(r * 255),
    green: Math.round(g * 255),
    blue: Math.round(b * 255),
  };
};

const parseHlsString = (hlsString) => {
  const regex = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/;
  const match = hlsString.match(regex);

  if (!match) {
    throw new Error('Invalid HSL format');
  }

  const hue = parseInt(match[1], 10);
  const saturation = parseFloat(match[2]);
  const lightness = parseFloat(match[3]);

  return { hue, lightness, saturation };
};

const setColor = async (
  color: { red: number; green: number; blue: number },
  type: 'foreground' | 'background'
) => {
  const command = {
    _obj: 'set',
    _target: [
      {
        _ref: 'color',
        _property: `${type}Color`,
      },
    ],
    to: {
      _obj: 'RGBColor',
      red: color.red,
      green: color.green,
      blue: color.blue,
    },
    _options: {
      dialogOptions: 'dontDisplay',
    },
  };
  try {
    await core.executeAsModal(async () => {
      await action.batchPlay([command], { synchronousExecution: true });
    });
  } catch (error) {
    console.error(error);
  }
};

export const ColorWheel: FC<{ spacing: number }> = ({ spacing }) => {
  const [colorScheme, setColorScheme] = useState('analogous');
  const [selectedAngle, setSelectedAngle] = useState(0);
  const [brightness, setBrightness] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const wheelRef = useRef(null);

  const colors = useMemo(() => {
    return schemes[colorScheme].map((angle) => {
      const radian = (angle + selectedAngle) * (Math.PI / 180);
      const x = Math.cos(radian) * 90;
      const y = Math.sin(radian) * 90;
      const color = `hsl(${(angle + selectedAngle + 90) % 360}, 100%, ${brightness}%)`;
      return { x, y, color };
    });
  }, [colorScheme, selectedAngle, brightness]);

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;

    const rect = wheelRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * (180 / Math.PI);
    setSelectedAngle(angle);
  };

  const handleSchemeChange = (e) => {
    setColorScheme(e.target.value);
  };

  useEffect(() => {
    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mouseup', handleMouseUp);

    return () => document.removeEventListener('mouseup', handleMouseUp);
  }, []);

  const setForegroundColor = (color: string) => {
    const { hue, lightness, saturation } = parseHlsString(color);
    const rgb = hlsToRgb(hue, lightness, saturation);
    setColor(rgb, 'foreground');
  };

  const setBackgroundColor = (color: string) => {
    const { hue, lightness, saturation } = parseHlsString(color);
    const rgb = hlsToRgb(hue, lightness, saturation);
    setColor(rgb, 'background');
  };

  return (
    <Container $external>
      <WheelCircle
        $isDragging={isDragging}
        id="color-wheel"
        ref={wheelRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
      >
        <svg
          width="200"
          height="200"
          viewBox="-100 -100 200 200"
          style={{ position: 'absolute', top: 0, left: 0 }}
        >
          {colors.map((color, index) => (
            <line
              key={`line-${index}`}
              x1="0"
              y1="0"
              x2={color.x}
              y2={color.y}
              stroke="white"
              strokeWidth="1"
            />
          ))}
          {colors.map((color, index) => (
            <circle
              key={`circle-${index}`}
              cx={color.x}
              cy={color.y}
              r="10"
              fill={color.color}
              stroke="white"
              strokeWidth="2"
              onClick={() => setForegroundColor(color.color)}
              onContextMenu={() => setBackgroundColor(color.color)}
              style={{
                cursor: 'pointer',
                transition: 'transform 0.2s ease',
              }}
            />
          ))}
        </svg>
      </WheelCircle>

      <SliderLabelContainer>
        <SliderLabel>Luminance</SliderLabel>
        <SliderValue>{brightness}%</SliderValue>
      </SliderLabelContainer>

      <Slider
        active
        max={100}
        min={0}
        value={brightness}
        onChange={(value) => setBrightness(value)}
      />

      <SelectLabel>Color Scheme</SelectLabel>
      <Line>
        <Select id="scheme" value={colorScheme} onChange={handleSchemeChange}>
          {Object.keys(schemes).map((scheme) => (
            <option key={scheme} value={scheme}>
              {scheme.charAt(0).toUpperCase() + scheme.slice(1)}
            </option>
          ))}
        </Select>

        <ColorSchemeContainer>
          {colors.map((color, index) => (
            <div
              key={`color-${index}`}
              style={{
                backgroundColor: color.color,
              }}
              onClick={async () => {
                setForegroundColor(color.color);
              }}
              onContextMenu={async () => {
                setBackgroundColor(color.color);
              }}
            ></div>
          ))}
        </ColorSchemeContainer>
      </Line>
      <div style={{ height: spacing }} />
    </Container>
  );
};

const WheelCircle = styled.div.attrs<{ $isDragging: boolean }>(({ $isDragging }) => ({
  style: {
    cursor: $isDragging ? 'grabbing' : 'pointer',
  },
}))`
  width: 200px;
  height: 200px;
  margin: 10px auto;
  border-radius: 50%;
  background: conic-gradient(#6c63ff, #56ccf2, #2f80ed, #9b51e0, #bb6bd9, #6c63ff);
  box-shadow: 0 0 15px rgba(108, 99, 255, 0.5);
  position: relative;
  background-image: url('/assets/cw.png');
  background-size: cover;
  background-position: center;
`;

const SliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const SelectLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
  margin-top: 15px;
  margin-bottom: 7px;
`;

const Select = styled.select`
  max-width: 181px;
  width: 100%;
  margin: 0;
  margin-right: 12px;
`;

const SliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const SliderLabelContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 7px;
  margin-top: 15px;
`;

const Line = styled.div`
  display: flex;
`;

const ColorSchemeContainer = styled.div`
  display: flex;

  & > div:not(:last-child) {
    margin-right: 7px;
  }

  & > div {
    width: 22px;
    height: 22px;
    border-radius: 4px;

    border: 1px solid #d1d1d1;
    cursor: pointer;
  }
`;
