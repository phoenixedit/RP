import React, { FC, useMemo } from 'react';
import { useTranslate } from '../../hooks/useTranslate';
import { ActionSection } from '../../types';
import { get8BitModeLabel, modeCheckWrapper, ScriptRun } from '../../utils';
import { Accordion } from '../common/accordion';
import { ActionCategory, ActionComponent, ActionsContainer } from '../common/action';
import { Container } from '../common/container';

export const Effects: FC<{ spacing: number }> = ({ spacing }) => {
  const { t } = useTranslate();

  const effectsSections = useMemo<ActionSection[]>(
    () => [
      {
        name: t('effects.details'),
        icon: '/assets/actionCategories/details.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'bean',
                name: t('effects.details.final_contrast'),
                action: () => ScriptRun('bin/FINISH/FinalContrast.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.grain'),
                action: () => ScriptRun('bin/FINISH/Grain.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.remove_grain'),
                action: () => ScriptRun('bin/FINISH/RemoveGrain.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.remove_chromatic_aberrations'),
                action: () =>
                  ScriptRun('bin/FINISH/RemoveChromaticAberrations.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.details'),
                action: () => ScriptRun('bin/FINISH/Details.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.behind_blur_1'),
                action: () => ScriptRun('bin/FINISH/BehindBlur_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.details.behind_blur_2'),
                action: () => ScriptRun('bin/FINISH/BehindBlur_2.jsxbin', false, true),
              },
            ],
          },
        ],
      },
      {
        name: t('effects.overlays'),
        icon: '/assets/actionCategories/overlays.png',
        categories: [
          {
            category: t('effects.overlays.snow'),
            actions: [
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.snow.snow_1'), t),
                action: () =>
                  modeCheckWrapper(() => ScriptRun('bin/FX/OVERLAYS/Snow1.jsxbin', false, true), t),
              },
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.snow.snow_2'), t),
                action: () =>
                  modeCheckWrapper(() => ScriptRun('bin/FX/OVERLAYS/Snow2.jsxbin', false, true), t),
              },
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.snow.snow_3'), t),
                action: () =>
                  modeCheckWrapper(() => ScriptRun('bin/FX/OVERLAYS/Snow3.jsxbin', false, true), t),
              },
              {
                type: 'bean',
                name: t('effects.overlays.snow.snow_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Snow4.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('effects.overlays.rain'),
            actions: [
              {
                type: 'bean',
                name: t('effects.overlays.rain.rain_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Rain_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.rain.rain_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Rain_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.rain.rain_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Rain_3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.rain.rain_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Rain_4.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('effects.overlays.sun'),
            actions: [
              {
                type: 'bean',
                name: t('effects.overlays.sun.sun_1'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Sun_1.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.sun.sun_2'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Sun_2.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.sun.sun_3'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Sun_3.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.overlays.sun.sun_4'),
                action: () => ScriptRun('bin/FX/OVERLAYS/Sun_4.jsxbin', false, true),
              },
            ],
          },
          {
            category: t('effects.overlays.dust'),
            actions: [
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.dust.dust_1'), t),
                action: () =>
                  modeCheckWrapper(
                    () => ScriptRun('bin/FX/OVERLAYS/Dust_1.jsxbin', false, true),
                    t
                  ),
              },
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.dust.dust_2'), t),
                action: () =>
                  modeCheckWrapper(
                    () => ScriptRun('bin/FX/OVERLAYS/Dust_2.jsxbin', false, true),
                    t
                  ),
              },
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.dust.dust_3'), t),
                action: () =>
                  modeCheckWrapper(
                    () => ScriptRun('bin/FX/OVERLAYS/Dust_3.jsxbin', false, true),
                    t
                  ),
              },
              {
                type: 'bean',
                name: get8BitModeLabel(t('effects.overlays.dust.dust_4'), t),
                action: () =>
                  modeCheckWrapper(
                    () => ScriptRun('bin/FX/OVERLAYS/Dust_4.jsxbin', false, true),
                    t
                  ),
              },
            ],
          },
        ],
      },
      {
        name: t('effects.water'),
        icon: '/assets/actionCategories/water.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'imageBean',
                name: t('effects.water.water_1'),
                action: () => ScriptRun('bin/FX/WATER/COLOR1.jsxbin', false, true),
                image: '/assets/water_effects/water_1.png',
                noMargin: false,
              },
              {
                type: 'imageBean',
                name: t('effects.water.water_2'),
                action: () => ScriptRun('bin/FX/WATER/COLOR2.jsxbin', false, true),
                image: '/assets/water_effects/water_2.png',
                noMargin: false,
              },
              {
                type: 'imageBean',
                name: t('effects.water.water_3'),
                action: () => ScriptRun('bin/FX/WATER/COLOR3.jsxbin', false, true),
                image: '/assets/water_effects/water_3.png',
                noMargin: true,
              },
              {
                type: 'imageBean',
                name: t('effects.water.water_4'),
                action: () => ScriptRun('bin/FX/WATER/COLOR4.jsxbin', false, true),
                image: '/assets/water_effects/water_4.png',
                noMargin: false,
              },
              {
                type: 'imageBean',
                name: t('effects.water.water_5'),
                action: () => ScriptRun('bin/FX/WATER/COLOR5.jsxbin', false, true),
                image: '/assets/water_effects/water_5.png',
                noMargin: false,
              },
              {
                type: 'imageBean',
                name: t('effects.water.water_6'),
                action: () => ScriptRun('bin/FX/WATER/COLOR6.jsxbin', false, true),
                image: '/assets/water_effects/water_6.png',
                noMargin: true,
              },
            ],
          },
        ],
      },
      {
        name: t('effects.clothes'),
        icon: '/assets/actionCategories/clothes.png',
        categories: [
          {
            category: null,
            actions: [
              {
                type: 'bean',
                name: t('effects.clothes.change_color'),
                action: () => ScriptRun('bin/CLOTHES/Clothes_ChangeColor.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.clothes.clothes_dodge_and_burn'),
                action: () => ScriptRun('bin/CLOTHES/Clothes_DodgeandBurn.jsxbin', false, true),
              },
              {
                type: 'bean',
                name: t('effects.clothes.clothes_details'),
                action: () => ScriptRun('bin/CLOTHES/Clothes_Details.jsxbin', false, true),
              },
            ],
          },
        ],
      },
    ],
    [t]
  );
  return (
    <Container $external>
      {effectsSections.map((section) => (
        <Accordion title={section.name} icon={section.icon} key={section.name}>
          {section.categories.map(({ actions, category }) => (
            <>
              {category && <ActionCategory>{category}</ActionCategory>}
              <ActionsContainer key={category}>
                {actions.map((action) => (
                  <ActionComponent action={action} key={action.name} />
                ))}
              </ActionsContainer>
            </>
          ))}
        </Accordion>
      ))}
      <div style={{ height: spacing }} />
    </Container>
  );
};
