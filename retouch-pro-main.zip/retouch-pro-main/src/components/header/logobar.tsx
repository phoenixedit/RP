import React, { useState } from 'react';
import styled from 'styled-components';
import { shell } from 'uxp';
import { useAuth } from '../../stores/auth';
import { standaloneURL } from '../../utils';
import { LanguageSelector } from './languageselector';
import { ConfirmModal } from '../common/confirmmodal';
import { useTranslate } from '../../hooks/useTranslate';
import { useUI } from '../../stores/ui';

export const LogoBar = () => {
  const { accessToken, idToken, logout } = useAuth(({ accessToken, idToken, logout }) => ({
    accessToken,
    idToken,
    logout,
  }));
  const { isDocumentOpen } = useUI(({ isDocumentOpen }) => ({ isDocumentOpen }));
  const { t } = useTranslate();
  const [confirmLogoutModal, setConfirmLogoutModal] = useState(false);

  return (
    <LogoBarContainer>
      <img src="/assets/logo_small.png" width={35} height={24} />
      <MenuContainer>
        <LanguageSelector languages={['it', 'fr', 'es', 'de', 'ru', 'en']} />
        {accessToken && idToken && (
          <Icon
            $src="/assets/socials/profile.png"
            onClick={() =>
              shell.openExternal(
                `${standaloneURL}/auth?access_token=${accessToken}&id_token=${idToken}&state=app&redirect=profile/my-account`
              )
            }
          />
        )}
        {accessToken && idToken && isDocumentOpen && (
          <Icon $src="/assets/logout.png" onClick={() => setConfirmLogoutModal(true)} />
        )}
      </MenuContainer>
      {confirmLogoutModal && (
        <ConfirmModal
          title={t('ai.logout_modal.title')}
          message={t('ai.logout_modal.message')}
          onAccept={() => {
            logout();
            setConfirmLogoutModal(false);
          }}
          onCancel={() => setConfirmLogoutModal(false)}
          cancelText={t('ai.logout_modal.cancel_button_text')}
          acceptText={t('ai.logout_modal.accept_button_text')}
        />
      )}
    </LogoBarContainer>
  );
};

const LogoBarContainer = styled.div`
  display: flex;
  flex-direction: row;
  height: 24px;
  justify-content: space-between;
`;

const MenuContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const Icon = styled.div.attrs<{ $src: string }>((props) => ({
  style: {
    backgroundImage: `url(${props.$src})`,
  },
}))`
  width: 13px;
  height: 13px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  cursor: pointer;
  margin-left: 8px;
`;
