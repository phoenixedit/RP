import React from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { useQueryParams } from '../../hooks/useQueryParams';
import { useUI } from '../../stores/ui';
import { cancelCommands } from '../../utils';
import { ActionDescriptor } from 'photoshop';

const { core, action } = require('photoshop');

type NavbarProps = {
  items: {
    [id: string]: string;
  };
};
export const Navbar: React.FC<NavbarProps> = ({ items }) => {
  const page = useQueryParams('page');
  const navigate = useNavigate();

  const { fnModalType, setFnModalType } = useUI();

  return (
    <NavbarContainer>
      {Object.entries(items).map(([id, value]) => (
        <NavbarItem
          key={id}
          $active={page === id}
          onClick={async () => {
            if (fnModalType) {
              for (const command of cancelCommands[fnModalType]) {
                await core.executeAsModal(
                  async () => {
                    await action.batchPlay(
                      command.command as unknown as ActionDescriptor[],
                      command.options
                    );
                  },
                  { commandName: command.commandName }
                );
              }

              setFnModalType(null);
            }

            navigate(`/dashboard?page=${id}`);
          }}
        >
          {value.toUpperCase()}
        </NavbarItem>
      ))}
    </NavbarContainer>
  );
};

const NavbarContainer = styled.div`
  display: flex;
  flex-direction: row;
  height: 26px;
`;

const NavbarItem = styled.div<{ $active: boolean }>`
  font-size: 10px;
  font-weight: 400;

  cursor: pointer;

  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;

  margin-right: 12px;

  &:last-child {
    margin-right: 0;
  }

  ${({ $active }) =>
    $active &&
    `
    &::after {
        content: '';
        display: block;
        width: 100%;
        height: 2px;
        background-color: #ffffff;
        border-radius: 2px;
        margin-top: 6px;
    }
    `}
`;
