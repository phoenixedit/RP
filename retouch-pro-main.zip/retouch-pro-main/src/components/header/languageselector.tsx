import React, { FC, useState } from 'react';
import styled from 'styled-components';
import { useAuth } from '../../stores/auth';
import { Languages } from '../../types';

type LanguageSelectorProps = {
  languages: Languages[];
};

export const LanguageSelector: FC<LanguageSelectorProps> = ({ languages }) => {
  const [open, setOpen] = useState(false);
  const { currentLanguage, setCurrentLanguage } = useAuth(
    ({ currentLanguage, setCurrentLanguage }) => ({ currentLanguage, setCurrentLanguage })
  );

  return (
    <LanguageSelectorContainer>
      {open && (
        <AvailableLanguages>
          {languages
            .filter((language) => language !== currentLanguage)
            .map((language) => (
              <LanguageIcon
                $src={`/assets/languages/${language}.png`}
                onClick={() => {
                  setCurrentLanguage(language);
                  setOpen(false);
                }}
              />
            ))}
        </AvailableLanguages>
      )}
      <LanguageIcon
        $src={`/assets/languages/${currentLanguage}.png`}
        onClick={() => setOpen(!open)}
      />
    </LanguageSelectorContainer>
  );
};

const LanguageSelectorContainer = styled.div`
  display: flex;
`;

const AvailableLanguages = styled.div`
  display: flex;
`;

const LanguageIcon = styled.div.attrs<{ $src: string }>((props) => ({
  style: {
    backgroundImage: `url(${props.$src})`,
  },
}))`
  width: 18px;
  height: 13px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  cursor: pointer;
  margin-left: 8px;
`;
