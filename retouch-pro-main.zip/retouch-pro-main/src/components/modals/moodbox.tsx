import React, { useCallback, useState } from 'react';
import { useTranslate } from '../../hooks/useTranslate';
import { ActionButton } from '../buttons/ActionButton';
import { FnModalContainer, FnModalTitle } from "./commons";
import styled from 'styled-components';
const { core, action, app } = require('photoshop');

const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
};

const hexToRgb = (hex: string) => {
    const bigint = parseInt(hex.slice(1), 16);
    return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
};

export const MoodBoxModal = () => {
    const { t } = useTranslate();

    const [mood, setMood] = useState<{
        shadows: string;
        midtones: string;
        highlights: string;
    }>({
        shadows: getRandomColor(),
        midtones: getRandomColor(),
        highlights: getRandomColor(),
    });

    const generateMood = useCallback(() => {
        setMood({
            shadows: getRandomColor(),
            midtones: getRandomColor(),
            highlights: getRandomColor(),
        });
    }, []);


    return (
        <FnModalContainer>
            <FnModalTitle>{t('light_and_color.color_filters.moodbox.title')}</FnModalTitle>
            <MoodBox
                style={{
                    background: `linear-gradient(45deg, ${mood.shadows}, ${mood.midtones}, ${mood.highlights})`,
                }}
            >
                <RegenerateButton onClick={generateMood}>
                    <img src="/assets/palette.png" style={{ width: 16, height: 16, marginRight: 7 }} />
                    Rigenera
                </RegenerateButton>
            </MoodBox>
            <ActionContainer>
                <ActionButton
                    text="Apply"
                    variant="primaryNormal"
                    action={async () => {
                        await core.executeAsModal(
                            async () => {
                                const colors = Object.values(mood).map((hexColor, index) => {
                                    const [r, g, b] = hexToRgb(hexColor);
                                    return {
                                        _obj: 'colorStop',
                                        color: { _obj: 'RGBColor', red: r, green: g, blue: b },
                                        location: Math.round((index / 2) * 4096),
                                        midpoint: 50,
                                        type: { _enum: 'colorStopType', _value: 'userStop' },
                                    };
                                });

                                const command = [
                                    {
                                        _obj: 'make',
                                        _target: [{ _ref: 'adjustmentLayer' }],
                                        using: {
                                            _obj: 'adjustmentLayer',
                                            type: {
                                                _obj: 'gradientMapClass',
                                                gradient: {
                                                    _obj: 'gradientClassEvent',
                                                    colors: colors,
                                                    gradientForm: { _enum: 'gradientForm', _value: 'customStops' },
                                                    interfaceIconFrameDimmed: 4096.0,
                                                    name: 'Generated Gradient',
                                                    transparency: [
                                                        {
                                                            _obj: 'transferSpec',
                                                            location: 0,
                                                            midpoint: 50,
                                                            opacity: { _unit: 'percentUnit', _value: 100.0 },
                                                        },
                                                        {
                                                            _obj: 'transferSpec',
                                                            location: 4096,
                                                            midpoint: 50,
                                                            opacity: { _unit: 'percentUnit', _value: 100.0 },
                                                        },
                                                    ],
                                                },
                                                gradientsInterpolationMethod: {
                                                    _enum: 'gradientInterpolationMethodType',
                                                    _value: 'perceptual',
                                                },
                                            },
                                        },
                                    },
                                    {
                                        _obj: 'set',
                                        _target: [{ _ref: 'layer', _enum: 'ordinal', _value: 'targetEnum' }],
                                        to: {
                                            _obj: 'layer',
                                            mode: { _enum: 'blendMode', _value: 'softLight' }, // Metodo di fusione Soft Light
                                        },
                                    },
                                ];

                                await action.batchPlay(command, {});
                            },
                            { commandName: 'Apply Gradient Map' }
                        );
                    }}
                />
            </ActionContainer>
        </FnModalContainer>
    )
}

const MoodBox = styled.div`
  width: 238px;
  height: 238px;

  border: 1.5px solid #ffffff40;
  border-radius: 4px;
  display: flex;
  align-items: end;
  padding: 15px;
`;

const RegenerateButton = styled.div`
  background-color: #d1d1d133;
  width: 100%;
  height: 31px;
  font-weight: 500;
  font-size: 14px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 4px;
  cursor: pointer;
`;

const ActionContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 22px;
`;