import React, { FC, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Slider } from '../common/slider';
import { ActionButton } from '../buttons/ActionButton';
import { useUI } from '../../stores/ui';
import type { ActionDescriptor, BatchPlayCommandOptions } from 'photoshop';
import {
  FnModalActionsContainer,
  FnModalCancelButton,
  FnModalContainer,
  FnModalTitle,
} from './commons';
import { cancelCommands } from '../../utils';
import { useTranslate } from '../../hooks/useTranslate';

export const SkintextureModal: FC<{
  onAction: (commands: ActionDescriptor[], options: BatchPlayCommandOptions) => Promise<void>;
}> = ({ onAction }) => {
  const { t } = useTranslate();
  const { setFnModalType } = useUI();

  const [opacity, setOpacity] = useState(0);

  const handleChange = useCallback(
    async (newValue: number) => {
      await onAction(
        [
          {
            _obj: 'set',
            _target: [{ _name: 'Skin Texture', _ref: 'layer' }],
            to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: newValue } },
          },
        ] as unknown as ActionDescriptor[],
        {}
      );
      setOpacity(newValue);
    },
    [onAction]
  );

  return (
    <FnModalContainer>
      <FnModalTitle>{t('skintexture.skin_texture')}</FnModalTitle>
      <FnModalSliderLabelContainer>
        <FnModalSliderLabel>{t('skintexture.texture')}</FnModalSliderLabel>
        <FnModalSliderValue>{opacity}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={opacity}
        onChange={(newValue) => handleChange(newValue)}
        active
        min={0}
        max={100}
      />
      <FnModalActionsContainer>
        <FnModalCancelButton
          onClick={async () => {
            for (const command of cancelCommands.skintexture) {
              await onAction(command.command as unknown as ActionDescriptor[], command.options);
            }

            setFnModalType(null);
          }}
        >
          {t('skintexture.cancel')}
        </FnModalCancelButton>
        <ActionButton
          variant="primaryNormal"
          text={t('skintexture.apply')}
          action={async () => {
            await onAction(
              [
                { _obj: 'mergeVisible', duplicate: true },
                {
                  _obj: 'set',
                  _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
                  to: { _obj: 'layer', name: 'Skin Texture' },
                },
              ] as unknown as ActionDescriptor[],
              { modalBehavior: 'execute' }
            );
            await onAction(
              [
                {
                  _obj: 'delete',
                  _target: [{ _name: 'Skin Texture', _ref: 'layer' }],
                },
              ] as unknown as ActionDescriptor[],
              {}
            );
            await onAction(
              [
                {
                  _obj: 'select',
                  _target: [
                    {
                      _enum: 'menuItemType',
                      _ref: 'menuItemClass',
                      _value: 'toggleLayersPalette',
                    },
                  ],
                },
              ] as unknown as ActionDescriptor[],
              {
                historyStateInfo: {
                  name: 'Mostra pannello livelli',
                  target: {
                    _ref: 'document',
                    _enum: 'ordinal',
                    _value: 'targetEnum',
                  },
                },
              }
            );
            setFnModalType(null);
          }}
        />
      </FnModalActionsContainer>
    </FnModalContainer>
  );
};

const FnModalSliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderLabelContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 7px;
`;
