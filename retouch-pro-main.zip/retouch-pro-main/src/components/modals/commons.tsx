import styled from 'styled-components';

export const FnModalContainer = styled.div`
  background-color: #323232;
  border-radius: 16px 16px 4px 4px;
  padding: 15px;

  max-height: 100%;

  margin-bottom: 10px;
  border: 1px solid #262626;
`;

export const FnModalTitle = styled.div`
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 15px;
`;

export const FnModalActionsContainer = styled.div`
  display: flex;
  flex-direction: row;

  margin-top: 22px;

  align-items: center;
`;

export const FnModalCancelButton = styled.div`
  font-size: 14px;
  font-weight: 400;
  margin-right: 15px;
  height: 100%;
  cursor: pointer;
`;

export const TabbarContainer = styled.div`
  display: flex;
  flex-direction: row;
  height: 26px;
  margin-bottom: 10px;
`;

export const TabbarItem = styled.div<{ $active: boolean }>`
  font-size: 12px;
  font-weight: 600;
  color: #d1d1d1;
  cursor: pointer;

  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;

  margin-right: 12px;

  &:last-child {
    margin-right: 0;
  }

  ${({ $active }) =>
    $active &&
    `
  color: #ffffff;
  &::after {
      content: '';
      display: block;
      width: 100%;
      height: 2px;
      background-color: #ffffff;
      border-radius: 2px;
      margin-top: 4px;
  }
  `}
`;
