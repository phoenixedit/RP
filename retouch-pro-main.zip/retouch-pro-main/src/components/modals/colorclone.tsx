import React, { FC, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Slider } from '../common/slider';
import { ActionButton } from '../buttons/ActionButton';
import { useUI } from '../../stores/ui';
import type { ActionDescriptor, BatchPlayCommandOptions } from 'photoshop';
import {
  FnModalActionsContainer,
  FnModalCancelButton,
  FnModalContainer,
  FnModalTitle,
} from './commons';
import { cancelCommands } from '../../utils';
import { useTranslate } from '../../hooks/useTranslate';

type ColorClone = {
  hue: number;
  saturation: number;
  lightness: number;
};

export const ColorcloneModal: FC<{
  onAction: (commands: ActionDescriptor[], options: BatchPlayCommandOptions) => Promise<void>;
}> = ({ onAction }) => {
  const { setFnModalType } = useUI();
  const { t } = useTranslate();

  const [value, setValue] = useState<ColorClone>({
    hue: 0,
    saturation: 0,
    lightness: 0,
  });

  const handleChange = useCallback(
    async (newValue: ColorClone) => {
      const { hue, saturation, lightness } = newValue;
      await onAction(
        [
          {
            _obj: 'set',
            _target: [{ _enum: 'ordinal', _ref: 'adjustmentLayer', _value: 'targetEnum' }],
            to: {
              _obj: 'hueSaturation',
              adjustment: [
                {
                  _obj: 'hueSatAdjustmentV2',
                  hue: hue,
                  lightness: lightness,
                  saturation: saturation,
                },
              ],
              presetKind: { _enum: 'presetKindType', _value: 'presetKindCustom' },
            },
          },
        ] as unknown as ActionDescriptor[],
        {
          synchronousExecution: true,
        }
      );

      setValue(newValue);
    },
    [onAction]
  );

  return (
    <FnModalContainer>
      <FnModalTitle>{t('colorclone.color_clone')}</FnModalTitle>
      <FnModalSliderLabelContainer $isFirst>
        <FnModalSliderLabel>{t('colorclone.hue')}</FnModalSliderLabel>
        <FnModalSliderValue>{value.hue}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={value.hue}
        onChange={(newValue) => handleChange({ ...value, hue: newValue })}
        active
        min={-100}
        max={100}
      />
      <FnModalSliderLabelContainer>
        <FnModalSliderLabel>{t('colorclone.saturation')}</FnModalSliderLabel>
        <FnModalSliderValue>{value.saturation}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={value.saturation}
        onChange={(newValue) => handleChange({ ...value, saturation: newValue })}
        active
        min={-100}
        max={100}
      />
      <FnModalSliderLabelContainer>
        <FnModalSliderLabel>{t('colorclone.lightness')}</FnModalSliderLabel>
        <FnModalSliderValue>{value.lightness}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={value.lightness}
        onChange={(newValue) => handleChange({ ...value, lightness: newValue })}
        active
        min={-100}
        max={100}
      />
      <FnModalActionsContainer>
        <FnModalCancelButton
          onClick={async () => {
            for (const command of cancelCommands.colorclone) {
              await onAction(command.command as unknown as ActionDescriptor[], command.options);
            }

            setFnModalType(null);
          }}
        >
          {t('colorclone.cancel')}
        </FnModalCancelButton>
        <ActionButton
          variant="primaryNormal"
          text={t('colorclone.apply')}
          action={async () => {
            await onAction(
              [
                // Seleziona il livello "Retouch Clone"
                { _obj: 'select', _target: [{ _ref: 'layer', _name: 'Retouch Clone' }] },
                // Aggiungi alla selezione il livello "Retouch Clone Sat"
                {
                  _obj: 'select',
                  _target: [{ _ref: 'layer', _name: 'Retouch Clone Sat' }],
                  selectionModifier: { _enum: 'selectionModifierType', _value: 'addToSelection' },
                },
                // Unisci i livelli selezionati in un nuovo livello
                { _obj: 'mergeLayersNew' },
                // Rinomina il livello unito
                {
                  _obj: 'set',
                  _target: [{ _ref: 'layer', _enum: 'ordinal', _value: 'targetEnum' }],
                  to: { _obj: 'layer', name: 'Retouch CLONE FINAL' },
                },
              ] as unknown as ActionDescriptor[],
              {
                synchronousExecution: true,
              }
            );
            setFnModalType(null);
          }}
        />
      </FnModalActionsContainer>
    </FnModalContainer>
  );
};

const FnModalSliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderLabelContainer = styled.div.attrs<{ $isFirst?: boolean }>(({ $isFirst }) => ({
  style: {
    marginTop: $isFirst ? '0' : '10px',
  },
}))`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 7px;
`;
