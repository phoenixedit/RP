import React, { FC, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Slider } from '../common/slider';
import { ActionButton } from '../buttons/ActionButton';
import { useUI } from '../../stores/ui';
import type { ActionDescriptor, BatchPlayCommandOptions } from 'photoshop';
import {
  FnModalActionsContainer,
  FnModalCancelButton,
  FnModalContainer,
  FnModalTitle,
} from './commons';
import { cancelCommands } from '../../utils';
import { useTranslate } from '../../hooks/useTranslate';

type SkinGlow = {
  contrast: number;
  light: number;
};

export const SkinglowModal: FC<{
  onAction: (commands: ActionDescriptor[], options: BatchPlayCommandOptions) => Promise<void>;
}> = ({ onAction }) => {
  const { t } = useTranslate();
  const { setFnModalType } = useUI();

  const [value, setValue] = useState<SkinGlow>({
    contrast: 0,
    light: 0,
  });

  const handleChange = useCallback(
    async (newValue: number, type: 'contrast' | 'light') => {
      await onAction(
        [
          {
            _obj: 'set',
            _target: [{ _name: type === 'contrast' ? 'Contrast' : 'Light', _ref: 'layer' }],
            to: { _obj: 'layer', opacity: { _unit: 'percentUnit', _value: newValue } },
          },
        ] as unknown as ActionDescriptor[],
        {}
      );
      setValue((prev) => ({ ...prev, [type]: newValue }));
    },
    [onAction]
  );

  return (
    <FnModalContainer>
      <FnModalTitle>{t('skinglow.skin_glow')}</FnModalTitle>
      <FnModalSliderLabelContainer $isFirst>
        <FnModalSliderLabel>{t('skinglow.contrast')}</FnModalSliderLabel>
        <FnModalSliderValue>{value.contrast}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={value.contrast}
        onChange={(newValue) => handleChange(newValue, 'contrast')}
        active
        min={0}
        max={100}
      />
      <FnModalSliderLabelContainer>
        <FnModalSliderLabel>{t('skinglow.light')}</FnModalSliderLabel>
        <FnModalSliderValue>{value.light}%</FnModalSliderValue>
      </FnModalSliderLabelContainer>
      <Slider
        backgroundColor="#323232"
        value={value.light}
        onChange={(newValue) => handleChange(newValue, 'light')}
        active
        min={0}
        max={100}
      />
      <FnModalActionsContainer>
        <FnModalCancelButton
          onClick={async () => {
            for (const command of cancelCommands.skinglow) {
              await onAction(command.command as unknown as ActionDescriptor[], command.options);
            }

            setFnModalType(null);
          }}
        >
          {t('skinglow.cancel')}
        </FnModalCancelButton>
        <ActionButton
          variant="primaryNormal"
          text={t('skinglow.apply')}
          action={async () => {
            await onAction(
              [
                { _obj: 'mergeVisible', duplicate: true },
                {
                  _obj: 'set',
                  _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
                  to: { _obj: 'layer', name: 'Glowing Skin' },
                },
              ] as unknown as ActionDescriptor[],
              { modalBehavior: 'execute' }
            );
            await onAction(
              [
                { _obj: 'delete', _target: [{ _name: 'Contrast', _ref: 'layer' }] },
              ] as unknown as ActionDescriptor[],
              {}
            );
            await onAction(
              [
                { _obj: 'delete', _target: [{ _name: 'Light', _ref: 'layer' }] },
              ] as unknown as ActionDescriptor[],
              {}
            );
            await onAction(
              [
                {
                  _obj: 'select',
                  _target: [
                    {
                      _enum: 'menuItemType',
                      _ref: 'menuItemClass',
                      _value: 'toggleLayersPalette',
                    },
                  ],
                },
              ] as unknown as ActionDescriptor[],
              {
                historyStateInfo: {
                  name: 'Mostra pannello livelli',
                  target: {
                    _ref: 'document',
                    _enum: 'ordinal',
                    _value: 'targetEnum',
                  },
                },
              }
            );
            setFnModalType(null);
          }}
        />
      </FnModalActionsContainer>
    </FnModalContainer>
  );
};

const FnModalSliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
`;

const FnModalSliderLabelContainer = styled.div.attrs<{ $isFirst?: boolean }>(({ $isFirst }) => ({
  style: {
    marginTop: $isFirst ? '0' : '10px',
  },
}))`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 7px;
`;
