import React, { FC, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Slider } from '../common/slider';
import { ActionButton } from '../buttons/ActionButton';
import { useUI } from '../../stores/ui';
import type { ActionDescriptor, BatchPlayCommandOptions } from 'photoshop';
import {
  FnModalActionsContainer,
  FnModalCancelButton,
  FnModalContainer,
  FnModalTitle,
  TabbarContainer,
  TabbarItem,
} from './commons';
import { cancelCommands } from '../../utils';
import { useTranslate } from '../../hooks/useTranslate';

type SkinTone = {
  shadows: {
    red: number;
    green: number;
    blue: number;
  };
  midtones: {
    red: number;
    green: number;
    blue: number;
  };
  highlights: {
    red: number;
    green: number;
    blue: number;
  };
};

export const SkintoneModal: FC<{
  onAction: (commands: ActionDescriptor[], options: BatchPlayCommandOptions) => Promise<void>;
}> = ({ onAction }) => {
  const { t } = useTranslate();
  const { setFnModalType } = useUI();
  const [value, setValue] = useState<SkinTone>({
    shadows: { red: 0, green: 0, blue: 0 },
    midtones: { red: 0, green: 0, blue: 0 },
    highlights: { red: 0, green: 0, blue: 0 },
  });

  const getPercentage = (value: number) => {
    return (((value + 100) / 200) * 100).toFixed(0);
  };

  const handleChange = useCallback(async (newValue: SkinTone) => {
    const shadowLevels = [newValue.shadows.red, newValue.shadows.green, newValue.shadows.blue];

    const midtoneLevels = [newValue.midtones.red, newValue.midtones.green, newValue.midtones.blue];

    const highlightLevels = [
      newValue.highlights.red,
      newValue.highlights.green,
      newValue.highlights.blue,
    ];
    await onAction(
      [
        {
          _obj: 'set',
          _target: [{ _ref: 'adjustmentLayer', _enum: 'ordinal', _value: 'targetEnum' }],
          to: {
            _obj: 'colorBalance',
            highlightLevels: highlightLevels,
            midtoneLevels: midtoneLevels,
            shadowLevels: shadowLevels,
            preserveLuminosity: true,
          },
        },
      ] as unknown as ActionDescriptor[],
      {}
    );
    setValue(newValue);
  }, []);

  const [tab, setTab] = useState<'shadows' | 'midtones' | 'highlights'>('shadows');

  return (
    <FnModalContainer>
      <FnModalTitle>{t('skintone.skin_tone')}</FnModalTitle>
      <TabbarContainer>
        <TabbarItem $active={tab === 'shadows'} onClick={() => setTab('shadows')}>
          {t('skintone.shadows')}
        </TabbarItem>
        <TabbarItem $active={tab === 'midtones'} onClick={() => setTab('midtones')}>
          {t('skintone.midtones')}
        </TabbarItem>
        <TabbarItem $active={tab === 'highlights'} onClick={() => setTab('highlights')}>
          {t('skintone.highlights')}
        </TabbarItem>
      </TabbarContainer>
      {tab === 'shadows' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.red}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.green}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.blue}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      {tab === 'midtones' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.red}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.green}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.blue}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      {tab === 'highlights' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.red}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.green}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('skintone.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.blue}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      <FnModalActionsContainer>
        <FnModalCancelButton
          onClick={async () => {
            for (const command of cancelCommands.skintone) {
              await onAction(command.command as unknown as ActionDescriptor[], command.options);
            }

            setFnModalType(null);
          }}
        >
          {t('skintone.cancel')}
        </FnModalCancelButton>
        <ActionButton
          variant="primaryNormal"
          text={t('skintone.apply')}
          action={async () => {
            await onAction(
              [
                { _obj: 'mergeVisible', duplicate: true },
                {
                  _obj: 'set',
                  _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
                  to: { _obj: 'layer', name: 'Skin Tone Merged' },
                },
                // {
                //   _obj: 'make',
                //   at: { _enum: 'channel', _ref: 'channel', _value: 'mask' },
                //   new: { _class: 'channel' },
                //   using: { _enum: 'userMaskEnabled', _value: 'hideAll' }, // Maschera nera
                // },
                // {
                //   _obj: 'delete',
                //   _target: [{ _name: 'Skin Tone', _ref: 'layer' }],
                // },
              ] as unknown as ActionDescriptor[],
              { modalBehavior: 'execute' }
            );
            await onAction(
              [
                // Select layer “Skin Tone”
                {
                  _obj: 'select',
                  _target: [
                    {
                      _name: 'Skin Tone',
                      _ref: 'layer',
                    },
                  ],
                  layerID: [4],
                  makeVisible: false,
                },
                // Delete current layer
                {
                  _obj: 'delete',
                  _target: [
                    {
                      _enum: 'ordinal',
                      _ref: 'layer',
                      _value: 'targetEnum',
                    },
                  ],
                  layerID: [4],
                },
              ] as unknown as ActionDescriptor[],
              {}
            );
            await onAction(
              [
                {
                  _obj: 'select',
                  _target: [
                    {
                      _enum: 'menuItemType',
                      _ref: 'menuItemClass',
                      _value: 'toggleLayersPalette',
                    },
                  ],
                },
              ] as unknown as ActionDescriptor[],
              {
                historyStateInfo: {
                  name: 'Mostra pannello livelli',
                  target: {
                    _ref: 'document',
                    _enum: 'ordinal',
                    _value: 'targetEnum',
                  },
                },
              }
            );
            setFnModalType(null);
          }}
        />
      </FnModalActionsContainer>
    </FnModalContainer>
  );
};

const FnModalSliderContainer = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;

  &:not(:last-child) {
    margin-bottom: 10px;
  }
`;

const FnModalSliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
  margin-right: 7px;
  min-width: 35px;
`;

const FnModalSliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
  margin-left: 7px;
  min-width: 35px;
  text-align: right;
`;

const FnModalGroupContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
