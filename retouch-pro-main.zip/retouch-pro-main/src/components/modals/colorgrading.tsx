import React, { FC, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Slider } from '../common/slider';
import { ActionButton } from '../buttons/ActionButton';
import { useUI } from '../../stores/ui';
import type { ActionDescriptor, BatchPlayCommandOptions } from 'photoshop';
import {
  FnModalActionsContainer,
  FnModalCancelButton,
  FnModalContainer,
  FnModalTitle,
  TabbarContainer,
  TabbarItem,
} from './commons';
import { Checkbox } from '../common/checkbox';
import { cancelCommands } from '../../utils';
import { useTranslate } from '../../hooks/useTranslate';

type ColorGrading = {
  shadows: {
    red: number;
    green: number;
    blue: number;
  };
  midtones: {
    red: number;
    green: number;
    blue: number;
  };
  highlights: {
    red: number;
    green: number;
    blue: number;
  };
  luminance: boolean;
  preview: boolean;
};

export const ColorgradingModal: FC<{
  onAction: (commands: ActionDescriptor[], options: BatchPlayCommandOptions) => Promise<void>;
}> = ({ onAction }) => {
  const { t } = useTranslate();
  const { setFnModalType } = useUI();
  const [value, setValue] = useState<ColorGrading>({
    shadows: { red: 0, green: 0, blue: 0 },
    midtones: { red: 0, green: 0, blue: 0 },
    highlights: { red: 0, green: 0, blue: 0 },
    luminance: true,
    preview: true,
  });

  const [tab, setTab] = useState<'shadows' | 'midtones' | 'highlights'>('shadows');

  const getPercentage = (value: number) => {
    return (((value + 100) / 200) * 100).toFixed(0);
  };

  const handleChange = useCallback(async (newValue: ColorGrading) => {
    if (newValue.preview) {
      const command = { _obj: 'show', _target: [{ _ref: 'layer', _name: 'mrtemp' }] };
      await onAction([command] as unknown as ActionDescriptor[], {
        modalBehavior: 'execute',
        historyStateInfo: {
          name: 'Toggle Preview',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      });
    } else {
      const command = { _obj: 'hide', _target: [{ _ref: 'layer', _name: 'mrtemp' }] };
      await onAction([command] as unknown as ActionDescriptor[], {
        modalBehavior: 'execute',
        historyStateInfo: {
          name: 'Toggle Preview',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      });
    }

    const highlightLevels = [
      newValue.highlights.red,
      newValue.highlights.green,
      newValue.highlights.blue,
    ];
    const midtoneLevels = [newValue.midtones.red, newValue.midtones.green, newValue.midtones.blue];
    const shadowLevels = [newValue.shadows.red, newValue.shadows.green, newValue.shadows.blue];
    const preserveLuminosity = newValue.luminance;

    await onAction(
      [
        {
          _obj: 'set',
          _target: [
            {
              _ref: 'adjustmentLayer',
              _enum: 'ordinal',
              _value: 'targetEnum',
            },
          ],
          to: {
            _obj: 'colorBalance',
            highlightLevels: highlightLevels,
            midtoneLevels: midtoneLevels,
            shadowLevels: shadowLevels,
            preserveLuminosity: preserveLuminosity,
          },
        },
      ] as unknown as ActionDescriptor[],
      {
        historyStateInfo: {
          name: 'Update Ctp Color Balance',
          target: {
            _ref: 'document',
            _enum: 'ordinal',
            _value: 'targetEnum',
          },
        },
      }
    );
    setValue(newValue);
  }, []);

  return (
    <FnModalContainer>
      <FnModalTitle>{t('colorgrading.color_grading')}</FnModalTitle>
      <TabbarContainer>
        <TabbarItem $active={tab === 'shadows'} onClick={() => setTab('shadows')}>
          {t('colorgrading.shadows')}
        </TabbarItem>
        <TabbarItem $active={tab === 'midtones'} onClick={() => setTab('midtones')}>
          {t('colorgrading.midtones')}
        </TabbarItem>
        <TabbarItem $active={tab === 'highlights'} onClick={() => setTab('highlights')}>
          {t('colorgrading.highlights')}
        </TabbarItem>
      </TabbarContainer>
      {tab === 'shadows' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.red}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.green}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.shadows.blue}
              onChange={(newValue) =>
                handleChange({ ...value, shadows: { ...value.shadows, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.shadows.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      {tab === 'midtones' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.red}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.green}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.midtones.blue}
              onChange={(newValue) =>
                handleChange({ ...value, midtones: { ...value.midtones, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.midtones.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      {tab === 'highlights' && (
        <FnModalGroupContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.red')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.red}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, red: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.red)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.green')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.green}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, green: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.green)}%</FnModalSliderValue>
          </FnModalSliderContainer>
          <FnModalSliderContainer>
            <FnModalSliderLabel>{t('colorgrading.blue')}</FnModalSliderLabel>
            <Slider
              backgroundColor="#323232"
              value={value.highlights.blue}
              onChange={(newValue) =>
                handleChange({ ...value, highlights: { ...value.highlights, blue: newValue } })
              }
              active
              min={-100}
              max={100}
            />
            <FnModalSliderValue>{getPercentage(value.highlights.blue)}%</FnModalSliderValue>
          </FnModalSliderContainer>
        </FnModalGroupContainer>
      )}
      <FnModalGroupSeparator />
      <FnModalGroupLabel>{t('colorgrading.correct_color_balance')}</FnModalGroupLabel>
      <FnModalChecboxContainer>
        <FnModalCheckbox>
          <CheckboxLabel onClick={() => handleChange({ ...value, luminance: !value.luminance })}>
            <Checkbox checked={value.luminance} />
            <CheckboxLabelTitle>{t('colorgrading.luminance')}</CheckboxLabelTitle>
          </CheckboxLabel>
        </FnModalCheckbox>
        <FnModalCheckbox>
          <CheckboxLabel onClick={() => handleChange({ ...value, preview: !value.preview })}>
            <Checkbox checked={value.preview} />
            <CheckboxLabelTitle>{t('colorgrading.preview')}</CheckboxLabelTitle>
          </CheckboxLabel>
        </FnModalCheckbox>
      </FnModalChecboxContainer>

      <FnModalActionsContainer>
        <FnModalCancelButton
          onClick={async () => {
            for (const command of cancelCommands.colorgrading) {
              await onAction(command.command as unknown as ActionDescriptor[], command.options);
            }

            setFnModalType(null);
          }}
        >
          {t('colorgrading.cancel')}
        </FnModalCancelButton>
        <ActionButton
          variant="primaryNormal"
          text={t('colorgrading.apply')}
          action={async () => {
            await onAction(
              [
                { _obj: 'show', _target: [{ _ref: 'layer', _name: 'mrtemp' }] },
                // Merge visible layers into a new layer
                { _obj: 'mergeVisible', duplicate: true },
                // Rename the new layer to "ColorX"
                {
                  _obj: 'set',
                  _target: [{ _enum: 'ordinal', _ref: 'layer', _value: 'targetEnum' }],
                  to: { _obj: 'layer', name: 'Color Grading - RP' },
                },
                // Delete "mrtemp" layer
                {
                  _obj: 'delete',
                  _target: [{ _name: 'mrtemp', _ref: 'layer' }],
                },
              ] as unknown as ActionDescriptor[],
              {
                modalBehavior: 'execute',
                historyStateInfo: {
                  name: 'Applica Color Balance',
                  target: {
                    _ref: 'document',
                    _enum: 'ordinal',
                    _value: 'targetEnum',
                  },
                },
              }
            );
            await onAction(
              [
                {
                  _obj: 'select',
                  _target: [
                    {
                      _enum: 'menuItemType',
                      _ref: 'menuItemClass',
                      _value: 'toggleLayersPalette',
                    },
                  ],
                },
              ] as unknown as ActionDescriptor[],
              {
                historyStateInfo: {
                  name: 'Mostra pannello livelli',
                  target: {
                    _ref: 'document',
                    _enum: 'ordinal',
                    _value: 'targetEnum',
                  },
                },
              }
            );
            setFnModalType(null);
          }}
        />
      </FnModalActionsContainer>
    </FnModalContainer>
  );
};

const FnModalSliderContainer = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;

  &:not(:last-child) {
    margin-bottom: 10px;
  }
`;

const FnModalSliderLabel = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
  margin-right: 7px;
  min-width: 35px;
`;

const FnModalSliderValue = styled.div`
  font-size: 12px;
  font-weight: 400;
  color: #d1d1d1;
  margin-left: 7px;
`;

const FnModalGroupLabel = styled.div`
  font-size: 12px;
  font-weight: 600;
  color: #d1d1d1;
  margin-bottom: 10.5px;
`;

const FnModalGroupContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

const FnModalGroupSeparator = styled.div`
  height: 1px;
  width: 100%;
  background-color: #70707040;
  margin-bottom: 15px;
  margin-top: 15px;
`;

const CheckboxLabel = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  cursor: pointer;
  color: #d1d1d1;
`;

const CheckboxLabelTitle = styled.div`
  margin-left: 7px;
`;

const FnModalChecboxContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const FnModalCheckbox = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 50%;
`;
