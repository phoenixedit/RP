import React, { FC } from 'react';
import styled from 'styled-components';

export const Slider: FC<{
  value: number;
  onChange: (value: number) => void;
  active: boolean;
  min: number;
  max: number;
  backgroundColor?: string;
}> = ({ value, onChange, active, min, max, backgroundColor }) => {
  const handleMouseMove = (event: MouseEvent) => {
    if (!active) {
      return;
    }
    const slider = document.getElementById('slider');
    const rect = slider.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const newValue = min + (offsetX / rect.width) * (max - min);

    if (newValue >= min && newValue <= max) {
      onChange(parseInt(newValue.toFixed(0), 10));
    }
  };

  const handleMouseUp = () => {
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const handleMouseDown = () => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const valuePercentage = ((value - min) / (max - min)) * 100;

  return (
    <SliderTrackContainer>
      <SliderTrack
        id="slider"
        onMouseDown={(event) => {
          handleMouseDown();
        }}
      >
        <LeftTrack $value={valuePercentage} $backgroundColor={backgroundColor}></LeftTrack>
        <RightTrack $value={valuePercentage} $backgroundColor={backgroundColor}></RightTrack>
        <SliderThumb
          style={{ left: `${valuePercentage}%` }}
          $active={active}
          $backgroundColor={backgroundColor}
        ></SliderThumb>
      </SliderTrack>
    </SliderTrackContainer>
  );
};

const SliderTrackContainer = styled.div`
  height: 16px;
  width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const SliderTrack = styled.div`
  width: 100%;
  height: 2px;
  background-color: #ccc;
  position: relative;
`;

const LeftTrack = styled.div<{ $value: number; $backgroundColor?: string }>`
  width: ${(props) => props.$value}%;
  height: 100%;
  background-color: #d1d1d1;
  position: absolute;
  top: 0;
  left: 0;
  &::after {
    content: '';
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    right: 6px;
    width: 4px;
    height: 2px;
    background-color: ${({ $backgroundColor }) => $backgroundColor ?? '#262626'};
  }
`;

const RightTrack = styled.div<{ $value: number; $backgroundColor?: string }>`
  width: calc(100% - ${(props) => props.$value}% - 4px);
  height: 100%;
  background-color: #707070;
  position: absolute;
  top: 0;
  right: 0;

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    left: 6px;
    width: 4px;
    height: 2px;
    background-color: ${({ $backgroundColor }) => $backgroundColor ?? '#262626'};
  }
`;

const SliderThumb = styled.div<{ $active?: boolean; $backgroundColor?: string }>`
  width: 16px;
  height: 16px;
  background-color: ${({ $backgroundColor }) => $backgroundColor ?? '#262626'};
  border: 2px solid #fff;
  border-radius: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  ${(props) => (props.$active ? 'cursor: grab;' : '')};
`;
