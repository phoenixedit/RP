import React, { useCallback, useState } from 'react';
import styled from 'styled-components';
import { LinkButton } from '../buttons/LinkButton';
import { useTranslate } from '../../hooks/useTranslate';
import { shell } from 'uxp';
import { apiKey, standaloneURL } from '../../utils';
import { Spacer } from './spacer';
import { useAuth } from '../../stores/auth';
import { useConfig } from '../../hooks/useConfig';

import { v4 } from 'uuid';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useUI } from '../../stores/ui';
import { ActionButton } from '../buttons/ActionButton';
import { InputField } from '../input/Input';
import { AuthenticationDetails, CognitoUser, CognitoUserPool } from 'amazon-cognito-identity-js';
import { Toast } from './toast';
import { Loader } from './spinner';

type ModalProps = {
  close: () => void;
};

type LoginRequest = {
  email: string;
  password: string;
};

export const LoginModal: React.FC<ModalProps> = ({ close }) => {
  const { t } = useTranslate();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [cancellable, setCancellable] = useState(false);

  const { setAccessToken, setIdToken, setRefreshToken } = useAuth(
    ({ setAccessToken, setIdToken, setRefreshToken }) => ({
      setAccessToken,
      setIdToken,
      setRefreshToken,
    })
  );

  const { appConfig } = useConfig();
  const { loginError, setLoginError } = useUI(({ loginError, setLoginError }) => ({
    loginError,

    setLoginError,
  }));

  const intervalRef = React.useRef<ReturnType<typeof setInterval>>();

  const navigate = useNavigate();

  const [fields, setFields] = useState<LoginRequest>({
    email: '',
    password: '',
  });

  const login = useCallback(() => {
    setIsLoggingIn(true);
    setLoginError(undefined);
    if (!appConfig) {
      return;
    }

    const userPool = new CognitoUserPool({
      UserPoolId: appConfig.cognito.userPoolId,
      ClientId: appConfig.cognito.userPoolWebClientId,
    });

    const user = new CognitoUser({
      Username: fields.email,
      Pool: userPool,
    });

    const authDetails = new AuthenticationDetails({
      Username: fields.email,
      Password: fields.password,
    });

    user.authenticateUser(authDetails, {
      onSuccess: (result) => {
        const accessToken = result.getAccessToken().getJwtToken();
        const idToken = result.getIdToken().getJwtToken();
        const refreshToken = result.getRefreshToken().getToken();
        setAccessToken(accessToken);
        setIdToken(idToken);
        setRefreshToken(refreshToken);
        setIsLoggingIn(false);
        close();
      },
      onFailure: (error) => {
        useUI.setState((prev) => ({ ...prev, loginError: error.message }));
        setIsLoggingIn(false);
      },
    });
  }, [fields, appConfig, navigate]);

  const loginZeroRetouch = useCallback(async () => {
    try {
      setIsLoggingIn(true);

      setLoginError(undefined);
      if (!appConfig) {
        return;
      }
      const uuid = v4();
      await axios.post(
        `${appConfig.api.basePath}/oauth2/start-auth`,
        { uuid },
        { headers: { 'x-api-key': apiKey } }
      );

      intervalRef.current = setInterval(async () => {
        try {
          const { data } = await axios.get<{
            access_token: string | null;
            refresh_token: string | null;
            token_id: string | null;
          }>(`${appConfig.api.basePath}/oauth2/get-credentials?uuid=${uuid}`, {
            headers: { 'x-api-key': apiKey },
          });
          if (!data.access_token && !data.token_id) {
            return;
          }
          clearInterval(intervalRef.current);
          setAccessToken(data.access_token);
          setIdToken(data.token_id);
          setRefreshToken(data.refresh_token);
          setIsLoggingIn(false);
          setCancellable(false);
          close();
        } catch {
          setLoginError(t('common.error'));
          setIsLoggingIn(false);
          setCancellable(false);
          clearInterval(intervalRef.current);
        }
      }, 1000);

      setCancellable(true);

      const config = {
        domain:
          appConfig.cognito?.oauth?.domain ??
          'https://dev-phoenix.auth.us-east-1.amazoncognito.com',
        clientId: appConfig.cognito?.userPoolWebClientId ?? '7m1ck36psmmh6j3ja13285h2d0',
        redirectUri:
          appConfig.cognito?.oauth?.redirectSignIn ?? 'https://d3gzsdepi5xw86.cloudfront.net/auth',
        idp: appConfig.cognito?.oauth?.identity_provider ?? 'test-wp',
      };

      shell.openExternal(
        `${config.domain}/oauth2/authorize?response_type=code&client_id=${config.clientId}&redirect_uri=${config.redirectUri}&state=${uuid}&identity_provider=${config.idp}`
      );
    } catch (error) {
      console.log(error);
      setLoginError(t('common.error'));
      setIsLoggingIn(false);
      setCancellable(false);
      clearInterval(intervalRef.current);
    }
  }, [appConfig, navigate]);

  const [isZeroRetouchLogin, setIsZeroRetouchLogin] = useState<boolean>(false);

  return (
    <ModalOverlay
      onClick={() => {
        if (isLoggingIn) {
          return;
        }
        setLoginError(undefined);
        close();
      }}
    >
      <Modal onClick={(event) => event.stopPropagation()}>
        <ModalTitle>{t('ai.login')}</ModalTitle>
        <ModalMessage>{t('ai.unlock_ai')}</ModalMessage>
        <Spacer size={20} />

        {loginError && <Toast type="error" text={loginError} />}
        {isLoggingIn && (
          <Centered>
            <Loader />
            {cancellable && (
              <>
                <Spacer size={5} />
                <div>{t('ai.localize_browser_window')}</div>
                <Spacer size={5} />
                <LinkButton
                  text={t('common.cancel')}
                  action={() => {
                    clearInterval(intervalRef.current);
                    setIsLoggingIn(false);
                  }}
                  variant={'secondary'}
                />
              </>
            )}
          </Centered>
        )}
        {!isLoggingIn && !isZeroRetouchLogin && (
          <>
            <ActionButton
              text={t('login.login_with_retouch_zone')}
              action={() => {
                loginZeroRetouch();
              }}
              disabled={isLoggingIn}
              variant="primaryNormal"
            />
            <Spacer size={10} />
            <Centered>
              <div>
                {t('ai.or')}{' '}
                <LinkButton
                  text={`${t('ai.login_with')} Zero Retouch`}
                  action={() => setIsZeroRetouchLogin(true)}
                />
              </div>
            </Centered>
          </>
        )}
        {!isLoggingIn && isZeroRetouchLogin && (
          <>
            <InputContainer>
              <InputField
                name="email"
                label={t('login.email_label')}
                type="text"
                placeholder={t('login.email_placeholder')}
                value={fields.email}
                update={(value) => setFields((prev) => ({ ...prev, email: value }))}
              />
              <Spacer size={20} />
              <InputField
                name="password"
                label={t('login.password_label')}
                type="password"
                placeholder={t('login.password_placeholder')}
                value={fields.password}
                update={(value) => setFields((prev) => ({ ...prev, password: value }))}
              />
            </InputContainer>
            <ActionButton
              text={t('login.login_button_text')}
              action={() => {
                login();
              }}
              disabled={isLoggingIn}
              variant="primaryNormal"
            />
            <Spacer size={10} />
            <Centered>
              <div>
                {t('ai.or')}{' '}
                <LinkButton
                  text={`${t('ai.login_with')} Retouch Zone`}
                  action={() => setIsZeroRetouchLogin(false)}
                />
              </div>
            </Centered>
          </>
        )}
        {isZeroRetouchLogin && (
          <>
            <Spacer size={20} />
            <FastActionContainer>
              <FastAction>
                <LinkButton
                  text={t('login.forgot_password')}
                  action={() => shell.openExternal(`${standaloneURL}/forgot-password`)}
                />
              </FastAction>
              <FastAction>
                <NoAccountLabel>{t('login.no_account')}</NoAccountLabel>
                <LinkButton
                  text={t('login.sign_up')}
                  action={() => shell.openExternal(`${standaloneURL}/sign-up`)}
                />
              </FastAction>
            </FastActionContainer>
          </>
        )}
      </Modal>
    </ModalOverlay>
  );
};

const ModalOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  z-index: 99999;
  width: calc(100% - 16px);
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Modal = styled.div`
  width: 270px;
  padding: 16px;
  background-color: #262626;
  border-radius: 4px;
`;

const ModalTitle = styled.div`
  font-size: 16px;
  margin-bottom: 5px;
`;

const ModalMessage = styled.div`
  margin-bottom: 10px;
`;

const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;

  & > *:first-child {
    margin-right: 10px;
  }
`;

const NoAccountLabel = styled.span`
  padding-right: 3px;
`;

const FastActionContainer = styled.div``;

const FastAction = styled.div`
  font-size: 12px;
  line-height: 15px;
  font-style: italic;
`;

const InputContainer = styled.form`
  margin-bottom: 20px;
`;

const Centered = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  text-align: center;
`;
