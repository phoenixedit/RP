import React, { FC } from 'react';
import styled from 'styled-components';

export const Checkbox: FC<{
  checked: boolean;
}> = ({ checked }) => {
  return (
    <CheckboxContainer $checked={checked}>
      {checked && <CheckboxImage src="/assets/check.png" />}
    </CheckboxContainer>
  );
};

const CheckboxImage = styled.img`
  width: 100%;
  height: 100%;
`;

const CheckboxContainer = styled.div<{ $checked: boolean }>`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 16px;
  height: 16px;
  ${(props) =>
    !props.$checked
      ? 'border: 2px solid #B2B2B2;'
      : 'border: 2px solid #FFCC00; background-color: #FFCC00;'}
  border-radius: 2px;
`;
