import React, { FC } from 'react';

type LoaderProps = {
    size?: number;
};

export const Loader: FC<LoaderProps> = ({ size }) => <img src="/assets/loader.gif" width={size ?? 24} height={size ?? 24} alt="loading..." />
