import React, { FC, useRef, useState } from "react";
import styled from "styled-components";

type InfoProps = {
    text: string;
}

export const Info: FC<InfoProps> = ({ text }) => {
    const [open, setOpen] = useState(false);
    const timerRef = useRef<ReturnType<typeof setTimeout>>();
    return <InfoIcon onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
        {open && <InfoBox>{text}</InfoBox>}
    </InfoIcon>
}

const InfoIcon = styled.div`
    position: relative;
    width: 15px;
    height: 15px;
    background-image: url('/assets/info.png');
    background-size: contain;

    background-position: center;
`

const InfoBox = styled.div`
    position: absolute;
    top: 100%;
    left: 0;
    margin-top: 9px;
    margin-left: -42.5px;
    width: 100px;
    background-color: #707070;
    border-radius: 4px;
    padding: 4px 8px 4px 8px;

    font-size: 12px;
    color: #ffffff;

    z-index: 99;
`