import React from 'react';
import { Action } from '../../types';
import styled from 'styled-components';
import { ActionButton } from '../buttons/ActionButton';
import { FaceAction } from '../face/FaceAction';
import { EyesAction } from '../face/EyesAction';
import { LipsAction } from '../face/LipsAction';
import { PlusMinusAction } from '../face/PlusMinusAction';

type ActionProps = {
  action: Action;
};

export const ActionsContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
`;

export const ActionCategory = styled.div`
  font-size: 12px;
  margin-bottom: 7px;
  color: #ebebeb;
`;

export const ActionComponent: React.FC<ActionProps> = ({ action }) => {
  switch (action.type) {
    case 'bean':
    case 'yellowFilledBean':
      return (
        <ActionContainer>
          <ActionButton
            variant={action.type}
            text={action.name}
            action={action.action}
            disabled={action.disabled}
          />
        </ActionContainer>
      );
    case 'face': {
      const { name, type, ...rest } = action;
      return <FaceAction {...rest} />;
    }
    case 'eyes': {
      const { name, type, ...rest } = action;
      return <EyesAction {...rest} />;
    }
    case 'lips': {
      const { name, type, ...rest } = action;
      return <LipsAction {...rest} />;
    }
    case 'plusminus': {
      const { name, type, ...rest } = action;
      return <PlusMinusAction {...rest} />;
    }
    case 'imageBean':
    case 'imageBeanLarge': {
      return (
        <ActionContainer $noMargin={action.noMargin}>
          <ActionButton
            variant={action.type}
            text={action.name}
            action={action.action}
            image={action.image}
            disabled={action.disabled}
          />
        </ActionContainer>
      );
    }
  }
};

const ActionContainer = styled.div<{ $noMargin?: boolean }>`
  ${(props) => !props.$noMargin && 'margin-right: 6px;'}
  margin-bottom: 6px;
  flex-shrink: 0;
`;
