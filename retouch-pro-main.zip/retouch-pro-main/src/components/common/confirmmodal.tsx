import React from 'react';
import styled from "styled-components";
import { ActionButton } from '../buttons/ActionButton';
import { after } from 'node:test';

type ModalProps = {
    title: string;
    message: string;
    hideAccept?: boolean;
    acceptText?: string;
    cancelText: string;
    afterMessage?: JSX.Element;
    onAccept?: () => void;
    onCancel: () => void;
}

export const ConfirmModal: React.FC<ModalProps> = ({ title, message, onAccept, onCancel, acceptText, cancelText, afterMessage, hideAccept }) => {
  return <ModalOverlay onClick={onCancel}>
    <Modal onClick={(event) => {
      event.stopPropagation();
    }}>
      <ModalTitle>{title}</ModalTitle>
      <ModalMessage>{message}</ModalMessage>
      {afterMessage}
      <ModalActions>
        <ActionButton variant='bean' action={onCancel} text={cancelText} />
        {!hideAccept && <ActionButton variant='yellowFilledBean' action={onAccept} text={acceptText} />}
      </ModalActions>
    </Modal>
  </ModalOverlay>
};

const ModalOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  z-index: 99999;
  width: calc(100% - 16px);
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Modal = styled.div`
  width: 270px;
  padding: 16px;
  background-color: #262626;
  border-radius: 4px;
`;

const ModalTitle = styled.div`
  font-size: 16px;
  margin-bottom: 5px;
`;

const ModalMessage = styled.div`
margin-bottom: 10px;
`;

const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;

  & > *:first-child {
    margin-right: 10px;
  }
`;
