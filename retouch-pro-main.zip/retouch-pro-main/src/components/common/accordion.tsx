import React, { FC, ReactNode, useEffect, useState } from 'react';
import styled from 'styled-components';

type AccordionProps = {
  title: string;
  icon: string;
  children: ReactNode | ReactNode[];
};

export const Accordion: FC<AccordionProps> = ({ title, icon, children }) => {
  const [open, setOpen] = useState(false);

  return (
    <AccordionContainer>
      <AccordionOpener $open={open} onClick={() => setOpen(!open)}>
        <AccordionOpenerIcon $open={open} $icon={icon} />
        <AccordionOpenerTitle>{title}</AccordionOpenerTitle>
      </AccordionOpener>
      {open && <AccordionContent>{children}</AccordionContent>}
    </AccordionContainer>
  );
};

const AccordionContainer = styled.div`
  width: 100%;
  margin-bottom: 4px;
`;

const AccordionOpener = styled.div<{ $open: boolean }>`
  display: flex;
  flex-direction: row;
  cursor: pointer;
  width: 100%;
  height: ${(props) => (props.$open ? '64px' : '40px')};
  background-color: ${(props) => (props.$open ? '#2B405E' : '#323232')};
  padding: 8px;
  align-items: center;
  border-radius: 4px;
  ${(props) => (!props.$open ? 'margin-bottom: 6px;' : '')}
  border: 1px solid ${(props) => (props.$open ? '#2B405E' : '#323232')};

  &:hover {
    border: 1px solid #72B7F9;

    background-color: #323232;
  }
`;

const AccordionOpenerIcon = styled.div<{ $open: boolean; $icon: string }>`
  width: ${(props) => (props.$open ? '48px' : '24px')};
  height: ${(props) => (props.$open ? '48px' : '24px')};

  background-image: url(${(props) => props.$icon});
  background-size: cover;
  background-position: center;
  background-size: ${(props) => (props.$open ? '48px' : '24px')};

  margin-right: 8px;

  border-radius: 2px;

  flex-shrink: 0;
`;

const AccordionOpenerTitle = styled.div`
  font-size: 14px;
  font-weight: 400;
`;

const AccordionContent = styled.div`
  margin-top: 10px;
`;
