import styled from "styled-components";

export const Spacer = styled.div<{ size: number }>`
  height: ${({ size }) => size}px;
`;