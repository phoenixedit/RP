import React from 'react';
import styled, { WebTarget } from 'styled-components';

type ContainerProps = {
  $centered?: boolean;
  $external?: boolean;
};

export const Container = styled.div.attrs<ContainerProps>(({ $centered, $external }) => ({
  style: {
    alignItems: $centered ? 'center' : 'flex-start',
    justifyContent: $centered ? 'center' : 'flex-start',
    padding: $external ? 0 : 15,
  },
}))`
  margin: 0;
  height: 100%;
  width: 100%;
  ${(props) => props.$centered && `
    display: flex;
    flex-direction: column;
  `}
`;
