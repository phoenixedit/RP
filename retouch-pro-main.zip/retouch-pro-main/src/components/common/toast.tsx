import React, { FC } from 'react';
import styled from 'styled-components';

type ToastProps = {
  type: 'success' | 'error';
  text: string;
};

export const Toast: FC<ToastProps> = ({ text, type }) => {
  return (
    <ToastContainer $type={type}>
      <ToastIcon $type={type} />
      <ToastText>{text}</ToastText>
    </ToastContainer>
  );
};

const ToastContainer = styled.div<{ $type: string }>`
  width: 100%;
  ${(props) =>
    props.$type === 'success' ? 'background-color: #1CA872;' : 'background-color: #DD2118;'}
  display: flex;
  border-radius: 4px;
  padding: 10px 14px;
  margin-bottom: 10px;

  align-items: center;
`;

const ToastIcon = styled.div<{ $type: string }>`
  width: 22px;
  height: 22px;

  ${(props) =>
    props.$type === 'success'
      ? 'background-image: url(/assets/toast/success.png);'
      : 'background-image: url(/assets/toast/error.png);'}
  background-size: 22px;
  background-position: center;

  margin-right: 8px;

  flex-shrink: 0;
`;

const ToastText = styled.div`
  font-style: italic;
  font-size: 12px;
`;
