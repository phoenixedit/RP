import React, { FC, Fragment, useRef, useState } from 'react';
import styled, { css } from 'styled-components';
import { Checkbox } from '../common/checkbox';

const rgbArrayToHex = (rgb: [number, number, number]) => {
  return (
    '#' +
    rgb
      .map((x) => {
        const hex = x.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
      })
      .join('')
  );
};

export const Filter: FC<{
  name: string;
  active: boolean;
  toggleActive: () => void;
  changeValue: (param: string, value: unknown) => void;
  params: {
    [name: string]:
      | {
          type: 'rgb';
          value: [number, number, number];
          options: [number, number, number][];
        }
      | {
          type: 'range';
          value: number;
        };
  };
  isLast?: boolean;
}> = ({ name, active, toggleActive, changeValue, params, isLast }) => {
  const paramRef = useRef<string>();
  const handleMouseMove = (event) => {
    if (!active) {
      return;
    }
    const slider = document.getElementById('slider');
    const rect = slider.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const percentage = (offsetX / rect.width) * 100;

    if (percentage >= 0 && percentage <= 100) {
      changeValue(paramRef.current, parseInt(percentage.toFixed(0), 10));
    }
  };

  const handleMouseUp = () => {
    paramRef.current = undefined;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const handleMouseDown = () => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <SliderContainer $isLast={isLast} $active={active}>
      {Object.entries(params).map(([param, value]) => {
        if (value.type === 'range') {
          return (
            <Fragment key={param}>
              <LabelContainer>
                <Label onClick={() => toggleActive()}>
                  <Checkbox checked={active} />
                  <LabelTitle>{name}</LabelTitle>
                  <TokenIcon />
                </Label>
                <div>{value.value}%</div>
              </LabelContainer>
              <SliderTrackContainer>
                <SliderTrack
                  id="slider"
                  onMouseDown={(event) => {
                    paramRef.current = param;
                    handleMouseDown();
                  }}
                >
                  <LeftTrack $value={value.value}></LeftTrack>
                  <RightTrack $value={value.value}></RightTrack>
                  <SliderThumb style={{ left: `${value.value}%` }} $active={active}></SliderThumb>
                </SliderTrack>
              </SliderTrackContainer>
            </Fragment>
          );
        }

        if (value.type === 'rgb') {
          return (
            <Fragment key={param}>
              <ColorVariantsContainer>
                {value.options.map((color) => (
                  <Color
                    key={rgbArrayToHex(color)}
                    $color={rgbArrayToHex(color)}
                    $selected={rgbArrayToHex(value.value) === rgbArrayToHex(color)}
                    onClick={() => {
                      if (!active) {
                        return;
                      }

                      changeValue(param, color);
                    }}
                    $active={active}
                  />
                ))}
              </ColorVariantsContainer>
            </Fragment>
          );
        }
      })}
    </SliderContainer>
  );
};

const Color = styled.div<{ $active: boolean; $color: string; $selected: boolean }>`
  position: relative;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.25);
  box-sizing: content-box;
  ${(props) => props.$active && 'cursor: pointer;'}
  margin-right: 6px;
  ${(props) =>
    props.$selected &&
    props.$active &&
    css`
      border: 1px solid #ffcc00;
    `}

  &::after {
    content: '';
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    left: 50%;
    width: 20px;
    height: 20px;
    box-sizing: content-box;
    /* background-color: ${(props) => props.$color}; */
    border: 10px solid ${(props) => props.$color};
    border-radius: 999px;
    overflow: hidden;
  }
`;

const SliderTrackContainer = styled.div`
  height: 16px;
`;

const TokenIcon = styled.div`
  width: 9px;
  height: 9px;

  background-image: url('/assets/token.png');
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  background-size: 9px;
  margin-left: 7px;
`;

const ColorVariantsContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 18px;
`;

const LabelContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin-bottom: 18px;
`;

const Label = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  cursor: pointer;
`;

const LabelTitle = styled.div`
  margin-left: 7px;
`;

const SliderTrack = styled.div`
  width: 100%;
  height: 2px;
  background-color: #ccc;
  position: relative;
`;

const LeftTrack = styled.div<{ $value: number }>`
  width: ${(props) => props.$value}%;
  height: 100%;
  background-color: #d1d1d1;
  position: absolute;
  top: 0;
  left: 0;
  &::after {
    content: '';
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    right: 6px;
    width: 4px;
    height: 2px;
    background-color: #262626;
  }
`;

const RightTrack = styled.div<{ $value: number }>`
  width: calc(100% - ${(props) => props.$value}% - 4px);
  height: 100%;
  background-color: #707070;
  position: absolute;
  top: 0;
  right: 0;

  &::before {
    content: '';
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    left: 6px;
    width: 4px;
    height: 2px;
    background-color: #262626;
  }
`;

const SliderThumb = styled.div<{ $active?: boolean }>`
  width: 16px;
  height: 16px;
  background-color: #262626;
  border: 2px solid #fff;
  border-radius: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  ${(props) => (props.$active ? 'cursor: grab;' : '')};
`;

const SliderContainer = styled.div<{ $isLast?: boolean; $active: boolean }>`
  position: relative;
  width: 100%;
  font-size: 12px;
  ${(props) => !props.$isLast && 'margin-bottom: 30px;'}

  ${(props) =>
    !props.$active &&
    `
      &:after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(38, 38, 38, .5);
        pointer-events: none;
      }
    `}
`;
