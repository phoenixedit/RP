import React, { FC, useEffect, useRef, useState } from 'react';

import styled from 'styled-components';
import { useUI } from '../../stores/ui';
import { ScriptRun } from '../../utils';
import { ActionButton } from '../buttons/ActionButton';
import { shell } from 'uxp';
import { Toast } from '../common/toast';
import { useTranslate } from '../../hooks/useTranslate';
import { SkintoneModal } from '../modals/skintone';
import { SkintextureModal } from '../modals/skintexture';
import { SkinglowModal } from '../modals/skinglow';
import { RedremovalModal } from '../modals/redremoval';
import { DreamingModal } from '../modals/dreaming';
import { ColorgradingModal } from '../modals/colorgrading';
import { ColorcloneModal } from '../modals/colorclone';
import { MoodBoxModal } from '../modals/moodbox';

const { action, core } = require('photoshop');

export const Footer: FC = () => {
  const { psToolbar, toast, setToast, isDocumentOpen, fnModalType } = useUI(
    ({ psToolbar, toast, setToast, isDocumentOpen, fnModalType }) => ({
      psToolbar,
      toast,
      setToast,
      isDocumentOpen,
      fnModalType,
    })
  );

  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();
  const containerRef = useRef<HTMLDivElement>(null);

  const { footerHeight, setFooterHeight } = useUI(({ footerHeight, setFooterHeight }) => ({
    footerHeight,
    setFooterHeight,
  }));

  useEffect(() => {
    if (!toast) {
      return;
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      setToast(undefined);
    }, 3000);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [toast]);

  useEffect(() => {
    const updateHeight = () => {
      if (containerRef.current) {
        setFooterHeight(containerRef.current.offsetHeight);
      }
    };

    updateHeight();
    window.addEventListener('resize', updateHeight);

    return () => {
      window.removeEventListener('resize', updateHeight);
    };
  }, []);

  const { t } = useTranslate();

  return (
    <FooterContainer ref={containerRef}>
      <FooterBackground $radiusOffset={fnModalType ? '16' : '4'} />
      {toast && (
        <Toast
          type={toast.type}
          text={
            toast.text
              ? t(toast.text)
              : toast.type === 'error'
              ? t('toast.error')
              : t('toast.success')
          }
        />
      )}
      {fnModalType === 'colorgrading' && (
        <ColorgradingModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Color Grading' }
            );
          }}
        />
      )}
      {fnModalType === 'moodbox' && (
        <MoodBoxModal />
      )}
      {fnModalType === 'colorclone' && (
        <ColorcloneModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Color Clone' }
            );
          }}
        />
      )}
      {fnModalType === 'dreaming' && (
        <DreamingModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Dreaming' }
            );
          }}
        />
      )}
      {fnModalType === 'skinglow' && (
        <SkinglowModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Skin Glow' }
            );
          }}
        />
      )}
      {fnModalType === 'skintexture' && (
        <SkintextureModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Skin Texture' }
            );
          }}
        />
      )}
      {fnModalType === 'skintone' && (
        <SkintoneModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Skin Tone' }
            );
          }}
        />
      )}
      {fnModalType === 'redremoval' && (
        <RedremovalModal
          onAction={async (commands, options) => {
            await core.executeAsModal(
              async () => {
                await action.batchPlay(commands, options);
              },
              { commandName: 'Red Removal' }
            );
          }}
        />
      )}
      {psToolbar && isDocumentOpen && (
        <ToolbarContainer>
          <Tools>
            <ToolsLine>
              <SelectionTool
                onClick={() => ScriptRun('bin/TOOLS/ToolSelezioneRapida.jsxbin', false, false)}
              />
              <MaskTool
                onClick={() => ScriptRun('bin/TOOLS/ToolMascheraCrea.jsxbin', false, true)}
              />
              <CloneTool
                onClick={() => ScriptRun('bin/TOOLS/ToolTimbroClone.jsxbin', false, false)}
              />
              <CorrectionTool
                onClick={() => ScriptRun('bin/TOOLS/ToolPennelloCorrettivo.jsxbin', false, false)}
              />
              <BlackBrushTool
                onClick={() => ScriptRun('bin/TOOLS/ToolPennelloNero.jsxbin', false, false)}
              />
              <WhiteBrushTool
                onClick={() => ScriptRun('bin/TOOLS/ToolPennelloBianco.jsxbin', false, false)}
              />
              <GradientTool
                onClick={() => ScriptRun('bin/TOOLS/ToolGradiente.jsxbin', false, false)}
              />
              <DropperTool
                onClick={() => ScriptRun('bin/TOOLS/ToolContagocce.jsxbin', false, false)}
              />
            </ToolsLine>
            <ToolsLine>
              <TonesTool
                onClick={() => ScriptRun('bin/TOOLS/ToolValoriTonali.jsxbin', false, true)}
              />
              <CurvesTool onClick={() => ScriptRun('bin/TOOLS/ToolCurve.jsxbin', false, true)} />
              <DuplicateLayers
                onClick={() => ScriptRun('bin/TOOLS/ToolDuplicaLivello.jsxbin', false, true)}
              />
              <MergeLayers
                onClick={() => ScriptRun('bin/TOOLS/ToolUnisciLivelli.jsxbin', false, true)}
              />
              <SelectSkyTool
                onClick={() => ScriptRun('bin/TOOLS/ToolSelezionaCielo.jsxbin', false, true)}
              />
              <SelectSubjectTool
                onClick={() => ScriptRun('bin/SELECTION/SelectSubject.jsxbin', false, true)}
              />
              <LumMaskTool
                onClick={() =>
                  ScriptRun('bin/RETOUCH/SELECTIONS/LuminosityMask.jsxbin', false, true)
                }
              />
              <DarkMaskTool
                onClick={() => ScriptRun('bin/RETOUCH/SELECTIONS/DarkMask.jsxbin', false, true)}
              />
            </ToolsLine>
          </Tools>
          <SaveButtonsContainer>
            <ActionButton
              variant="primaryNormal"
              text={t('quick_actions.save')}
              action={() => ScriptRun('bin/FINISH/Save.jsxbin', false, false)}
            />
            <ActionButton
              variant="secondaryNormal"
              text={t('quick_actions.save_as')}
              action={() => ScriptRun('bin/FINISH/SaveAS.jsxbin', false, false)}
            />
            <ActionButton
              variant="secondaryNormal"
              text={t('quick_actions.save_web')}
              action={() => ScriptRun('bin/FINISH/SaveWEB.jsxbin', false, false)}
            />
          </SaveButtonsContainer>
        </ToolbarContainer>
      )}
      <PanelInfo>
        <PanelTitle>Retouch Pro Panel (5.1.0)</PanelTitle>
        <PanelIcons>
          <Icon
            $src="/assets/socials/youtube.png"
            onClick={() => shell.openExternal('https://youtube.com/c/RetouchProPhotoshopPanel')}
          />
          <Icon
            $src="/assets/socials/facebook.png"
            onClick={() =>
              shell.openExternal('https://www.facebook.com/Retouch-Pro-109473920814385/')
            }
          />
          <Icon
            $src="/assets/socials/instagram.png"
            onClick={() =>
              shell.openExternal('https://instagram.com/retouchzoneig?igshid=NDA1YzNhOGU=')
            }
          />
          <Icon
            $src="/assets/socials/mail.png"
            onClick={() => shell.openExternal('mailto: info@retouchpropanel.com')}
          />
          <Icon
            $src="/assets/socials/faq.png"
            onClick={() => shell.openExternal('https://retouchzone.com/tutorial/')}
          />
        </PanelIcons>
      </PanelInfo>
    </FooterContainer>
  );
};

const FooterContainer = styled.div`
  position: fixed;
  width: 100%;
  padding-bottom: 15px;
  // padding-top: 15px;

  bottom: 0;
  left: 0;
  padding-left: 15px;
  padding-right: 31px;
`;

const FooterBackground = styled.div.attrs<{ $radiusOffset: string }>((props) => ({
  style: {
    height: `calc(100% - ${props.$radiusOffset}px)`,
  },
}))`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;

  background-color: #262626;
  z-index: -1;
`;

const PanelInfo = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
`;

const ToolbarContainer = styled.div``;

const PanelTitle = styled.span`
  font-size: 10px;
  font-weight: 400;
  font-style: italic;
`;

const PanelIcons = styled.div`
  display: flex;
`;

const SaveButtonsContainer = styled.div`
  display: flex;
  width: 100%;
  margin-bottom: 15px;

  & > div:nth-child(2) {
    margin-right: 10px;
    margin-left: 10.5px;
  }
`;

const Tools = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 10px;
  background-color: #323232;
  border-radius: 4px;
  padding: 10px 13px;
`;

const ToolsLine = styled.div`
  display: flex;
  justify-content: space-between;
`;

const Tool = styled.div`
  width: 25px;
  height: 25px;
  background-size: 25px;
  background-position: center;

  cursor: pointer;

  flex-shrink: 0;
`;

const SelectionTool = styled(Tool)`
  background-image: url('/assets/tools/selection.png');
`;

const MaskTool = styled(Tool)`
  background-image: url('/assets/tools/mask.png');
`;

const CloneTool = styled(Tool)`
  background-image: url('/assets/tools/clone.png');
`;

const CorrectionTool = styled(Tool)`
  background-image: url('/assets/tools/correction.png');
`;

const BlackBrushTool = styled(Tool)`
  background-image: url('/assets/tools/black_brush.png');
`;

const WhiteBrushTool = styled(Tool)`
  background-image: url('/assets/tools/white_brush.png');
`;

const GradientTool = styled(Tool)`
  background-image: url('/assets/tools/gradient.png');
`;

const DropperTool = styled(Tool)`
  background-image: url('/assets/tools/dropper.png');
`;

const TonesTool = styled(Tool)`
  background-image: url('/assets/tools/tones.png');
`;

const CurvesTool = styled(Tool)`
  background-image: url('/assets/tools/curves.png');
`;

const DuplicateLayers = styled(Tool)`
  background-image: url('/assets/tools/duplicate_layers.png');
`;

const MergeLayers = styled(Tool)`
  background-image: url('/assets/tools/merge_layers.png');
`;

const SelectSkyTool = styled(Tool)`
  background-image: url('/assets/tools/select_sky.png');
`;

const SelectSubjectTool = styled(Tool)`
  background-image: url('/assets/tools/select_subject.png');
`;

const LumMaskTool = styled(Tool)`
  background-image: url('/assets/tools/lum_mask.png');
`;

const DarkMaskTool = styled(Tool)`
  background-image: url('/assets/tools/dark_mask.png');
`;

const Icon = styled.div.attrs<{ $src: string }>((props) => ({
  style: {
    backgroundImage: `url(${props.$src})`,
  },
}))`
  width: 13px;
  height: 13px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  cursor: pointer;
  margin-left: 8px;
`;
