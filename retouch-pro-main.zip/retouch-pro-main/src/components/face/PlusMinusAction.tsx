import React, { FC } from 'react';

import styled from 'styled-components';
import { AdjustmentButton } from '../buttons/AdjustmentButton';

type PlusMinusActionProps = {
  increase: () => void;
  decrease: () => void;
};

export const PlusMinusAction: FC<PlusMinusActionProps> = ({ increase, decrease }) => {
  return (
    <PlusMinusActionContainer>
      <AdjustmentButton action={decrease} type="minus" size="big" />
      <Spacer />
      <AdjustmentButton action={increase} type="plus" size="big" />
    </PlusMinusActionContainer>
  );
};

const PlusMinusActionContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
`;

const Spacer = styled.div`
  width: 10px;
`;
