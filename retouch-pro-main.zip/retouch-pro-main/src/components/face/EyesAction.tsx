import React, { FC } from 'react';
import styled from 'styled-components';
import { AdjustmentButton } from '../buttons/AdjustmentButton';

type EyesActionProps = {
  leftEyeHeightIncrease: () => void;
  leftEyeHeightDecrease: () => void;
  leftEyeWidenessIncrease: () => void;
  leftEyeWidenessDecrease: () => void;
  leftEyeDimensionIncrease: () => void;
  leftEyeDimensionDecrease: () => void;

  rightEyeHeightIncrease: () => void;
  rightEyeHeightDecrease: () => void;
  rightEyeWidenessIncrease: () => void;
  rightEyeWidenessDecrease: () => void;
  rightEyeDimensionIncrease: () => void;
  rightEyeDimensionDecrease: () => void;
};

export const EyesAction: FC<EyesActionProps> = ({
  leftEyeDimensionDecrease,
  leftEyeDimensionIncrease,
  leftEyeHeightDecrease,
  leftEyeHeightIncrease,
  leftEyeWidenessDecrease,
  leftEyeWidenessIncrease,
  rightEyeDimensionDecrease,
  rightEyeDimensionIncrease,
  rightEyeHeightDecrease,
  rightEyeHeightIncrease,
  rightEyeWidenessDecrease,
  rightEyeWidenessIncrease,
}) => {
  return (
    <EyesActionContainer>
      <Eye>
        <EyeWidenessAndHeight>
          <EyeLateralColumn>
            <AdjustmentButton action={leftEyeWidenessDecrease} type="minus" size="small" />
          </EyeLateralColumn>
          <EyeCentralColumn>
            <AdjustmentButton action={leftEyeHeightIncrease} type="plus" size="small" />
            <LeftEyeIcon />
            <AdjustmentButton action={leftEyeHeightDecrease} type="minus" size="small" />
          </EyeCentralColumn>
          <EyeLateralColumn>
            <AdjustmentButton action={leftEyeWidenessIncrease} type="plus" size="small" />
          </EyeLateralColumn>
        </EyeWidenessAndHeight>
        <EyeDimension>
          <AdjustmentButton action={leftEyeDimensionDecrease} type="minus" size="big" />
          <AdjustmentButton action={leftEyeDimensionIncrease} type="plus" size="big" />
        </EyeDimension>
      </Eye>
      <Eye>
        <EyeWidenessAndHeight>
          <EyeLateralColumn>
            <AdjustmentButton action={rightEyeWidenessDecrease} type="minus" size="small" />
          </EyeLateralColumn>
          <EyeCentralColumn>
            <AdjustmentButton action={rightEyeHeightIncrease} type="plus" size="small" />
            <RightEyeIcon />
            <AdjustmentButton action={rightEyeHeightDecrease} type="minus" size="small" />
          </EyeCentralColumn>
          <EyeLateralColumn>
            <AdjustmentButton action={rightEyeWidenessIncrease} type="plus" size="small" />
          </EyeLateralColumn>
        </EyeWidenessAndHeight>
        <EyeDimension>
          <AdjustmentButton action={rightEyeDimensionDecrease} type="minus" size="big" />
          <AdjustmentButton action={rightEyeDimensionIncrease} type="plus" size="big" />
        </EyeDimension>
      </Eye>
    </EyesActionContainer>
  );
};

const EyesActionContainer = styled.div`
  margin-bottom: 10px;
  display: flex;

  width: 100%;

    justify-content: space-between;
`;

const Eye = styled.div`
  display: flex;
  flex-direction: column;
  width: 120px;
  align-items: center;
`;

const EyeWidenessAndHeight = styled.div`
  display: flex;
  justify-content: space-between;
  height: 100px;
  width: 100%;
`;

const EyeLateralColumn = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const EyeCentralColumn = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
`;

const EyeDimension = styled.div`
  display: flex;
  width: 79px;
  margin-top: 15px;
  justify-content: space-between;
`;

const EyeIcon = styled.div`
  width: 50px;
  height: 20px;
  background-position: center;
  background-size: 50px 20px;
`;

const LeftEyeIcon = styled(EyeIcon)`
  background-image: url(/assets/eye_left.png);
`;

const RightEyeIcon = styled(EyeIcon)`
  background-image: url(/assets/eye_right.png);
`;
