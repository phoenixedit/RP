import React, { FC } from 'react';
import styled from 'styled-components';
import { AdjustmentButton } from '../buttons/AdjustmentButton';

type LipsActionProps = {
  widenessIncrease: () => void;
  widenessDecrease: () => void;
  topLipIncrease: () => void;
  topLipDecrease: () => void;
  bottomLipIncrease: () => void;
  bottomLipDecrease: () => void;
  heightIncrease: () => void;
  heightDecrease: () => void;
};

export const LipsAction: FC<LipsActionProps> = ({
  widenessIncrease,
  widenessDecrease,
  topLipIncrease,
  topLipDecrease,
  bottomLipIncrease,
  bottomLipDecrease,
  heightIncrease,
  heightDecrease,
}) => {
  return (
    <LipsActionContainer>
      <LateralColumn>
        <AdjustmentButton action={widenessDecrease} type="minus" size="big" />
      </LateralColumn>
      <CentralColumn>
        <Row>
            <AdjustmentButton action={topLipDecrease} type="minus" size="small" />
            <AdjustmentButton action={heightIncrease} type="up" size="small" />
            <AdjustmentButton action={topLipIncrease} type="plus" size="small" />
        </Row>
        <LipsIcon />
        <Row>
            <AdjustmentButton action={bottomLipDecrease} type="minus" size="small" />
            <AdjustmentButton action={heightDecrease} type="down" size="small" />
            <AdjustmentButton action={bottomLipIncrease} type="plus" size="small" />
        </Row>
      </CentralColumn>
      <LateralColumn>
        <AdjustmentButton action={widenessIncrease} type="plus" size="big" />
      </LateralColumn>
    </LipsActionContainer>
  );
};

const LipsActionContainer = styled.div`
  margin-bottom: 10px;
  display: flex;
  width: 100%;
  justify-content: space-between;
`;

const Column = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 130px;
`;

const CentralColumn = styled(Column)`
  justify-content: space-between;
`

const LateralColumn = styled(Column)`
  justify-content: center;
`;

const Row = styled.div`
  display: flex;
  width: 90px;
  justify-content: space-between;
`;

const LipsIcon = styled.div`
  width: 140px;
  height: 48px;

  background-image: url(/assets/mouth_icon.png);
  background-position: center;
  background-size: 140px 48px;
`;
