import React, { FC } from 'react';
import { AdjustmentButton } from '../buttons/AdjustmentButton';
import styled from 'styled-components';
import { type } from 'os';

type FaceActionProps = {
  widenessIncrease: () => void;
  widenessDecrease: () => void;

  foreheadIncrease: () => void;
  foreheadDecrease: () => void;

  jawIncrease: () => void;
  jawDecrease: () => void;

  chinIncrease: () => void;
  chinDecrease: () => void;
};

export const FaceAction: FC<FaceActionProps> = ({
  chinDecrease,
  chinIncrease,
  foreheadDecrease,
  foreheadIncrease,
  jawDecrease,
  jawIncrease,
  widenessDecrease,
  widenessIncrease,
}) => {
  return (
    <FaceActionContainer>
      <OuterLeft>
        <AdjustmentButton action={widenessDecrease} type="minus" size="big" />
      </OuterLeft>
      <InnerLeft>
        <AdjustmentButton action={foreheadDecrease} type="minus" size="small" />
        <AdjustmentButton action={jawDecrease} type="minus" size="small" />
        <AdjustmentButton action={chinDecrease} type="minus" size="small" />
      </InnerLeft>
      <Central />
      <InnerRight>
        <AdjustmentButton action={foreheadIncrease} type="plus" size="small" />
        <AdjustmentButton action={jawIncrease} type="plus" size="small" />
        <AdjustmentButton action={chinIncrease} type="plus" size="small" />
      </InnerRight>
      <OuterRight>
        <AdjustmentButton action={widenessIncrease} type="plus" size="big" />
      </OuterRight>
    </FaceActionContainer>
  );
};

const FaceActionContainer = styled.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 10px;
`;

const OuterLeft = styled.div`
  display: flex;
  flex-direction: column;
  height: 100px;
  justify-content: center;
`;

const InnerLeft = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100px;
  justify-content: space-between;
`;

const Central = styled.div`
  width: 100px;
  height: 130px;

  background-image: url(/assets/face_illustration.png);
`;

const InnerRight = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100px;
  justify-content: space-between;
`;

const OuterRight = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100px;
  justify-content: center;
`;
