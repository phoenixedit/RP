import React, { useState } from 'react';
import styled from 'styled-components';
import { useUI } from '../../stores/ui';

type InputProps = {
  name: string;
  label: string;
  type: 'text' | 'password';
  placeholder?: string;
  update?: (newValue: string) => void;
  value?: string;
};

const InputField: React.FC<InputProps> = ({ name, label, type, placeholder, value, update }) => {
  const [isPlaceholder, setIsPlaceholder] = useState(value === '');

  const { loading } = useUI();

  return (
    <InputGroup>
      <Label>{label}</Label>
      {!loading && <Input
        type={type === 'password' && isPlaceholder ? 'text' : type}
        name={name}
        onChange={(event) => {
          update?.(event.target.value);
        }}
        onFocus={() => {
          if (isPlaceholder) {
            setIsPlaceholder(false);
          }
        }}
        onBlur={() => {
          if (value === '') {
            setIsPlaceholder(true);
          }
        }}
        value={isPlaceholder ? placeholder : value}
      />}
      {loading && <DisabledInput />}
    </InputGroup>
  );
};

const Input = styled.input`
  appearance: none;
  border-radius: 4px;
  margin: 0;
  border: 1px solid #707070;
  height: 33px;
  padding: 7px 12px 1px 12px !important;
  display: flex;
  align-items: center;

  background-color: #1d1d1d;
  outline: none;
  width: 100%;
  overflow: visible;
  opacity: 1;
  color: white;
`;

const DisabledInput = styled.div`
  appearance: none;
  border-radius: 4px;
  margin: 0;
  border: 1px solid #707070;
  height: 33px;
  padding: 0px 12px 0px 12px !important;
  display: flex;
  align-items: center;

  background-color: #1d1d1d;
  outline: none;
  width: 100%;
  overflow: visible;
  opacity: 1;
`

const Label = styled.label`
  font-size: 12px;
  font-weight: 400;
  margin-bottom: 7px;
  color: #D1D1D1;
`;

const InputGroup = styled.div``;

export { InputField };
