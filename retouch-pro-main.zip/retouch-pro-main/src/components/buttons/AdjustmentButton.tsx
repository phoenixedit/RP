import React, { FC } from 'react';
import styled from 'styled-components';

type AdjustmentButtonProps = {
  action: () => void;
  type: 'plus' | 'minus' | 'up' | 'down';
  size: 'small' | 'big';
};

export const AdjustmentButton: FC<AdjustmentButtonProps> = ({ action, size, type }) => {
  return (
    <Button onClick={action} $size={size} style={{ backgroundImage: `url(/assets/${type}.png)` }} />
  );
};

const Button = styled.div<{ $size: 'small' | 'big' }>`
  width: ${(props) => (props.$size === 'small' ? '20px' : '32px')};
  height: ${(props) => (props.$size === 'small' ? '20px' : '32px')};
  border: 1px solid #5c5c5c;
  border-radius: 50px;

  cursor: pointer;
  background-size: ${(props) => (props.$size === 'small' ? '6px' : '12px')};
  background-position: center;

  &:hover {
    background-color: #545454;
  }
`;
