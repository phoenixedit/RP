import React from 'react';
import styled from 'styled-components';

type ButtonProps = {
  text: string;
  action?: () => void;
  variant?: 'primary' | 'secondary';
};

const LinkButton: React.FC<ButtonProps> = ({ text, action, variant = 'primary' }) => {
  return <Button onClick={action} $variant={variant}>{text}</Button>;
};

export { LinkButton };

const Button = styled.span<{ $variant?: 'primary' | 'secondary' }>`
  color: ${(props) => (props.$variant === 'primary' ? '#0367e0' : '#FFDD53')};
  font-size: 12px;
  font-weight: 400;
  cursor: pointer;
`;
