import React, { HTMLAttributes } from 'react';
import styled from 'styled-components';

type ButtonProps = {
  variant:
    | 'primaryNormal'
    | 'secondaryNormal'
    | 'yellowFilledBean'
    | 'blueFilledBean'
    | 'bean'
    | 'imageBean'
    | 'imageBeanLarge';
  text: string;
  disabled?: boolean;
  image?: string;
  action?: () => void;
  children?: string;
  fullWidth?: boolean;
};

const Button: Record<
  string,
  (props: HTMLAttributes<HTMLDivElement> & { $disabled: boolean; $fullWidth?: boolean; }) => JSX.Element
> = {
  primaryNormal: (props) => <NormalButton {...props} $style="primary" />,
  secondaryNormal: (props) => <NormalButton {...props} $style="secondary" />,
  yellowFilledBean: (props) => <BeanButton {...props} $filled $style="yellow" />,
  blueFilledBean: (props) => <BeanButton {...props} $filled $style="blue" />,
  bean: (props) => <BeanButton {...props} />,
  imageBean: (props) => <BeanButton {...props} style={{ paddingRight: '6.5px', width: '86px' }} />,
  imageBeanLarge: (props) => (
    <BeanButton {...props} style={{ paddingRight: '7px', width: '132px' }} />
  ),
};

const ActionButton: React.FC<ButtonProps> = ({ text, action, disabled, variant, image, fullWidth }) => {
  const ButtonVariant = Button[variant];

  return (
    <ButtonVariant
      onClick={() => {
        if (disabled || !action) {
          return;
        }
        action();
      }}
      $disabled={disabled}
      $fullWidth={fullWidth}
    >
      {variant !== 'imageBean' && variant !== 'imageBeanLarge' && text}
      {['imageBean', 'imageBeanLarge'].includes(variant) && (
        <ImageBeanContainer>
          <ImageBeanText>{text}</ImageBeanText>
          <ImageBeanImage $image={image} $large={variant === 'imageBeanLarge'} />
        </ImageBeanContainer>
      )}
    </ButtonVariant>
  );
};

export { ActionButton };

const colors = {
  primary: {
    normal: '#0367e0',
    disabled: '#348FF4',
  },
  secondary: {
    normal: '#323232',
    disabled: '#545454',
  },
  yellow: {
    normal: '#FFDD53',
    hover: '#FFD11A',
    textColor: '#000000',
  },
  blue: {
    normal: '#0367e0',
    hover: '#0052B2',
    textColor: '#FFFFFF',
  },
};

const NormalButton = styled.div.attrs<{ $disabled?: boolean; $style: 'primary' | 'secondary' }>(
  (props) => ({
    style: {
      backgroundColor: colors[props.$style][props.$disabled ? 'disabled' : 'normal'],
    },
  })
)<{ disabled?: boolean }>`
  width: 100%;
  height: 31px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 14px;
  font-weight: 400;
  ${({ $disabled }) => !$disabled && `cursor: pointer;`}

  user-select: none;
  text-align: center;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 10px;
`;

const BeanButton = styled.div<{
  $disabled?: boolean;
  $filled?: boolean;
  $style?: 'yellow' | 'blue';
  $fullWidth?: boolean;
}>`
  ${({ $fullWidth }) => $fullWidth && `width: 100%;`}
  height: 28px;
  border-radius: 15.5px;
  border-width: 1px;
  border-style: solid;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 400;
  cursor: pointer;
  user-select: none;
  padding: 0 10px;
  text-align: center;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;

  ${({ $disabled, $filled, $style }) =>
    !$disabled &&
    `&:hover {
    background-color: ${$filled ? colors[$style].hover : '#545454'};
  }`}

  ${({ $disabled, $filled }) =>
    $disabled &&
    !$filled &&
    `
    color: #5c5c5c;
    cursor: default;
    border-color: #5c5c5c;
  `}

  ${({ $disabled, $filled }) =>
    $disabled &&
    $filled &&
    `
    color: #5c5c5c;
    cursor: default;
    background-color: #B2B2B2;
    border-color: #5c5c5c;
  `}

  ${({ $disabled, $filled, $style }) =>
    !$disabled &&
    $filled &&
    `
    background-color: ${colors[$style].normal};
    border-color: ${colors[$style].hover};
    color: ${colors[$style].textColor};
  `}

  ${({ $disabled, $filled }) =>
    !$disabled &&
    !$filled &&
    `
    background-color: transparent;
    border-color: #5C5C5C;
    color: #FFFFFF;
  `}
`;

const ImageBeanContainer = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  align-items: center;
`;

const ImageBeanText = styled.div`
  flex-shrink: 0;
`;

const ImageBeanImage = styled.div<{ $image: string; $large: boolean }>`
  width: ${({ $large }) => ($large ? '65px' : '19px')};
  height: 19px;
  background-image: url(${({ $image }) => $image});
  background-size: ${({ $large }) => ($large ? '65px 19px' : '19px')};
  background-position: center;
  flex-shrink: 1;
`;
