import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';
import { App } from './app';
import { PanelController } from './controllers/PanelController';

import { entrypoints } from 'uxp';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 0,
    },
    mutations: {
      retry: 0,
    }
  }
});

const panels = {
  retouchpro: new PanelController(
    () => (
      <QueryClientProvider client={queryClient}>
        <App />
      </QueryClientProvider>
    ),
    { id: 'retouchpro', menuItems: [] }
  ),
};

entrypoints.setup({
  panels,
});
