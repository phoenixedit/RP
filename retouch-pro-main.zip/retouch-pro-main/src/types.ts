export type AppConfig = {
  environment: string;
  api: {
    basePath: string;
  };
  cognito: {
    userPoolId: string;
    userPoolWebClientId: string;

    mandatorySignIn: boolean;

    oauth: {
      domain: string;
      scope: string[];
      redirectSignIn: string;
      redirectSignOut: string;
      responseType: string;
      identity_provider: string;
      state: string;
    };
  };
  options: {
    paypal_client_id: string;
    filetypes: string;
    max_height: number;
    max_width: number;
    polling_ms: number;
    polling_balance_ms: number;
    polling_refresh_ms: number;
    enabled_watermak: boolean;
    watermark_image: string;
    enable_cache: boolean;
    compress_quality: number;
    token_buy_list: number[];
    // token_default: number;
    compress_original: boolean;
    compress_original_quality: number;
    token_defaul: number;
    parallel_thread_upload: number;
    max_files_upload: number;
    page_size: number;
    scroll_bottom: number;
    term_url: string;
    privacy_url: string;
  };
  filters: {
    id: number;
    name: string;
    active: boolean;
    icon: string;
    disabled?: boolean;
    type: string;
    value: Array<{ value: number | number[] }>;
    params: string[];
    values?: Array<{ name: string; value: number[] }>;
    coming: boolean;
  }[];
};

export type Action = {
  name: string;
  disabled?: boolean;
} & (
  | {
      type: 'bean' | 'yellowFilledBean';
      action: () => void;
    }
  | {
      type: 'face';
      widenessIncrease: () => void;
      widenessDecrease: () => void;

      foreheadIncrease: () => void;
      foreheadDecrease: () => void;

      jawIncrease: () => void;
      jawDecrease: () => void;

      chinIncrease: () => void;
      chinDecrease: () => void;
    }
  | {
      type: 'eyes';

      leftEyeHeightIncrease: () => void;
      leftEyeHeightDecrease: () => void;
      leftEyeWidenessIncrease: () => void;
      leftEyeWidenessDecrease: () => void;
      leftEyeDimensionIncrease: () => void;
      leftEyeDimensionDecrease: () => void;

      rightEyeHeightIncrease: () => void;
      rightEyeHeightDecrease: () => void;
      rightEyeWidenessIncrease: () => void;
      rightEyeWidenessDecrease: () => void;
      rightEyeDimensionIncrease: () => void;
      rightEyeDimensionDecrease: () => void;
    }
  | {
      type: 'lips';
      widenessIncrease: () => void;
      widenessDecrease: () => void;
      topLipIncrease: () => void;
      topLipDecrease: () => void;
      bottomLipIncrease: () => void;
      bottomLipDecrease: () => void;
      heightIncrease: () => void;
      heightDecrease: () => void;
    }
  | {
      type: 'plusminus';
      increase: () => void;
      decrease: () => void;
    }
  | {
      type: 'imageBean' | 'imageBeanLarge';
      action: () => void;
      noMargin?: boolean;
      image: string;
    }
);

export type ActionSection = {
  name: string;
  icon: string;
  categories: {
    category: string | null;
    actions: Action[];
  }[];
};

export type Languages = 'it' | 'en' | 'fr' | 'de' | 'es' | 'ru';

export type Param =
  | {
      type: 'rgb';
      value: [number, number, number];
      options: [number, number, number][];
    }
  | {
      type: 'range';
      value: number;
    };

export type Filter = {
  id: number;
  type: 'rgb' | 'range' | 'teeth';
  name: string;
  cost: number;
  minutes: number;
  active: boolean;
  params: {
    [name: string]: Param;
  };
};

export type Pages = /* 'ai' |  */'face' | 'lightandcolor' | 'effects' | 'colorwheel';

export type SkinTone = {
  shadows: {
    red: number;
    green: number;
    blue: number;
  };
  midtones: {
    red: number;
    green: number;
    blue: number;
  };
  highlights: {
    red: number;
    green: number;
    blue: number;
  };
};
