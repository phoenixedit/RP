import React from 'react';
import styled, { createGlobalStyle } from 'styled-components';

import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { Container } from './components/common/container';
import { Loader } from './components/common/spinner';
import { Activation } from './routes/activation';
import { Dashboard } from './routes/dashboard';
import { Guard } from './routes/guard';
import { useUI } from './stores/ui';

import { Footer } from './components/footer/footer';
import { useTranslate } from './hooks/useTranslate';

export const App: React.FC = () => {
  const { loading } = useUI(({ loading }) => ({
    loading,
  }));

  return (
    <Container $external>
      {loading && (
        <LoaderOverlay>
          <Loader size={48} />
        </LoaderOverlay>
      )}
      <GlobalStyle />
      <MemoryRouter>
        <Routes>
          <Route path="/" Component={() => <Guard />} />
          <Route path="/activation" Component={() => <Activation />} />
          <Route path="/dashboard" Component={() => <Dashboard />} />
        </Routes>
      </MemoryRouter>
      <Footer />
    </Container>
  );
};

const LoaderOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  z-index: 99999;
  width: calc(100% - 16px);
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;

const GlobalStyle = createGlobalStyle`
html, body {
  height: 100%;
  animation: repaint 0.01s;
}

@keyframes repaint {
  from { opacity: 1; }
  to { opacity: 0.99; }
}

body {
  color: white;
  user-select: none;
  background-color: #262626;
}

#root {
  overflow-y: scroll;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  padding-bottom: 100px;
  padding: 0;
  margin: 0;
  height: 100%;
  &::before {
    background-color: var(--uxp-host-border-color);
    position: fixed;
    right: 0;
    z-index: 200;
    height: 100vh;
    content: '';
    width: 16px;
  }
}
`;
