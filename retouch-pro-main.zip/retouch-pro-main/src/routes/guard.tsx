import { useQuery } from '@tanstack/react-query';
import React from 'react';
import { Navigate } from 'react-router-dom';
import { Container } from '../components/common/container';
import { Loader } from '../components/common/spinner';
import { useConfig } from '../hooks/useConfig';
import { checkLicense, needsUpdate } from '../utils';
import { useTranslate } from '../hooks/useTranslate';
import { ActionButton } from '../components/buttons/ActionButton';
import { shell } from 'uxp';
import styled from 'styled-components';
import { LogoBar } from '../components/header/logobar';

export const Guard = () => {
  const {
    isFetching: isFetchingLicenseValidation,
    data: isLicenseValid,
  } = useQuery(['check-license'], checkLicense, {
    refetchInterval: 1000 * 30,
    networkMode: 'always',
    refetchOnReconnect: true,
  });

  const { data: doesItNeedUpdate, isFetching: isFetchingUpdateCheck } = useQuery(['check-update'], needsUpdate, {
    refetchInterval: 1000 * 30,
    networkMode: 'always',
    refetchOnReconnect: true,
  });

  console.log('doesItNeedUpdate', doesItNeedUpdate);

  const { t } = useTranslate();

  // const appConfig = useConfig();

  const isFetching = isFetchingLicenseValidation || isFetchingUpdateCheck;

  if (isFetching) {
    return (
      <Container $centered>
        <Loader size={48} />
      </Container>
    );
  }

  if (!navigator.onLine) {
    return (
      <Container $centered>
        {t('error.offline')}
      </Container>
    );
  }

  if (doesItNeedUpdate) {
    return <Container>
      <LogoBar />
      <Container $centered>
      <PopupMessage>{t('newversion')}</PopupMessage>
      <ActionButton text='Update' variant='blueFilledBean' action={() => shell.openExternal('https://retouchzone.com/my-account/downloads/')} />
      </Container>
    </Container>
  }

  if (isLicenseValid) {
    return <Navigate to="/dashboard?page=face" />;
  } else {
    return <Navigate to="/activation" />;
  }
};

const PopupMessage = styled.div`
  text-align: center;
  margin-bottom: 16px;
`;
