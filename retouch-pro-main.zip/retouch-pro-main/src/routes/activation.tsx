import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { ActionButton } from '../components/buttons/ActionButton';
import { Container } from '../components/common/container';
import { useTranslate } from '../hooks/useTranslate';
// import { uxpFS } from '../utils';

import axios from 'axios';

import { useMutation } from '@tanstack/react-query';
import { InputField } from '../components/input/Input';

export const Activation = () => {
  const [licenseKey, setLicenseKey] = useState<string>('');

  const navigate = useNavigate();
  const { t } = useTranslate();

  const {
    mutate: activate,
    error,
    isLoading,
  } = useMutation(async () => {
    const payload = {
      key: licenseKey,
      temp_id: Math.random().toString(36).substring(2, 34),
      product: JSON.stringify({
        name: 'retouch-pro',
        mode: 'uxp',
        version: '5.0.0',
      }),
    };

    const formBody = [];
    for (const property in payload) {
      const encodedKey = encodeURIComponent(property);
      const encodedValue = encodeURIComponent(payload[property]);
      formBody.push(encodedKey + '=' + encodedValue);
    }

    const body = formBody.join('&');
    // const dataFolder = await uxpFS.getDataFolder();
    const { data } = await axios.post('https://api.retouchzone.com/activate', body, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    if (data.error) {
      throw new Error(data.error);
    }

    // const licenseFile = await dataFolder.createFile('retouchpro.license', {
    //   overwrite: true,
    // });
    // licenseFile.write(data.session, {});
    localStorage.setItem('retouchpro.license', data.session);

    navigate('/dashboard?page=ai');
    return true;
  });

  return (
    <Container $centered>
      <img src="/assets/logo.png" width={260} alt="Retouch Pro" />
      <Subtitle>The best solution for AI Photo Retouch</Subtitle>
      <SectionContainer>
        <InputContainer>
          <InputField
            name="license-key"
            label={t('activation.license_key')}
            type="text"
            placeholder={t('activation.license_key_placeholder')}
            value={licenseKey}
            update={(value) => setLicenseKey(value)}
          />
        </InputContainer>
        {error && <ErrorLabel>{(error as Error).message ?? t('common.error')}</ErrorLabel>}
        <ActionButton
          text={t('login.login_button_text')}
          action={() => {
            activate();
          }}
          disabled={isLoading}
          variant="primaryNormal"
        />
      </SectionContainer>
    </Container>
  );
};

const InputContainer = styled.form`
  margin-bottom: 20px;
`;

const Subtitle = styled.div`
  margin-top: 5px;
  font-weight: 400;
  font-style: italic;
  font-size: 12px;
  color: #d1d1d1;
`;

const SectionContainer = styled.div`
  margin-top: 25px;
  width: 190px;
  box-sizing: content-box;
`;

const ErrorLabel = styled.div`
  color: #d71913;
  font-size: 12px;
  margin-bottom: 20px;
  text-align: center;
`;
