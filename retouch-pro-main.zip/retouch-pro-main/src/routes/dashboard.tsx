import { useQuery } from '@tanstack/react-query';
// import { CognitoRefreshToken, CognitoUser, CognitoUserPool } from 'amazon-cognito-identity-js';
// import { isAxiosError } from 'axios';
// import { action, app } from 'photoshop';
import React, { useEffect, useMemo } from 'react';
import { Navigate /* , useNavigate */ } from 'react-router-dom';
import styled from 'styled-components';
import { Container } from '../components/common/container';
import { Spacer } from '../components/common/spacer';
import { LogoBar } from '../components/header/logobar';
import { Navbar } from '../components/header/navbar';
// import { AI } from '../components/pages/ai';
import { Effects } from '../components/pages/effects';
import { Face } from '../components/pages/face';
import { LightAndColor } from '../components/pages/lightandcolor';
// import { useConfig } from '../hooks/useConfig';
import { useQueryParams } from '../hooks/useQueryParams';
import { useTranslate } from '../hooks/useTranslate';
//  import { useAuth } from '../stores/auth';
import { useUI } from '../stores/ui';
import { Pages } from '../types';
import { checkLicense } from '../utils';
import { action, app } from 'photoshop';
import { ColorWheel } from '../components/pages/colorwheel';

const PageWrapper: Record<Pages, (props: { spacing: number }) => JSX.Element> = {
  //  ai: ({ spacing }) => <AI spacing={spacing} />,
  face: ({ spacing }) => <Face spacing={spacing} />,
  lightandcolor: ({ spacing }) => <LightAndColor spacing={spacing} />,
  effects: ({ spacing }) => <Effects spacing={spacing} />,
  colorwheel: ({ spacing }) => <ColorWheel spacing={spacing} />,
} as const;

export const Dashboard = () => {
  const { setPSToolbar, toast, setDocumentOpen, isDocumentOpen, footerHeight, setFooterHeight } =
    useUI(
      ({
        setPSToolbar,
        toast,
        setDocumentOpen,
        isDocumentOpen,
        footerHeight,
        setFooterHeight,
      }) => ({
        setPSToolbar,
        toast,
        setDocumentOpen,
        isDocumentOpen,
        footerHeight,
        setFooterHeight,
      })
    );
  /* const { refreshToken, idToken, logout, setAccessToken, setIdToken, setRefreshToken } = useAuth(
    ({ refreshToken, idToken, logout, setAccessToken, setIdToken, setRefreshToken }) => ({
      refreshToken,
      idToken,
      logout,
      setAccessToken,
      setIdToken,
      setRefreshToken,
    })
  ); */
  // const { appConfig } = useConfig();
  const page = useQueryParams<Pages>('page');
  const { t } = useTranslate();
  const CurrentPage = useMemo(() => PageWrapper[page ?? 'face'], [page]);

  useEffect(() => {
    /* if (page !== 'ai') {
      setPSToolbar(true);
    } else {
      setPSToolbar(false);
    } */
    setPSToolbar(true);

    return () => {
      setPSToolbar(false);
    };
  }, [page]);
  // const navigate = useNavigate();
  const { data: isLicenseValid, error } = useQuery(['check-license'], checkLicense, {
    refetchInterval: 1000 * 30,
    networkMode: 'always',
  });

  useEffect(() => {
    if (app.activeDocument) {
      setDocumentOpen(true);
    }

    const handleEvent = () => {
      if (app.activeDocument) {
        setDocumentOpen(true);
      } else {
        setDocumentOpen(false);
      }
    };

    action.addNotificationListener(
      [
        {
          // pick your event(s)
          event: 'select',
        },
        {
          event: 'open',
        },
        {
          event: 'make',
        },
        {
          event: 'move',
        },
        {
          event: 'close',
        },
        {
          event: 'delete',
        },
        {
          event: 'show',
        },
        {
          event: 'hide',
        },
        {
          event: 'set',
        },
      ],
      handleEvent
    );

    return () => {
      action.removeNotificationListener([{ event: 'open' }, { event: 'close' }], handleEvent);
    };
  }, []);

  /* useQuery(
    ['refresh-token'],
    async () => {
      if (!navigator.onLine) {
        navigate('/');
        return Promise.reject('offline');
      }
      if (!refreshToken && idToken) {
        logout();
        return Promise.resolve(true);
      }

      const userPool = new CognitoUserPool({
        UserPoolId: appConfig.cognito.userPoolId,
        ClientId: appConfig.cognito.userPoolWebClientId,
      });
      const user = new CognitoUser({
        Username: 'retouchzone',
        Pool: userPool,
      });

      const cognitoRefreshToken = new CognitoRefreshToken({ RefreshToken: refreshToken });

      return new Promise((resolve, reject) => {
        user.refreshSession(cognitoRefreshToken, (error, session) => {
          if (error) {
            logout();
            return reject(error);
          }

          const accessToken = session.getAccessToken().getJwtToken();
          const idToken = session.getIdToken().getJwtToken();
          const refreshToken = session.getRefreshToken().getToken();

          setAccessToken(accessToken);
          setIdToken(idToken);
          setRefreshToken(refreshToken);

          resolve(true);
        });
      });
    },
    {
      refetchInterval: 1000 * 30,
      enabled: !!idToken && !!appConfig,
      networkMode: 'always',
      useErrorBoundary: (error) => {
        if (isAxiosError(error)) {
          if (error.response?.status === 401) {
            logout();
          }
        }
        return false;
      },
    }
  ); */

  if (error || isLicenseValid === false) {
    return <Navigate to="/" />;
  }

  return (
    <Container>
      <Header>
        <LogoBar />
        <Spacer size={25} />
        <Navbar
          items={{
            // ai: t('menu.ai'),
            face: t('menu.face'),
            lightandcolor: t('menu.light_and_color'),
            effects: t('menu.effects'),
            colorwheel: t('menu.color_wheel'),
          }}
        />
      </Header>
      <BodyPositioner>
        {/* {isDocumentOpen ? (
          <CurrentPage spacing={45 + (page !== 'ai' && isDocumentOpen ? 120 : 0) + (toast ? 80 : 0)} />
        ) : (
          <Container $external $centered>
            {t('no_image')}
          </Container>
        )} */}
        <CurrentPage spacing={footerHeight} />
      </BodyPositioner>
    </Container>
  );
};

const Header = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  padding: 15px;
  width: calc(100% - 16px);
  background-color: #262626;
`;

const BodyPositioner = styled.div`
  padding-top: 100px;
  width: 100%;
  height: 100%;
`;
