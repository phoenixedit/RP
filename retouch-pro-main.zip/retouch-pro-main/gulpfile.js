const gulp = require('gulp');
const jsxbin = require('jsxbin');
const fs = require('fs');

const rawsFolder = 'extendscript';

gulp.task("binify", () => {
  const recursiveBinify = async (folder) => {
    fs.readdir(folder, async (err, files) => {
      for (const file of files) {
        if (fs.statSync(folder + "/" + file).isDirectory()) {
          await recursiveBinify(folder + "/" + file)
        } else {
          const filePath = folder + "/" + file;
          const output = filePath.split("/");
          output[0] = 'dist/bin';
          const fileName = output.pop();

          if (fileName.endsWith(".jsx")) {
            await jsxbin(filePath, output.join("/") + "/");
          } else {
            if (!fs.existsSync(output.join("/"))) {
              fs.mkdirSync(output.join("/"), { recursive: true });
            }
            fs.copyFileSync(filePath, output.join("/") + "/" + fileName);
          }
        }
      }
    });
  }

  return recursiveBinify(rawsFolder);;
});
