const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');

module.exports = (_env, arg) => {
  return {
    entry: './src/index.tsx',
    output: {
      path: path.resolve(__dirname, 'dist'),
      filename: 'index.js',
      //libraryTarget: "commonjs2"
    },
    devtool: 'cheap-eval-source-map', // won't work on XD due to lack of eval
    externals: {
      uxp: 'commonjs2 uxp',
      photoshop: 'commonjs2 photoshop',
      os: 'commonjs2 os',
    },
    resolve: {
      extensions: ['.ts', '.tsx', '.js', 'jsx', '.css'],
    },
    module: {
      rules: [
        {
          test: /\.[jt]sx?$/,
          exclude: /node_modules/,
          loader: 'esbuild-loader',
          options: {
            target: 'es2015',
          },
        },
        {
          test: /\.png$/,
          exclude: /node_modules/,
          loader: 'file-loader',
        },
      ],
    },
    plugins: [
      // new CleanWebpackPlugin(),
      new CopyPlugin(['plugin'], {
        copyUnmodified: true,
      }),
    ],
  };
};
